jQuery(document).ready(function() {

    $('.ctm_select2').select2({
        allowClear: true
    });

    $('.ctm_s2_multi').select2();
    
    $('.ctm_timepicker').timepicker();

    var arrows;
    if (KTUtil.isRTL()) {
        arrows = {
            leftArrow: '<i class="la la-angle-right"></i>',
            rightArrow: '<i class="la la-angle-left"></i>'
        }
    } else {
        arrows = {
            leftArrow: '<i class="la la-angle-left"></i>',
            rightArrow: '<i class="la la-angle-right"></i>'
        }
    }

    $('.ctm_time').timepicker({
        minuteStep: 1,
        defaultTime: '',
        showSeconds: true,
        showMeridian: false,
        snapToStep: true
    });

    // range picker
    $('.ctm_daterangepicker').daterangepicker({
        buttonClasses: ' btn',
        applyClass: 'btn-primary',
        cancelClass: 'btn-secondary',
        locale: {
            format: 'DD/MM/YYYY'
        }
    });

    $('.ctm_drp').daterangepicker({
        buttonClasses: ' btn',
        applyClass: 'btn-primary',
        cancelClass: 'btn-secondary',
        /*locale: {
            format: 'DD/MM/YYYY'
        }*/
    });

    $('.ctm_date').datepicker({
        rtl: KTUtil.isRTL(),
        todayHighlight: true,
        autoclose: true,
        templates: arrows,
        startDate: '-0m',
        format: 'dd/mm/yyyy',
    });

    // range picker
    $('.ctm_rangepicker').datepicker({
        rtl: KTUtil.isRTL(),
        todayHighlight: true,
        templates: arrows
    });

    $('.ctm_dp').datepicker({
        rtl: KTUtil.isRTL(),
        todayHighlight: true,
        templates: arrows,
    //    startDate: '-0m',
        format: 'dd-mm-yyyy',
    });

    // range picker
    $('.ctm_yearpicker').datepicker({
        format: "yyyy",
		viewMode: "years", 
		minViewMode: "years",
		autoclose:true //to close picker once year is selected
    });

    $('.ctm_datepicker').datepicker({
        rtl: KTUtil.isRTL(),
        todayHighlight: true,
        templates: arrows,
        startDate: '-0m',
        format: 'dd/mm/yyyy',
    });

    $('.ctm_picker').datepicker({
        rtl: KTUtil.isRTL(),
        todayHighlight: true,
        templates: arrows,
    //    startDate: '-0m',
        format: 'dd/mm/yyyy',
    });

    $('.ctm_datepicker_vo').datepicker({
        rtl: KTUtil.isRTL(),
        todayHighlight: true,
        templates: arrows,
        startDate: '-0m',
    //    format: 'dd/mm/yyyy',
    });

    $('.ctm_dt').datepicker({
        rtl: KTUtil.isRTL(),
        todayHighlight: true,
        format: 'dd/mm/yyyy',
        orientation: "bottom left",
        templates: arrows
    });

    //  time picker
    $('.ctm_tp').timepicker();

    $('.ctm_dp_for_dob').datepicker({
        rtl: KTUtil.isRTL(),
        format: 'dd-mm-yyyy',
    //    endDate: '-18Y', 
        todayHighlight: true,
        autoclose: true,
        templates: arrows
    });

    // file input
    $('.custom-file-input').on('change', function() {
        var fileName = $(this).val();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
    
    // form repeater
    $('.ctm_repeater').repeater({
        initEmpty: false,
        
        show: function() {
            alert();
            $(this).slideDown();

            $('.ctm_dt, .ctm_datepicker').datepicker({
                rtl: KTUtil.isRTL(),
                todayHighlight: true,
                templates: arrows,
                startDate: '-0m',
                format: 'dd/mm/yyyy',
            });

            $('.ctm_tp, .ctm_timepicker').timepicker();

        //    $('.ctm_s2').select2();

            $('.select2-container').remove();
            $('.ctm_select2').select2({
                width: '100%',
                placeholder: 'Choose slots',
                allowClear: true
            });

            $('.doses').trigger('change');

            $('.custom-file-input').on('change', function() {
                var fileName = $(this).val();
                $(this).next('.custom-file-label').addClass("selected").html(fileName);
            });                     
        },

        hide: function(deleteElement) {                 
            if(confirm('Are you sure you want to delete this element?')) {
                $(this).slideUp(deleteElement);
            }                                  
        }      
    });

    $('#kt_datetimepicker_1').datetimepicker({
        todayHighlight: true,
        autoclose: true,
        format: 'dd/mm/yyyy hh:ii'
    });

    var avatar1 = new KTImageInput('ctm_image');

    var table = $('.ctm-datatable');

    // begin first table
    table.DataTable({
        responsive: true,
        // Pagination settings
        dom: `<'row'<'col-sm-6 text-left'f><'col-sm-6 text-right'B>>
        <'row'<'col-sm-12'tr>>
        <'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7 dataTables_pager'lp>>`,
        buttons: [
            'print',
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
        ],
    //    pagingType: 'full_numbers',
        columnDefs: [ ],
        
    });

    $('.ctm-db-export').DataTable({
        responsive: true,
        // Pagination settings
        dom: `<'row'<'col-sm-6 text-left'f><'col-sm-6 text-right'B>>
        <'row'<'col-sm-12'tr>>
        <'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7 dataTables_pager'lp>>`,

        buttons: [
            'print',
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
        ],
        columnDefs: [
        ],
    });
  
    // calender
    var todayDate  = moment().startOf('day');
    var YM         = todayDate.format('YYYY-MM');
    var YESTERDAY  = todayDate.clone().subtract(1, 'day').format('YYYY-MM-DD');
    var TODAY      = todayDate.format('YYYY-MM-DD');
    var TOMORROW   = todayDate.clone().add(1, 'day').format('YYYY-MM-DD');
    var calendarEl = document.getElementById('kt_calendar');
    var calendar   = new FullCalendar.Calendar(calendarEl, {
        plugins: [ 'bootstrap', 'interaction', 'dayGrid', 'timeGrid', 'list' ],
        themeSystem: 'bootstrap',

        isRTL: KTUtil.isRTL(),

        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },

        height: 800,
        contentHeight: 780,
        aspectRatio: 3,

        nowIndicator: true,
        now: TODAY + 'T09:25:00', // just for demo

        views: {
            dayGridMonth: { buttonText: 'month' },
            timeGridWeek: { buttonText: 'week' },
            timeGridDay: { buttonText: 'day' }
        },

        defaultView: 'dayGridMonth',
        defaultDate: TODAY,

        editable: true,
        eventLimit: true, // allow "more" link when too many events
        navLinks: true,
        events: [
            {
                title: 'All Day Event',
                start: YM + '-01',
                description: 'Toto lorem ipsum dolor sit incid idunt ut',
                className: "fc-event-danger fc-event-solid-warning"
            },
            {
                title: 'Reporting',
                start: YM + '-14T13:30:00',
                description: 'Lorem ipsum dolor incid idunt ut labore',
                end: YM + '-14',
                className: "fc-event-success"
            },
            {
                title: 'Company Trip',
                start: YM + '-02',
                description: 'Lorem ipsum dolor sit tempor incid',
                end: YM + '-03',
                className: "fc-event-primary"
            },
            {
                title: 'ICT Expo 2017 - Product Release',
                start: YM + '-03',
                description: 'Lorem ipsum dolor sit tempor inci',
                end: YM + '-05',
                className: "fc-event-light fc-event-solid-primary"
            },
            {
                title: 'Dinner',
                start: YM + '-12',
                description: 'Lorem ipsum dolor sit amet, conse ctetur',
                end: YM + '-10'
            },
            {
                id: 999,
                title: 'Repeating Event',
                start: YM + '-09T16:00:00',
                description: 'Lorem ipsum dolor sit ncididunt ut labore',
                className: "fc-event-danger"
            },
            {
                id: 1000,
                title: 'Repeating Event',
                description: 'Lorem ipsum dolor sit amet, labore',
                start: YM + '-16T16:00:00'
            },
            {
                title: 'Conference',
                start: YESTERDAY,
                end: TOMORROW,
                description: 'Lorem ipsum dolor eius mod tempor labore',
                className: "fc-event-primary"
            },
            {
                title: 'Meeting',
                start: TODAY + 'T10:30:00',
                end: TODAY + 'T12:30:00',
                description: 'Lorem ipsum dolor eiu idunt ut labore'
            },
            {
                title: 'Lunch',
                start: TODAY + 'T12:00:00',
                className: "fc-event-info",
                description: 'Lorem ipsum dolor sit amet, ut labore'
            },
            {
                title: 'Meeting',
                start: TODAY + 'T14:30:00',
                className: "fc-event-warning",
                description: 'Lorem ipsum conse ctetur adipi scing'
            },
            {
                title: 'Happy Hour',
                start: TODAY + 'T17:30:00',
                className: "fc-event-info",
                description: 'Lorem ipsum dolor sit amet, conse ctetur'
            },
            {
                title: 'Dinner',
                start: TOMORROW + 'T05:00:00',
                className: "fc-event-solid-danger fc-event-light",
                description: 'Lorem ipsum dolor sit ctetur adipi scing'
            },
            {
                title: 'Birthday Party',
                start: TOMORROW + 'T07:00:00',
                className: "fc-event-primary",
                description: 'Lorem ipsum dolor sit amet, scing'
            },
            {
                title: 'Click for Google',
                url: 'http://google.com/',
                start: YM + '-28',
                className: "fc-event-solid-info fc-event-light",
                description: 'Lorem ipsum dolor sit amet, labore'
            }
        ],

        eventRender: function(info) {
            var element = $(info.el);

            if (info.event.extendedProps && info.event.extendedProps.description) {
                if (element.hasClass('fc-day-grid-event')) {
                    element.data('content', info.event.extendedProps.description);
                    element.data('placement', 'top');
                    KTApp.initPopover(element);
                } else if (element.hasClass('fc-time-grid-event')) {
                    element.find('.fc-title').append('<div class="fc-description">' + info.event.extendedProps.description + '</div>');
                } else if (element.find('.fc-list-item-title').lenght !== 0) {
                    element.find('.fc-list-item-title').append('<div class="fc-description">' + info.event.extendedProps.description + '</div>');
                }
            }
        }
    });

    calendar.render();

});