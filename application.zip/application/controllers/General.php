<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General extends MY_Controller {

    function __construct() {
        parent::__construct();

        $this->tbl_session_master = TBL_SESSION;
        $this->tbl_users = TBL_USERS;

        $this->load->model(
                array(
                    'user_model',
                    'general_model',
                    'activity_model'
                )
        );
    }

    function index() {
        $this->login();
    }

    function create_session($id) {
        $this->content->_header = 'SUPER SCORE BOARD';
        $this->content->session_data = $this->general_model->get_session($id);

        $this->load_admin_view('userRegister', $title);
    }

    function user_registration($id) {
        if ($this->form_validation->run('user_register')) {
            $post = $this->input->post();

            $user = array();
            $user['first_name']  = strtolower($post['name']);
            $user['mobile']      = $post['mobile'];
            $user['session_id']  = $post['session_id'];
            $user['state']       = $post['state'];
            $user['city']        = $post['city'];
            $user['role']        = 4;
            $user['user_status'] = 1;
            $user['created_on']  = time();

            $user_id = $this->user_model->add_data($this->tbl_users, $user);

            if (isset($user_id) && !empty($user_id)) :

                $this->welcome($user_id);
                return;

            endif;
        }

        $this->content->_header = 'QUIZ CHALLENGE';
        $this->content->session_data = $this->general_model->get_session($id);
        $this->content->_states = $this->general_model->get_states($id);

        $this->load_admin_view('userRegistrationForm', $title);
    }

    function get_city() {
        $state = $this->input->post('state_id');
        $city = $this->general_model->get_city($state);

        if (!empty($city)) {
            echo '<option value=""></option>';
            foreach ($city as $city) {
                echo '<option value="' . $city->id . '">' . $city->name . '</option>';
            }
        }
    }

    function welcome($user_id) {
        $this->content->_header = '';
        $userdata = $this->user_model->user_detail($user_id);
        $this->content->_userdata = $userdata;
        $this->content->_sessiondata = $this->user_model->session_detail($userdata->session_id);
        $this->content->_user_id = $user_id;

        $this->load_admin_view('userWelcome', $title);
    }

    function leaderboard($id) {
        $this->content->_header = 'SCOREBOARD';
        $this->content->title = $title;
        $this->content->_status = User_status::getValue();
        $this->content->_questions = $this->user_model->get_quesstions();
        $this->content->_list = $this->user_model->get_leaderboard($id);
        $this->content->action = base_url('console/user/add');
        $this->content->session_id = $id;
        $price = array_column($this->content->_list, 'total');
        array_multisort($price, SORT_DESC, $this->content->_list);
        
        $price = array_column($this->content->_list, 'time');
        array_multisort($price, SORT_DESC, $this->content->_list);
        
        $this->load_admin_view('session_manager', $title);
    }

    function dynamicLederData() {
        $id = $this->input->post('session_id');
        $_list = $this->user_model->get_leaderboard($id);
        
        $price = array_column($_list, 'total');
        array_multisort($price, SORT_DESC, $_list);
        
        $price = array_column($this->content->_list, 'time');
        array_multisort($price, SORT_DESC, $this->content->_list);
        
        $i = 1;
        if (!empty($_list)) {
            foreach ($_list as $list) {
                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo toPropercase($list->first_name); ?></td>
                    <td><?php echo $list->Q1; ?></td>
                    <td><?php echo $list->Q2; ?></td>
                    <td><?php echo $list->Q3; ?></td>
                    <td><?php echo $list->Q4; ?></td>
                    <td><?php echo $list->Q5; ?></td>
                    <td><?php echo $list->Q6; ?></td>
                    <td><?php echo $list->Q7; ?></td>
                    <td><?php echo $list->Q8; ?></td>
                    <td><?php echo $list->Q9; ?></td>
                    <td><?php echo $list->Q10; ?></td>
                    <td><?php echo $list->total; ?></td>
                    <td><?php echo $list->time; ?></td>
                </tr>

                <?php
                $i++;
            }
        } else {
            echo '<tr><td colspan="14"><center>No data found</center></td></tr>';
        }
    }

    private function load_admin_view($viewname, $page_title) {
        $this->masterpage->setMasterPage('user_master_page');
        $this->masterpage->setPageTitle($page_title);
        $this->masterpage->addContentPage('console/user/' . $viewname, 'content', $this->content);
        $this->masterpage->show();
    }

    function getSessionData() {
        $session_id = $this->input->post('session_status');
        $sessiondata = $this->user_model->session_detail($session_id);

        if ($sessiondata->status == 1) {
            echo 'yes';
        } else {
            echo 'no';
        }
    }

    function conductQuiz($user_id) {
        $this->content->_header = 'Quiz';
        $this->content->title = $title;
        $this->content->_questions = $this->user_model->get_questions();
        $this->content->user_id = $user_id;
        $this->load_quiz_view('conductQuiz', $title);
    }

    private function load_quiz_view($viewname, $page_title) {
        $this->masterpage->setMasterPage('quiz_master_page');
        $this->masterpage->setPageTitle($page_title);
        $this->masterpage->addContentPage('console/user/' . $viewname, 'content', $this->content);
        $this->masterpage->show();
    }

    function startSession() {
//        $this->load->model(array('app_model'));   
        $session_id = $this->input->post('session_id');
        $update_data = array();
        $update_data['status'] = 1;
        $session_data = $this->user_model->edit_data($this->tbl_session_master, $update_data, 'session_id', $session_id);
        echo $session_id;
    }
    
    function getexamdata()
    {
        $data = array();
        parse_str($this->input->post('data'),$data);
        $point = 0;
        if(isset($data['stp_select_option']))
        {
            if($data['stp_select_option'] == $data['correct_id'])
            {
                $point = 10;
            }    
        }    
        $i_array = array(
          'user_id'    =>   $data['user_id'],
          'que_id'     =>   $data['question_id'],
          'answer_key' =>   $data['stp_select_option'],
          'point'      =>   $point,
          'created_at' =>  time(),
        );

        $wh = 'user_id = ' . $data['user_id'] . ' AND que_id = ' . $data['question_id'];
        $get_count = $this->user_model->get_result_count('fs_question_answer', $wh);

        if( $get_count == 0 )
        {
            $this->user_model->add_data('fs_question_answer',$i_array);
        }
    }
    
    function thankyou()
    {
        $this->load->view('console/user/thankyou');
    }

}

/* end of account */