<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// use PhpOffice\PhpSpreadsheet\Spreadsheet;
// use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Colors extends MY_Controller {

    function __construct() {
        parent::__construct();

        // module
        $this->ml_users = Module::USER;

        // tables
        $this->tbl_users = TBL_USERS;
        $this->tbl_color_master = TBL_COLORS;
        $this->tbl_session_master = TBL_SESSION;

        $this->load->model(
                array(
                    'user_model',
                    'general_model',
                    'activity_model'
                )
        );
    }

    function index() {
        $title = 'Micro App';
        $this->load_view('app_view', $title);
    }

    function add() {
        $title = 'Add Color';
        $this->content->breadcrumb = array(
            'Color' => 'console/colors',
            $title => NULL
        );

        $this->load->library('form_validation');

        if ($this->form_validation->run('add_color')) {
            $post = $this->input->post();
            $app = array();

            $app['name'] = strtolower($post['first_name']);
            $app['platform_charge'] = strtolower($post['platform_charge']);
            $app['status'] = (isset($post['status']) ? $post['status'] : NULL);
            $app['created_by'] = $this->session->userdata('user_id');
            $app['created_on'] = time();
            $color_id = $this->user_model->add_data($this->tbl_color_master, $app);
//            echo '<pre>';
//            print_r($_POST);
//            return;
            if (isset($color_id) && !empty($color_id)) {

                $contacts = array_filter($post['doses']);
                foreach ($contacts as $contact):
                    if (isset($contact['from_price']) && !empty($contact['from_price'])) {
                        $data[] = array(
                            'color_id'  => $color_id,
                            'from_price'    => $contact['from_price'],
                            'to_price'    => $contact['to_price'],
                            'charge'     => $contact['platform_price'],
                            
                        );
                    }
                endforeach;
                $this->user_model->add_batch(TBL_COLORS_PRICE, $data);


                // add activity log
                $this->_activity_log($color_id, Action::Add, $this->tbl_color_master);
                redirect('console/colors/view', 'refresh');
            }
        }

        $this->content->title = $title;
        $this->content->status = Status::getValue();
        $this->load_view('colors_form_view', $title);
    }

    function view() {
        $title = 'View Colors';

        $this->content->breadcrumb = array(
            'User' => 'console/user',
            'View Colors' => 'console/colors/view',
        );

        $this->content->title = $title;
        $this->content->_status = User_status::getValue();
        $this->content->action = ROOT_URL . 'console/colors/add';
        $this->load_view('colors_view', $title);
    }

    private function load_view($viewname = 'user_view', $page_title) {
        $this->masterpage->setMasterPage('master_page');
        $this->masterpage->setPageTitle($page_title);
        $this->masterpage->addContentPage('console/user/' . $viewname, 'content', $this->content);
        $this->masterpage->show();
    }

    function delete() {
        $id = $this->input->post('id');
        $row = $this->input->post('row');
        $table = $this->input->post('table');
        $file = $this->input->post('file');
        if (!$id && !$table && !$column) {
            redirect('console/app', 'refresh');
        }
        $this->load->model(array('app_model'));

        $data = array();
        $data[$row] = $id;
        $data['updated_by'] = $this->session->userdata['user_id'];
        $data['updated_on'] = time();
        $data['is_deleted'] = Deleted_status::DELETED;
        $affected_id = $this->app_model->edit_data($table, $data, $row, $id);

        if (isset($affected_id) && !empty($affected_id)) {

            if (isset($table) && !empty($table) && isset($file) && !empty($file)) {
                @unlink($file);
            }
            // add activity log
            $this->_activity_log($affected_id, Action::Delete, $this->ml_users);

            echo 'success';
        }
    }

    function get_list() {
        $post = $this->input->post();

        $data = $this->user_model->get_colors($post);
        echo json_encode($data);
    }
    
    

}

/* end of user */