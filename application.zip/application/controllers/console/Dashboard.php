<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{
             
		$title = '';

		/** page level css & js **/
		/*$this->content->extra_js = array('widgets');

		$this->load->model(array('user_model'));

		// tables
		$tb_users = TBL_USERS;
		$tb_views = TBL_VIEWS;
		$tb_model = TBL_QUESTIONS;

		$me_where = 'role = ' . User_role::MEMBER . ' AND user_status = ' . User_status::ACTIVE . ' AND user_deleted = ' . Deleted_status::NOT_DELETED;
		$total_member = $this->user_model->get_result_count($tb_users, $me_where);

		$total_views = $this->user_model->get_result_count($tb_views);

		$vi_where = 'created_on >= unix_timestamp(curdate())';
		$today_views = $this->user_model->get_result_count($tb_views, $vi_where);

		$mo_where = 'is_status = ' . Status::ACTIVE . ' AND is_deleted = ' . Deleted_status::NOT_DELETED;
		$total_model = $this->user_model->get_result_count($tb_model, $mo_where);

		$this->content->title        = $title;
		$this->content->total_member = $total_member;
		$this->content->total_views  = $total_views;
		$this->content->total_model  = $total_model;
		$this->content->today_views  = $today_views;*/
		$this->load_view('dashboard_view', $title);
	}
	
	private function load_view($viewname = 'dashboard_view', $page_title) {
		$this->masterpage->setMasterPage('master_page');
		$this->masterpage->setPageTitle($page_title);
		$this->masterpage->addContentPage('console/'.$viewname , 'content', $this->content);
                $this->masterpage->show();
	}
	
}
/* end of dashboard */