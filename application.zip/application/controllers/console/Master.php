<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends MY_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->user_id 		= 	$this->session->userdata('user_id');
		
		// module
		$this->ml_topic  	= 	Module::TOPIC;

		// tables
		$this->tbl_topic 	= 	TBL_TOPIC;
		$this->tbl_media 	= 	TBL_MEDIA;
	}

	function index() {
		$title = 'Micro App';
		$this->load_view('app_view', $title);
	}

	function app()
	{
		$segment = $this->uri->segment(4);
		if(! $segment) {
			redirect('console/master', 'refresh');
		}

		$title = 'View App';
		$this->content->breadcrumb = array(
			'Master' => 'console/master',
			$title   => NULL
		);
		$this->load->model(array('app_model'));
		$this->content->title = $title;
		
		$_app = $this->app_model->apps();
		foreach($_app as $key => $app) :
			$_app[$key]->count = $this->app_model->get_count($segment, $app->app_id);
		endforeach;

		$this->content->segment = $segment;
		$this->content->_list   = $_app;
		$this->load_view('app_list_view', $title);
	}

	// start package
	function add_topic()
	{
		$this->load->model(array('general_model', 'category_model'));
		$title = 'Add Topic';
		$this->content->breadcrumb = array(
			'Master' => 'console/master',
			'Topic'  => 'console/master/topic',
			$title   => NULL
		);
		
		$this->load->library('form_validation');	
		
		if($this->form_validation->run('add-topic'))
		{
			$post    = $this->input->post();
			$status  = (isset($post['status']) && !empty($post['status']) ? $post['status'] : Status::ACTIVE);
			$url_key = $this->nectar->generate_url_key($post['topic_name'], $this->tbl_topic);
			
			$add = array();
			$add['topic_name'] 		= 	strtolower($post['topic_name']);
			$add['category_id'] 	= 	$post['category_id'];
			$add['questions'] 		= 	$post['questions'];
			$add['status']   		= 	$status;
			$add['url_key']      	= 	$url_key;
			$add['created_by']   	= 	$this->user_id;
			$add['created_on']   	= 	time();
			$ids = $this->general_model->add_data($this->tbl_topic, $add);
			
			if(isset($ids) && !empty($ids))
			{
				// add activity log
				$this->_activity_log($ids, Action::Add, Module::TOPIC);

				if(isset($_FILES['media']['name']) && !empty($_FILES['media']['name']))
				{
					// upload media
					$uploadPath = $this->upload_path;
					if( ! is_dir($uploadPath))
					{
						mkdir($uploadPath, 0755, true);
					}
					
					$config['upload_path'] 	 = $uploadPath;
				//	$config['allowed_types'] = 'jpeg|jpg|png';
				//	$config['max_size']      = 2097152;
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					
					if($this->upload->do_upload('media'))
					{	
						$fileData = $this->upload->data();
						$media['media']       = $fileData['file_name'];
						$media['relative_id'] = $ids;
						$media['module']      = $this->ml_topic;
					} else {
		                $data['error_msg'] = $this->upload->display_errors();
					}

					if(!empty($media))
					{
						$media_id = $this->media_model->add_data($this->tbl_media, $media);
					}
				}

				redirect('console/master/topic', 'refresh');
			}
		}

		$this->content->title    	= 	$title;
		$this->content->_category 	= 	$this->category_model->get_category();
		$this->content->status 		= 	Status::getValue();
		$this->load_view('topic_form_view', $title);
	}

	function edit_topic()
	{
		$id = $this->uri->segment(4);
		if(!$id) {
			redirect('console/master/topic', 'refresh');
		}
		$this->load->model(array('general_model', 'category_model'));

		$title = 'Edit Topic';
		$detail = $this->general_model->topic_details($id);
		$this->content->breadcrumb = array(
			'master'       => 'console/master',
			$detail->title => NULL,
			$title         => NULL
		);

		$this->load->library('form_validation');	
		if($this->form_validation->run('edit-topic'))
		{
			$post = $this->input->post();
			$edit = array();

			if(isset($post['topic_name']) && isset($post['previous']) && ($post['topic_name'] != $post['previous']))
			{
				$edit['url_key'] = $this->nectar->generate_url_key($post['topic_name'], $this->tbl_topic);
			}
			
			$edit['topic_id']   	= 	$post['topic_id'];
			$edit['category_id']   	= 	$post['category_id'];
			$edit['questions']   	= 	$post['questions'];
			$edit['topic_name'] 	= 	strtolower($post['topic_name']);
			$edit['status']   		= 	$post['status'];
			$edit['updated_by']   	= 	$this->user_id;
			$edit['updated_on']   	= 	time();
            $topic_id = $this->general_model->edit_data($this->tbl_topic, $edit, 'topic_id', $post['topic_id']);

			if(isset($topic_id) && !empty($topic_id))
			{
				// add activity log
				// $this->_activity_log($topic_id, Action::Edit, Module::TOPIC);
				redirect('console/master/topic', 'refresh');
			}
		}
		
		$this->content->title    	= 	$title;
		$this->content->status 		= 	Status::getValue();
		$this->content->_category 	= 	$this->category_model->get_category();
		$this->content->edit     	= 	$detail;
		$this->load_view('topic_form_view', $title);
	}

	function topic()
	{
		$title = 'View Topic';
		$this->content->breadcrumb = array(
			'Master' => 'console/master',
			$title   => NULL
		);
		$this->load->model(array('general_model'));
		$this->content->title = $title;
		$this->content->_list = $this->general_model->topics();

		$this->content->action = base_url('console/master/add-topic');
		$this->load_view('topic_list_view', $title);
	}
	// end package

	function delete() {
		$id    = $this->input->post('id');
		$row   = $this->input->post('row');
		$table = $this->input->post('table');
		if(!$id && !$table && !$column) {
			redirect('console/master', 'refresh');
		}
		$this->load->model(array('general_model'));
        
        $data = array();
		$data[$row]         = $id;
		$data['updated_by'] = $this->session->userdata['user_id'];
		$data['updated_on'] = time();
		$data['is_deleted'] = Deleted_status::DELETED;
        $affected_id = $this->general_model->edit_data($table, $data, $row, $id);

		if(isset($affected_id) && !empty($affected_id)) {
			// add activity log
			// $this->_activity_log($affected_id, Action::Delete, $this->ml_topic);

			echo 'success';
		}
	}

	private function load_view($viewname = 'app_view', $page_title) {
		$this->masterpage->setMasterPage('master_page');
		$this->masterpage->setPageTitle($page_title);
		$this->masterpage->addContentPage('console/master/'.$viewname , 'content', $this->content);
        $this->masterpage->show();
	}
	
}
/* end of master */