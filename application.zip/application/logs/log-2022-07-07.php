<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-07 01:41:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '103'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance +
WHERE `user_id` = '103'
ERROR - 2022-07-07 01:41:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '103'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance +
WHERE `user_id` = '103'
ERROR - 2022-07-07 01:42:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '103'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance +
WHERE `user_id` = '103'
