<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-01 18:45:22 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `wp_betted_transaction`
WHERE `active_game_id` = 1
AND `game_id` IN(1, 2, 3)
