<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-23 15:02:24 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: SELECT *
FROM `wp_day_count`
WHERE `date` = '2022-06-23'
ERROR - 2022-06-23 21:22:10 --> Severity: error --> Exception: Call to a member function get_user_data_by_login_id() on null /home/nectarinfoway/public_html/demo/application/controllers/Account.php 299
ERROR - 2022-06-23 22:34:56 --> Severity: error --> Exception: Call to a member function update() on null /home/nectarinfoway/public_html/demo/application/controllers/console/User.php 160
ERROR - 2022-06-23 22:35:05 --> Severity: error --> Exception: Call to a member function update() on null /home/nectarinfoway/public_html/demo/application/controllers/console/User.php 160
