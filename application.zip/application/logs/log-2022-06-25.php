<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-25 09:36:16 --> Query error: Unknown column 'amout' in 'field list' - Invalid query: INSERT INTO `wp_withdrawl_request` (`user_id`, `amout`, `created_at`) VALUES ('42', '200', '2022-06-25 09:36:16')
ERROR - 2022-06-25 09:49:34 --> Severity: error --> Exception: Call to undefined function startouppder() /home/nectarinfoway/public_html/demo/application/controllers/Account.php 306
ERROR - 2022-06-25 09:50:44 --> Severity: error --> Exception: Call to undefined function startoupper() /home/nectarinfoway/public_html/demo/application/controllers/Account.php 306
ERROR - 2022-06-25 18:09:15 --> Query error: Unknown column 'charge' in 'field list' - Invalid query: INSERT INTO `wp_withdrawl_request` (`user_id`, `amount`, `charge`, `created_at`) VALUES ('42', 475, 25, '2022-06-25 18:09:15')
ERROR - 2022-06-25 18:09:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '42'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance -
WHERE `user_id` = '42'
ERROR - 2022-06-25 19:27:01 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1493
ERROR - 2022-06-25 20:11:37 --> Query error: Unknown column 'game_id' in 'where clause' - Invalid query: SELECT *
FROM `wp_betted_transaction`
WHERE `active_game_id` = 1061
AND `game_id` IN(1, 2, 3)
ERROR - 2022-06-25 20:12:48 --> Query error: Unknown column 'game_id' in 'field list' - Invalid query: INSERT INTO `wp_betted_transaction` (`user_id`, `game_id`, `active_game_id`, `betted_amount`, `created_at`) VALUES ('42', '2', '1062', '100.00', '2022-06-25 20::48')
ERROR - 2022-06-25 20:15:05 --> Query error: Unknown column 'game_id' in 'where clause' - Invalid query: SELECT *
FROM `wp_betted_transaction`
WHERE `active_game_id` = 1062
AND `game_id` IN(1, 2, 3)
