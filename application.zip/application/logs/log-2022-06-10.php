<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-10 17:10:18 --> Unable to connect to the database
