<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-04 15:48:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '87'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance -
WHERE `user_id` = '87'
ERROR - 2022-07-04 19:33:03 --> Unable to connect to the database
ERROR - 2022-07-04 19:33:03 --> Unable to connect to the database
ERROR - 2022-07-04 19:33:03 --> Unable to connect to the database
ERROR - 2022-07-04 19:33:04 --> Unable to connect to the database
