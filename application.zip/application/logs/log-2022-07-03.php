<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-03 13:57:02 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home1/wingoqba/public_html/application/controllers/Account.php 3996
ERROR - 2022-07-03 16:30:16 --> Query error: Unknown column 'game_id' in 'where clause' - Invalid query: SELECT *
FROM `wp_color_master`
WHERE `game_id` = 1
ERROR - 2022-07-03 16:30:45 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/controllers/Account.php 2451
ERROR - 2022-07-03 16:31:35 --> Query error: Unknown column 'game_id' in 'where clause' - Invalid query: SELECT *
FROM `wp_color_master`
WHERE `game_id` != 1
