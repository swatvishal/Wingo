<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-30 03:13:16 --> Query error: Unknown column 'wp_active_game_id.id' in 'on clause' - Invalid query: SELECT `wp_betted_transaction`.*, `wp_draw_master`.`draw_name`
FROM `wp_betted_transaction`
JOIN `wp_draw_master` ON `wp_active_game_id`.`id` = `wp_betted_transaction`.`active_game_id`
WHERE `user_id` = '49'
ORDER BY `id` DESC
ERROR - 2022-06-30 03:38:18 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT SUM(wp_ref_bonus.amount) as tot_level_3, `wp_user_master`.`first_name`
FROM `wp_ref_bonus`
JOIN `wp_betted_transaction` ON `wp_betted_transaction`.`id` = `wp_ref_bonus`.`t_id`
JOIN `wp_user_master` ON `wp_user_master`.`user_id` = `wp_betted_transaction`.`user_id`
WHERE `wp_ref_bonus`.`level` = 3
AND `wp_ref_bonus`.`user_id` = '49'
ORDER BY `id` DESC
ERROR - 2022-06-30 19:44:25 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting ',' or ';' /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1227
ERROR - 2022-06-30 19:44:38 --> Severity: error --> Exception: syntax error, unexpected '$lvl_one_win_color' (T_VARIABLE), expecting ',' or ';' /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1235
ERROR - 2022-06-30 19:44:45 --> Severity: error --> Exception: syntax error, unexpected '$lvl_one_win_color' (T_VARIABLE), expecting ',' or ';' /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1235
