<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-29 17:18:18 --> Severity: error --> Exception: syntax error, unexpected end of file /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1311
ERROR - 2022-06-29 21:57:02 --> Severity: error --> Exception: syntax error, unexpected end of file /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1321
ERROR - 2022-06-29 23:08:03 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `wp_draw_result` SET `win_color` = Array, `win_number` = 9, `updated_time` = '2022-06-29 23:08:03', `is_completed` = 1
WHERE `draw_id` = 463
