<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-22 08:48:37 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_n() /home/nectarinfoway/public_html/demo/application/controllers/Account.php 930
ERROR - 2022-06-22 08:48:55 --> Query error: Unknown column 'active_game_id' in 'where clause' - Invalid query: SELECT *
FROM `wp_draw_master`
WHERE `active_game_id` = 3970
AND `game_id` IN(1, 2, 3)
ERROR - 2022-06-22 08:49:22 --> Query error: Unknown column 'active_game_id' in 'where clause' - Invalid query: SELECT *
FROM `wp_draw_master`
WHERE `active_game_id` = 3970
AND `game_id` IN(1, 2, 3)
ERROR - 2022-06-22 08:49:45 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_n() /home/nectarinfoway/public_html/demo/application/controllers/Account.php 956
ERROR - 2022-06-22 08:50:06 --> Query error: Unknown column 'active_game_id' in 'where clause' - Invalid query: SELECT *
FROM `wp_draw_master`
WHERE `active_game_id` = '5313'
AND `game_id` IN(4, 5, 6, 7, 8, 9)
ERROR - 2022-06-22 10:01:00 --> Severity: error --> Exception: Function name must be a string /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1044
ERROR - 2022-06-22 10:01:30 --> Severity: error --> Exception: Function name must be a string /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1044
ERROR - 2022-06-22 10:01:36 --> Severity: error --> Exception: Function name must be a string /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1044
ERROR - 2022-06-22 10:08:01 --> Severity: error --> Exception: Function name must be a string /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1039
ERROR - 2022-06-22 10:10:23 --> Severity: error --> Exception: Function name must be a string /home/nectarinfoway/public_html/demo/application/controllers/Account.php 1047
ERROR - 2022-06-22 10:45:27 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/nectarinfoway/public_html/demo/application/views/common/head_view.php 1
ERROR - 2022-06-22 10:45:27 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/nectarinfoway/public_html/demo/application/views/common/head_view.php 1
ERROR - 2022-06-22 10:45:29 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/nectarinfoway/public_html/demo/application/views/common/head_view.php 1
ERROR - 2022-06-22 10:45:30 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/nectarinfoway/public_html/demo/application/views/common/head_view.php 1
ERROR - 2022-06-22 10:45:50 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/nectarinfoway/public_html/demo/application/views/common/head_view.php 1
ERROR - 2022-06-22 10:45:51 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/nectarinfoway/public_html/demo/application/views/common/head_view.php 1
ERROR - 2022-06-22 10:46:27 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/nectarinfoway/public_html/demo/application/views/common/head_view.php 1
ERROR - 2022-06-22 19:55:27 --> Query error: Unknown column 'utr' in 'field list' - Invalid query: INSERT INTO `wp_balance_request` (`user_id`, `amount`, `utr`, `created_at`) VALUES ('37', '', '123456789', '2022-06-22 07:55:27')
ERROR - 2022-06-22 20:48:01 --> Severity: error --> Exception: Too few arguments to function Dashboard::recharge_request(), 0 passed in /home/nectarinfoway/public_html/demo/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/nectarinfoway/public_html/demo/application/controllers/member/Dashboard.php 98
