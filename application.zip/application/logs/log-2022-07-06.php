<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-06 23:40:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '103'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance +
WHERE `user_id` = '103'
ERROR - 2022-07-06 23:40:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '103'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance +
WHERE `user_id` = '103'
