<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-28 12:32:31 --> Severity: error --> Exception: Call to undefined function random() /home/nectarinfoway/public_html/demo/application/controllers/Account.php 259
ERROR - 2022-06-28 19:10:59 --> Query error: Unknown column 'mobile' in 'where clause' - Invalid query: UPDATE `wp_color_master` SET `otp_no` = 837939
WHERE `mobile` = '9662920315'
ERROR - 2022-06-28 19:12:24 --> Severity: error --> Exception: Call to a member function get_user_data_by_login_id() on null /home/nectarinfoway/public_html/demo/application/controllers/Account.php 406
ERROR - 2022-06-28 21:52:25 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: SELECT SUM(amount) as number_sum
FROM `wp_betted_transaction`
WHERE `active_game_id` = 2517
AND `game_id` IN(4, 5, 6, 7, 8, 9, 10, 11, 12, 13)
ERROR - 2022-06-28 22:16:40 --> Query error: Column 'refcode' cannot be null - Invalid query: INSERT INTO `wp_ref_bonus` (`user_id`, `draw_id`, `level`, `t_id`, `refcode`, `amount`) VALUES ('1', 2519, 1, '66', NULL, 1.5)
ERROR - 2022-06-28 23:06:36 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `wp_ref_bonus` (`user_id`, `draw_id`, `level`, `t_id`, `refcode`, `amount`) VALUES (NULL, 2526, 1, '80', NULL, 1)
ERROR - 2022-06-28 23:16:01 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: UPDATE `wp_user_master` SET balance = balance + 7.5
WHERE `id` = '47'
