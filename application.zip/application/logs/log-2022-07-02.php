<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-02 06:05:36 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `wp_betted_transaction`
WHERE `active_game_id` = 226
AND `game_id` IN(1, 2, 3)
ERROR - 2022-07-02 09:42:36 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `wp_betted_transaction`
WHERE `active_game_id` = 287
AND `game_id` IN(1, 2, 3)
ERROR - 2022-07-02 10:18:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `wp_betted_transaction`
WHERE `active_game_id` = 300
AND `game_id` IN(1, 2, 3)
ERROR - 2022-07-02 11:28:02 --> Severity: error --> Exception: syntax error, unexpected '$data_arr' (T_VARIABLE) /home1/wingoqba/public_html/application/controllers/Account.php 3456
ERROR - 2022-07-02 11:29:01 --> Severity: error --> Exception: syntax error, unexpected '$data_arr' (T_VARIABLE) /home1/wingoqba/public_html/application/controllers/Account.php 3456
ERROR - 2022-07-02 11:53:05 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:28 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:29 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:36 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:38 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:46 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:48 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:52 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:53 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:53:56 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:54:01 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:54:02 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:54:04 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:54:11 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:54:26 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:54:30 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:54:39 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:55:01 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:55:32 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:55:40 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:55:43 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:55:58 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:55:59 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:55:59 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:56:01 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:56:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:56:06 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:56:11 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:56:18 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:56:38 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:57:01 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:57:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:57:36 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:57:37 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:57:40 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:58:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 11:58:15 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:58:25 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 11:59:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 12:00:01 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 12:00:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 12:00:20 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home1/wingoqba/public_html/application/controllers/Account.php 4538
ERROR - 2022-07-02 12:01:15 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:16 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:17 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:38 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:38 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:40 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:40 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:40 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:41 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:42 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:50 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:01:51 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:03:29 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:03:34 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 12:03:35 --> Severity: error --> Exception: syntax error, unexpected end of file /home1/wingoqba/public_html/application/views/member/dashboard_view.php 582
ERROR - 2022-07-02 16:05:36 --> Query error: Table 'wingoqba_app.wp_draw_master' doesn't exist - Invalid query: UPDATE `wp_draw_master` SET `win_color` = 2, `win_number` = 4
WHERE `id` = 411
ERROR - 2022-07-02 18:45:05 --> Query error: Unknown column 'win_color' in 'field list' - Invalid query: UPDATE `wp_betted_transaction` SET `updated_at` = '2022-07-02 06:45:05', `win_color` = 3, `win_number` = 10
WHERE `active_game_id` = '463'
ERROR - 2022-07-02 20:56:34 --> Query error: Unknown column 'win_color' in 'field list' - Invalid query: UPDATE `wp_betted_transaction` SET `updated_at` = '2022-07-02 08:56:34', `win_color` = 3, `win_number` = 12
WHERE `active_game_id` = '500'
ERROR - 2022-07-02 22:02:45 --> Query error: Unknown column 'win_color' in 'field list' - Invalid query: UPDATE `wp_betted_transaction` SET `updated_at` = '2022-07-02 10:02:45', `win_color` = 1, `win_number` = 13
WHERE `active_game_id` = '523'
