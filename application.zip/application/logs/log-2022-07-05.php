<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-05 20:25:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '98'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance -
WHERE `user_id` = '98'
ERROR - 2022-07-05 20:25:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '98'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance -
WHERE `user_id` = '98'
ERROR - 2022-07-05 21:04:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `user_id` = '98'' at line 2 - Invalid query: UPDATE `wp_user_master` SET balance = balance -
WHERE `user_id` = '98'
