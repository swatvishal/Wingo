<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// load_entities(array('user'));

class General_model extends MY_Model
{
	public function __construct() {
		parent::__construct();
	}
	
	###################### topic ######################
	public function topics($status = NULL)
	{
		$this->db->select('t.topic_id, t.topic_name, cm.name, t.questions, t.status, t.url_key');
		$this->db->from(TBL_TOPIC . ' t');
		$this->db->join('category_master as cm', 't.category_id = cm.category_id', 'left');
		$this->db->where(array('t.is_deleted' => Deleted_status::NOT_DELETED));
		if( isset($status) && !empty($status) )
		{
			$this->db->where('t.status', $status);
		}
		$this->db->order_by('t.topic_id', 'desc');
		return $this->db->get()->result();
	}

	public function topics_by_category($id)
	{
		$this->db->select('t.topic_id, t.topic_name, t.questions, t.status, t.url_key');
		$this->db->from(TBL_TOPIC . ' t');
		$this->db->where(array('t.is_deleted' => Deleted_status::NOT_DELETED));
		$this->db->where('t.category_id', $id);
		$this->db->order_by('t.topic_id', 'desc');
		return $this->db->get()->result();
	}

	public function topic_details($id)
	{
		$this->db->select('t.topic_id, t.topic_name, t.category_id, t.questions, t.status, t.url_key');
		$this->db->from(TBL_TOPIC . ' t');
		$this->db->where(array('t.is_deleted' => Deleted_status::NOT_DELETED, 't.topic_id' => $id));
		return $this->db->get()->row();
	}
        
        public function get_session($id)
        {
            $this->db->select('*');
            $this->db->from(TBL_SESSION);
            $this->db->where('session_id',$id);
            return $this->db->get()->row();
        }  
        
        public function get_states()
        {
            $this->db->select('*');
            $this->db->from('fs_states');
            return $this->db->get()->result();
        }       
        
        public function get_city($id)
        {
            $this->db->select('*');
            $this->db->from('fs_cities');
            $this->db->where('state_id',$id);
            return $this->db->get()->result();
        }    
        
        function get_games()
        {
            $this->db->select('*');
            $this->db->from(TBL_COLORS);
            $this->db->where('is_deleted', Deleted_status::NOT_DELETED);
            return $this->db->get()->result();
        }


}
/* end of general model */