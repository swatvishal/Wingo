<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

load_entities(array('user'));

class User_model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

    public function add_user(User_entity $data) {
        if ($this->db->insert('user_master', $data)) {
            return $this->db->insert_id();
        }
    }

    public function user_exist($mobile) {
        $this->db->select('u.user_id, u.email, u.mobile, u.user_status, up.gst_no, up.pan_no');
        $this->db->from('user_master as u');
        $this->db->join('user_profile as up', 'up.user_id = u.user_id', 'left');
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED, 'u.role' => User_role::CLIENT, 'u.mobile' => $mobile));
        return $this->db->get('user_master')->row();
    }

    public function check_user_exists($mobile, $app_id) {
        $this->db->where(array('mobile' => $mobile, 'user_deleted' => Deleted_status::NOT_DELETED, 'role' => User_role::MEMBER, 'app_id' => $app_id, 'user_status' => User_status::INACTIVE, 'profile_status' => User_status::ACTIVE));
        return $this->db->get('user_master')->row();
    }

    function update_password($user_id, $password) {
        $this->db->where('user_id', $user_id);
        $query = $this->db->update('user_master', array('password' => $password));
        if ($query) {
            return true;
        }
        return false;
    }

    public function users_by_role($role = NULL) {
        $this->db->select('u.user_id, u.first_name, u.last_name');
        $this->db->from('user_master as u');
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED));
        if (isset($role) && !empty($role)) {
            $this->db->where('u.role', $role);
        }
        $this->db->order_by('u.first_name', 'asc');
        return $this->db->get()->result();
    }

    public function user_detail($user_id) {
        $this->db->select('u.*');
        $this->db->from(TBL_USERS . ' u');
        $this->db->where(array('u.user_id' => $user_id, 'u.user_deleted' => Deleted_status::NOT_DELETED));
        return $this->db->get()->row();
    }

    public function session_detail($id) {
        $this->db->select('u.*');
        $this->db->from(TBL_SESSION . ' u');
        $this->db->where(array('u.session_id' => $id, 'u.is_deleted' => Deleted_status::NOT_DELETED));
        return $this->db->get()->row();
    }

    public function user_count($app) {
        $this->db->from('user_master');
        $this->db->where(array('user_deleted' => Deleted_status::NOT_DELETED, 'app_id' => $app, 'role' => User_role::MEMBER));
        return $this->db->count_all_results();
    }

    public function get_users_by_role($role = NULL) {
        $this->db->select('u.user_id, u.first_name, u.last_name, u.email, u.mobile, ad.city, ad.state, ad.pincode, u.ac_no,u.ifsc');
        $this->db->from('user_master as u');
        $this->db->join('user_profile as up', 'up.user_id = u.user_id', 'left');
        $this->db->join('address as ad', 'ad.relative_id = u.user_id AND ad.is_deleted =' . Deleted_status::NOT_DELETED, 'left');
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED, 'u.role' => User_role::MEMBER, 'u.user_status' => Status::ACTIVE));
        $this->db->group_by('u.user_id');
        return $this->db->get()->result();
    }

    function get_users($post = null) {
        $response = array();

        ## Read value
        $draw = $post['draw'];
        $start = $post['start'];
        $rowPerPage = $post['length'];
        $columnIndex = $post['order'][0]['column'];
        $columnName = $post['columns'][$columnIndex]['data'];
        $columnSortOrder = $post['order'][0]['dir'];
        $searchValue = $post['search']['value'];

        // Custom search filter 
        $name = $post['name'];
        $mobile = $post['mobile'];
        $status = $post['status'];

        ## Search 
        $search_arr = array();
        $searchQuery = "";
        if ($searchValue != '') {
            $search_arr[] = " (
	    	u.first_name like '%" . $searchValue . "%' or 
	    	u.mobile like '%" . $searchValue . "%' or 
	    	u.user_status like'%" . $searchValue . "%' ) ";
        }
        if ($status != '') {
            $search_arr[] = " u.user_status = '" . $status . "' ";
        }
        if ($name != '') {
            $search_arr[] = " u.first_name like '%" . $name . "%' ";
        }
        if ($mobile != '') {
            $search_arr[] = " u.mobile like '%" . $mobile . "%' ";
        }
        if (count($search_arr) > 0) {
            $searchQuery = implode(" and ", $search_arr);
        }

        ## Total number of records without filtering
        $this->db->from(TBL_USERS . ' u');
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED, 'u.role' => User_role::MEMBER));

        if ($searchQuery != '') {
            $this->db->where($searchQuery);
            $totalRecordwithFilter = $this->db->count_all_results();

            ## Total number of records without filtering
            $this->db->from(TBL_USERS);
            $this->db->where(array('user_deleted' => Deleted_status::NOT_DELETED, 'role' => User_role::MEMBER));
            $totalRecords = $this->db->count_all_results();
        } else {
            $totalRecords = $this->db->count_all_results();
            $totalRecordwithFilter = $totalRecords;
        }

        ## Fetch records
        $this->db->select('u.user_id,u.balance, u.first_name, u.ac_no,u.ifsc, u.last_name, u.email, u.email_verified, u.mobile, u.mobile_verified, u.role, u.user_status, u.created_on');
        $this->db->from(TBL_USERS . ' u');
        //	$this->db->join(TBL_SUBSCRIPTION . ' s', 's.user_id = u.user_id AND s.status = '. Status::ACTIVE .' AND s.type = '. Subscription_type::VIEW, 'left');
        //	$this->db->join(TBL_PACKAGE . ' p', 'p.package_id = s.package_id', 'left');
        if ($searchQuery != '')
            $this->db->where($searchQuery);
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED, 'u.role' => User_role::MEMBER));
        $this->db->order_by('u.user_id', 'desc');
        $this->db->group_by('u.user_id');
        $this->db->limit($rowPerPage, $start);
        $records = $this->db->get()->result();

        $data = array();

        foreach ($records as $list) :
            $data[] = array(
                'user_id' => $list->user_id,
                'name' => '<div class="d-flex align-items-center">
                    <div class="ml-3">' . toPropercase($list->first_name . ' ' . $list->last_name) . '<br><a href="javascript:;" class="text-muted text-hover-primary">' . $list->email . ' ' . ($list->email_verified ? '<i class="flaticon2-correct text-success icon-md"></i>' : '' ) . '</a>
			                            </div>
			                        </div>',
                'mobile' => $list->mobile . ' ' . ($list->mobile_verified ? '<i class="flaticon2-correct text-success icon-md"></i>' : '' ),
                'balance' => $list->balance,
                'ac_no' => $list->ac_no,
                'ifsc' => $list->ifsc,
                //	'role'       	=> User_role::getValue($list->role),
//                'user_status' => ((isset($list->user_status) && $list->user_status == User_status::INACTIVE ? '<span id="us-' . $list->user_id . '" class="btn btn-link-danger font-weight-bold status_btn" data-id="' . $list->user_id . '" data-table="user_master" data-row="user_id" data-status="' . User_status::ACTIVE . '" data-value="Active" title="User Status"> ' . User_status::getValue($list->user_status) . ' </span>' : '<span id="us-' . $list->user_id . '" class="btn btn-link-info label-inline mr-2 font-weight-bold status_btn" data-id="' . $list->user_id . '" data-table="user_master" data-row="user_id" data-status="' . User_status::INACTIVE . '" data-value="Inactive" title="User Status"> ' . User_status::getValue($list->user_status) . ' </span>' )),
                'created_on' => '<span class="btn btn-link-info font-weight-bold">' . ($list->created_on ? date('d M Y H:i', $list->created_on) : '') . '</span>',
                'action' => '<a href="' . ROOT_URL . 'console/user/edit/' . $list->user_id . '" class="btn btn-sm btn-clean btn-icon mr-2" title="Edit"> <i class="flaticon-edit text-success"></i> </a>'
//					
            );
        endforeach;

        ## Response
        $response = array(
            'draw' => intval($draw),
            'iTotalRecords' => $totalRecords,
            'iTotalDisplayRecords' => $totalRecordwithFilter,
            'aaData' => $data
        );

        return $response;
    }

    function get_quesstions() {
        $this->db->select('*');
        $this->db->from(TBL_QUESTIONS);
        $this->db->where('is_deleted', Deleted_status::NOT_DELETED);
        return $this->db->get()->result();
    }

    function get_scoreboard($post = null) {
        $response = array();

        ## Read value
        $draw = $post['draw'];
        $start = $post['start'];
        $rowPerPage = $post['length'];
        $columnIndex = $post['order'][0]['column'];
        $columnName = $post['columns'][$columnIndex]['data'];
        $columnSortOrder = $post['order'][0]['dir'];
        $searchValue = $post['search']['value'];

        // Custom search filter 
        $name = $post['name'];
        $mobile = $post['mobile'];
        $status = $post['status'];

        ## Search 
        $search_arr = array();
        $searchQuery = "";
        if ($searchValue != '') {
            $search_arr[] = " (
	    	u.first_name like '%" . $searchValue . "%' or 
	    	u.mobile like '%" . $searchValue . "%' ) ";
        }

        if (count($search_arr) > 0) {
            $searchQuery = implode(" and ", $search_arr);
        }

        ## Total number of records without filtering
        $this->db->from(TBL_USERS . ' u');
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED, 'u.role' => User_role::MEMBER));

        if ($searchQuery != '') {
            $this->db->where($searchQuery);
            $totalRecordwithFilter = $this->db->count_all_results();

            ## Total number of records without filtering
            $this->db->from(TBL_USERS);
            $this->db->where(array('user_deleted' => Deleted_status::NOT_DELETED, 'role' => User_role::MEMBER));
            $totalRecords = $this->db->count_all_results();
        } else {
            $totalRecords = $this->db->count_all_results();
            $totalRecordwithFilter = $totalRecords;
        }

        ## Fetch records
        $this->db->select('u.user_id, u.first_name, u.last_name');
        $this->db->from(TBL_USERS . ' u');
        //	$this->db->join(TBL_SUBSCRIPTION . ' s', 's.user_id = u.user_id AND s.status = '. Status::ACTIVE .' AND s.type = '. Subscription_type::VIEW, 'left');
        //	$this->db->join(TBL_PACKAGE . ' p', 'p.package_id = s.package_id', 'left');
        if ($searchQuery != '')
            $this->db->where($searchQuery);
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED, 'u.role' => User_role::MEMBER));
        $this->db->order_by('u.user_id', 'desc');
        $this->db->group_by('u.user_id');
        $this->db->limit($rowPerPage, $start);
        $records = $this->db->get()->result();

        $data = array();

        foreach ($records as $list) :
            $this->db->select('point');
            $this->db->from('fs_question_answer');
            $this->db->where('user_id', $list->user_id);
            $answers = $this->db->get()->result();

            $user_array = array();
            $user_array['user_id'] = $list->user_id;
            $user_array['name'] = toPropercase($list->first_name . ' ' . $list->last_name);
            $total_point = '';
            if (!empty($answers)) {

                foreach ($answers as $key => $ans) {
                    $user_array['Q' . ($key + 1)] = $ans->point;
                    $total_point += $ans->point;
                }
            } else {

                for ($x = 1; $x <= 10; $x++) {
                    $user_array['Q' . ($x)] = '';
                }
            }
            $user_array['total'] = '';
            $user_array['time'] = $total_point;
            $data[] = $user_array;


        endforeach;

        ## Response
        $response = array(
            'draw' => intval($draw),
            'iTotalRecords' => $totalRecords,
            'iTotalDisplayRecords' => $totalRecordwithFilter,
            'aaData' => $data
        );

        return $response;
    }

    function get_colors($post = null) {
        $response = array();

        ## Read value
        $draw = $post['draw'];
        $start = $post['start'];
        $rowPerPage = $post['length'];
        $columnIndex = $post['order'][0]['column'];
        $columnName = $post['columns'][$columnIndex]['data'];
        $columnSortOrder = $post['order'][0]['dir'];
        $searchValue = $post['search']['value'];

        // Custom search filter 
        $name = $post['name'];
        $mobile = $post['mobile'];
        $status = $post['status'];

        ## Search 
        $search_arr = array();
        $searchQuery = "";
        if ($searchValue != '') {
            $search_arr[] = " (
	    	name like '%" . $searchValue . "%') ";
        }

        if (count($search_arr) > 0) {
            $searchQuery = implode(" and ", $search_arr);
        }

        ## Total number of records without filtering
        $this->db->from(TBL_COLORS . ' u');
        $this->db->where(array('u.is_deleted' => Deleted_status::NOT_DELETED));

        if ($searchQuery != '') {
            $this->db->where($searchQuery);
            $totalRecordwithFilter = $this->db->count_all_results();

            ## Total number of records without filtering
            $this->db->from(TBL_COLORS . ' u');
            $this->db->where(array('u.is_deleted' => Deleted_status::NOT_DELETED));
            $totalRecords = $this->db->count_all_results();
        } else {
            $totalRecords = $this->db->count_all_results();
            $totalRecordwithFilter = $totalRecords;
        }

        ## Fetch records
        $this->db->select('u.id, u.name, u.platform_charge');
        $this->db->from(TBL_COLORS . ' u');
        //	$this->db->join(TBL_SUBSCRIPTION . ' s', 's.user_id = u.user_id AND s.status = '. Status::ACTIVE .' AND s.type = '. Subscription_type::VIEW, 'left');
        //	$this->db->join(TBL_PACKAGE . ' p', 'p.package_id = s.package_id', 'left');
        if ($searchQuery != '')
            
        $this->db->where($searchQuery);
        $this->db->where(array('u.is_deleted' => Deleted_status::NOT_DELETED));
        $this->db->limit($rowPerPage, $start);
        $records = $this->db->get()->result();

        $data = array();

        foreach ($records as $list) :


            $array = array();
            $array['id'] = $list->id;
            $array['name'] = toPropercase($list->name);
//            $array['platform_charge'] = $list->platform_charge;
//            $array['status'] = ((isset($list->user_status) && $list->user_status == User_status::INACTIVE ? '<span id="us-' . $list->user_id . '" class="btn btn-link-danger font-weight-bold status_btn" data-id="' . $list->user_id . '" data-table="user_master" data-row="user_id" data-status="' . User_status::ACTIVE . '" data-value="Active" title="User Status"> ' . User_status::getValue($list->user_status) . ' </span>' : '<span id="us-' . $list->user_id . '" class="btn btn-link-info label-inline mr-2 font-weight-bold status_btn" data-id="' . $list->user_id . '" data-table="user_master" data-row="user_id" data-status="' . User_status::INACTIVE . '" data-value="Inactive" title="User Status"> ' . User_status::getValue($list->user_status) . ' </span>' ));
//            $array['action'] = '<a href="javascript:;" data-id="' . $list->user_id . '" data-table="' . TBL_COLORS . '" data-row="user_id" class="btn btn-sm btn-clean btn-icon mr-2 delete_btn" title="Delete"> <i class="far fa-trash-alt text-danger"></i> </a>';
//            $array['action'] = '';


            $data[] = $array;


        endforeach;

        ## Response
        $response = array(
            'draw' => intval($draw),
            'iTotalRecords' => $totalRecords,
            'iTotalDisplayRecords' => $totalRecordwithFilter,
            'aaData' => $data
        );

        return $response;
    }

    function get_leaderboard($id) {
        $this->db->select('u.user_id,u.first_name');
        $this->db->from(TBL_USERS . ' u');
        $this->db->where(array('u.user_deleted' => Deleted_status::NOT_DELETED, 'u.session_id' => $id, 'u.role' => User_role::MEMBER));
//	    $this->db->order_by('u.user_id', 'desc');
        $records = $this->db->get()->result();

        foreach ($records as $kye1 => $list) :
            $this->db->select('point,created_at');
            $this->db->from('fs_question_answer');
            $this->db->where('user_id', $list->user_id);
            $answers = $this->db->get()->result();

            $total_point = 0;
            $total_time = 0;
            if (!empty($answers)) {

                foreach ($answers as $key => $ans) {
                    $ky = 'Q' . ($key + 1);
                    $records[$kye1]->$ky = $ans->point;
                    $total_point += $ans->point;
                    $total_time += $ans->created_at;
                }

                $time_1 = $answers[0]->created_at;
                $last_ele = end($answers);
                $time_2 = $last_ele->created_at;

                $records[$kye1]->time = timePassed($time_1, $time_2);
            } else {

                for ($x = 1; $x <= 10; $x++) {
                    $ky = 'Q' . ($x);
                    $records[$kye1]->$ky = '';
                }

                $records[$kye1]->time = 0;
            }
            $records[$kye1]->total = $total_point;
            /* if ($total_time != 0) {
              $records[$kye1]->time = round(($total_time % 3600) / 60).'sec';
              } else {
              $records[$kye1]->time = 0;
              } */
            /* if (!empty($answers)) {

              $time_1 = $answers[0]->created_at;
              $last_ele = end($answers);
              $time_2 = $last_ele->created_at;

              $records[$kye1]->time = timePassed($time_1, $time_2);
              } else {
              $records[$kye1]->time = 0;
              } */


        endforeach;


        return $records;
    }

    function get_questions() {
        $this->db->select('*');
        $this->db->from('fs_questions');
        $this->db->order_by('question_id', 'asc');
        return $this->db->get()->result();
    }

    function get_all_session() {
        $this->db->select('*');
        $this->db->from(TBL_SESSION);
        $this->db->order_by('session_id', 'asc');
        return $this->db->get()->result();
    }

    public function add_batch($table, $data) {
        if ($this->db->insert_batch($table, $data)) {
            return $this->db->insert_id();
        }
    }

}

/* end of user model */