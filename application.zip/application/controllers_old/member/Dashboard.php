<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

    function __construct() {

        parent::__construct();



        // tables
//		$this->tbl_question     = 		TBL_QUESTIONS;
//		$this->tbl_media 		= 		TBL_MEDIA;
//		$this->tbl_topic 		= 		TBL_TOPIC;



        $this->load->model(
                array(
                    'general_model',
                )
        );
    }

    function index() {

        $title = 'Dashboard';

        $this->content->_games = $this->general_model->get_games();

//                $this->content->_games = $this->general_model->get_draw();

        $this->db->select('*');

        $this->db->from('wp_draw_master');

        $this->db->where('is_active', 0);
        
        $this->db->where('start_time >',date('Y-m-d').' 00:00:00');
        
        $this->db->where('end_time <',date('Y-m-d').' 23:59:59');

        $this->db->order_by('id', 'desc');

        $data = $this->db->get()->result();
        

        $this->db->select('*');

        $this->db->from('wp_draw_master');

        $this->db->where('is_active', 1);

        $this->db->order_by('id', 'desc');

        $active_data = $this->db->get()->row();
        
        $this->db->select('wp_betted_transaction.*,wp_draw_master.draw_name');

        $this->db->from('wp_betted_transaction');
        
        $this->db->join('wp_draw_master','wp_draw_master.id = wp_betted_transaction.active_game_id');

        $this->db->where('user_id', $this->session->userdata('user_id'));
        
        $this->db->order_by('id', 'desc');

        $data_profile_tran = $this->db->get()->result();

        $this->content->data_profile_tran = $data_profile_tran;
        
        $current_time = date('Y-m-d H:i:s');
        $time2 = new DateTime($active_data->end_time);
        $time1 = new DateTime($current_time);
        $timediff = $time1->diff($time2);
        $timediffrence = $timediff->format('%i : %s');
        $diffInSeconds = $timediff->s;
        
        $this->content->timer = $timediffrence;
        $this->content->tot_seconds = $time2->getTimestamp() - $time1->getTimestamp();

//        echo json_encode(array('draw' => $active_data->draw_name, 'timer' => $timediffrence, 'tot_seconds' =>
//        $time2->getTimestamp() - $time1->getTimestamp()));



        $this->db->select('*');

        $this->db->from('wp_user_master');

        $this->db->where('user_id', $this->session->userdata('user_id'));

        $data_profile = $this->db->get()->row();

        $this->content->data_profile = $data_profile;

        $this->content->_data = $data;
        $this->content->active_data = $active_data;
        
        
        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('type',1);
        $color_array = $this->db->get()->result();
        
        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('type',2);
        $number_array = $this->db->get()->result();
        
        
        $this->content->title   = $title;
        $this->content->number = array_column($number_array, 'name', 'id');
        $this->content->color = array_column($color_array, 'color_code', 'id');

        $this->load_view('dashboard_view', $title);
    }

    public function recharge() {
        $this->db->select('*');

        $this->db->from('wp_user_master');

        $this->db->where('user_id', $this->session->userdata('user_id'));

        $data_profile = $this->db->get()->row();

        $this->content->data_profile = $data_profile;
        
        $this->load_view('recharge', $title);
    }
    
    public function transactions() {
        $title = 'Transactions';
        
        $this->db->select('wp_betted_transaction.*,wp_draw_master.draw_name');

        $this->db->from('wp_betted_transaction');
        
        $this->db->join('wp_draw_master','wp_draw_master.id = wp_betted_transaction.active_game_id');

        $this->db->where('user_id', $this->session->userdata('user_id'));
        
        $this->db->order_by('id', 'desc');

        $data_profile = $this->db->get()->result();

        $this->content->data_profile = $data_profile;
        
        $this->load_view('transactions', $title);
    }
    
    public function commisssion() {
        $title = 'Commisssion';
        
//        $this->db->select('*');
//
//        $this->db->from('wp_ref_bonus');
//
//        $this->db->where('user_id', $this->session->userdata('user_id'));
//        
//        $this->db->order_by('id', 'desc');
//
//        $data_profile = $this->db->get()->result();
        
        $this->db->select('SUM(wp_ref_bonus.amount) as tot_level_3,wp_user_master.first_name');
        $this->db->from('wp_ref_bonus');
        $this->db->join('wp_betted_transaction','wp_betted_transaction.id = wp_ref_bonus.t_id');
        $this->db->join('wp_user_master','wp_user_master.user_id = wp_ref_bonus.user_id');
        $this->db->where('wp_ref_bonus.level', 3);
        $this->db->where('wp_ref_bonus.user_id', $this->session->userdata('user_id'));
        $this->db->order_by('wp_ref_bonus.id', 'desc');
        $data_profile_3 = $this->db->get()->result();
        
        $this->db->select('SUM(wp_ref_bonus.amount) as tot_level_2,wp_user_master.first_name');
        $this->db->from('wp_ref_bonus');
        $this->db->join('wp_betted_transaction','wp_betted_transaction.id = wp_ref_bonus.t_id');
        $this->db->join('wp_user_master','wp_user_master.user_id = wp_ref_bonus.user_id');
        $this->db->where('wp_ref_bonus.level', 2);
        $this->db->where('wp_ref_bonus.user_id', $this->session->userdata('user_id'));
        $this->db->order_by('wp_ref_bonus.id', 'desc');
        $data_profile_2 = $this->db->get()->result();
        
        $this->db->select('SUM(wp_ref_bonus.amount) as tot_level_1,wp_user_master.first_name');
        $this->db->from('wp_ref_bonus');
        $this->db->join('wp_betted_transaction','wp_betted_transaction.id = wp_ref_bonus.t_id','left');
        $this->db->join('wp_user_master','wp_user_master.user_id = wp_ref_bonus.user_id','left');
        $this->db->where('wp_ref_bonus.level', 1);
        $this->db->where('wp_ref_bonus.user_id', $this->session->userdata('user_id'));
        $this->db->order_by('wp_ref_bonus.id', 'desc');
        $data_profile_1 = $this->db->get()->result();
        
//        echo $this->db->last_query();
//        print_r($data_profile_1);
        

        $this->content->data_profile3 = $data_profile_3;
        $this->content->data_profile2 = $data_profile_2;
        $this->content->data_profile1 = $data_profile_1;
        
        $this->load_view('commission', $title);
    }
    
    public function user_panel()
    {
        $title = 'User Panel';
        
        $this->db->select('*');

        $this->db->from('wp_user_master');

        $this->db->where('user_id', $this->session->userdata('user_id'));

        $data_profile = $this->db->get()->row();
        
        $this->db->select('*');

        $this->db->from('wp_user_master');

        $this->db->where('user_ref_code', $data_profile->ref_code);
        
        $this->db->limit(3);

        $data_ref = $this->db->get()->result();
        
        $this->content->data_ref = $data_ref;
        $this->content->data_profile = $data_profile;
        
//        print_r($data_profile);
        
        $this->load_view('user-panel', $title);
    }
    

    private function load_view($viewname = 'dashboard_view', $page_title) {

        $this->masterpage->setMasterPage('master_page');

        $this->masterpage->setPageTitle($page_title);

        $this->masterpage->addContentPage('member/' . $viewname, 'content', $this->content);

        $this->masterpage->show();
    }
    
    public function recharge_request()
    {
        $amount = $this->input->post('amount_selected');
        
        $this->content->amount = $amount;
        
        $this->load_view('recharge_request', $title);
    }  
    
    public function submit_balance_request()
    {
        
       $utr     = $this->input->post('utr');
       $amount  = $this->input->post('amount');
       
       $user_id = $this->session->userdata('user_id');
       
       $this->db->select('*');
       $this->db->from('wp_balance_request');
       $this->db->where('user_id',$user_id);
       $this->db->where('utr',$utr);
       $row = $this->db->get()->row();
//       echo $this->db->last_query();
//       
//       echo '<pre>';
//       print_r($row);
       
       if(!empty($row) && $row->status == 0)
       {
           echo 'pending';
           return;
       }    
       if(!empty($row) && $row->status == 1)
       {
           echo 'approved';
           return;
       }    
       
       if(empty($row))
       {        
        $i_array = array(
          'user_id'      => $user_id,  
          'amount'       => $amount,  
          'utr'          => $utr,  
          'created_at'   => date('Y-m-d h:i:s'),  
        );

        $this->db->insert('wp_balance_request',$i_array);
        echo 'true';
        return;
       }
      
    } 
    
    public function trend()
    {
        $amount = $this->input->post('amount');
        
        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('type',1);
        $color_array = $this->db->get()->result();
        
        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('type',2);
        $number_array = $this->db->get()->result();
        
        $color_count = array();
        foreach($color_array as $c)
        {
            $this->db->select('id');
            $this->db->from('wp_draw_master');
            $this->db->where('win_color',$c->id);
            $res = $this->db->get()->result();
            
            $color_count[$c->id] = count($res);
        } 
        
        $number_count = array();
        foreach($number_array as $c)
        {
            $this->db->select('id');
            $this->db->from('wp_draw_master');
            $this->db->where('win_number',$c->id);
            $res = $this->db->get()->result();
            
            $number_count[$c->id] = count($res);
        }
        
        $this->db->select('*');
        $this->db->from('wp_draw_master');
        $this->db->where('start_time >',date('Y-m-d').' 00:00:00');
        $this->db->where('end_time <',date('Y-m-d').' 23:59:59');
        $draw = $this->db->get()->result();
       
       
        $this->content->draw_count = count($draw);
        $this->content->color_count = $color_count;
        $this->content->number_count = $number_count;
        $this->content->color_array = $color_array;
        $this->content->number_array = $number_array;
        
        $this->load_view('trend', $title);
    }
    
    
     public function bankAccount() {
         
        $title = 'Bank Account' ;
        
        $this->db->select('*');

        $this->db->from('wp_user_master');

        $this->db->where('user_id', $this->session->userdata('user_id'));

        $data_profile = $this->db->get()->row();


        $this->content->data_profile = $data_profile;
        
        $this->load_view('bankAccount', $title);
        
    }
    
    public function saveAccount()
    {
        
        $this->db->where('user_id',$this->input->post('user_id'));
        $this->db->set('ac_no',$this->input->post('ac_no'));
        $this->db->set('ifsc',$this->input->post('ifsc'));
        $this->db->set('ac_name',$this->input->post('ac_name'));
        $this->db->update('wp_user_master');
        header('Location: '.base_url('member/dashboard/bankAccount'));
        exit;
    }
    public function savewithdrawlRequest()
    {
        $this->db->where('user_id',$this->session->userdata('user_id'));
        $this->db->set('balance','balance -'.$this->input->post('amount'),False);
        $this->db->update('wp_user_master');
        
        $this->db->select('*');
        $this->db->from('wp_settings');
        $this->db->where('type','withdrawl');
        $charge_res = $this->db->get()->row();
        
        $charge_per = $charge_res->charge;
        $amount = $this->input->post('amount');
        $withdraw_charge = ($amount * $charge_per)/100;
        
        $i_array = array(
            'user_id' => $this->session->userdata('user_id'),
            'amount' => round($amount - $withdraw_charge),
            'w_charge' => round($withdraw_charge),
            'created_at' => date('Y-m-d H:i:s'),
        );
        $this->db->insert('wp_withdrawl_request',$i_array);
        header('Location: '.base_url('member/dashboard/withdrawlRequest'));
        exit;
    }
    
    public function withdrawlRequest()
    {
        $title = 'Withdrawl' ;
        
        $this->db->select('*');

        $this->db->from('wp_withdrawl_request');

        $this->db->where('user_id', $this->session->userdata('user_id'));

        $data_request = $this->db->get()->result();
        
        $this->db->select('*');

        $this->db->from('wp_user_master');

        $this->db->where('user_id', $this->session->userdata('user_id'));

        $data_profile = $this->db->get()->row();


        $this->content->data_profile = $data_profile;
        $this->content->data_request = $data_request;
        
        $this->load_view('withdrawlRequest', $title);
        
    }
            
             

}

/* end of dashboard */