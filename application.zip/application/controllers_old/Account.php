<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends MY_Controller {

    function __construct() {

        parent::__construct();
    }

    function index() {

        $this->login();
    }

    function login() {

        /** page level css & js * */
        $this->content->extra_css = array('login');

        $this->content->extra_js = array('login-general');

        $this->load->model('account_model');

        $user_role = $this->session->userdata('user_role');

        $user_id = $this->session->userdata('user_id');

        if ($this->session->userdata('user_id')) {

            if (!empty($user_role) && $user_role == User_role::SUPER_ADMIN) {

                redirect('console/dashboard', 'refresh');
            } else if (!empty($user_role) && $user_role == User_role::CLIENT) {



                redirect('member/dashboard', 'refresh');
            } else if (!empty($user_role) && $user_role == User_role::MEMBER) {

                redirect('member/dashboard', 'refresh');
            }
        }

        $this->load_view('login_view', 'Login');
    }

    function otp_login($ref_code = '') {

        /** page level css & js * */
        $this->content->extra_css = array('login');

        //	$this->content->extra_js  = array('');



        $this->load->model('account_model');

        $user_role = $this->session->userdata('user_role');

        $user_id = $this->session->userdata('user_id');

        $roles = array(
            User_role::CLIENT,
        );

        if ($this->session->userdata('user_id')) {



            if (!empty($user_role) && in_array($user_role, $roles)) {

                redirect('console/dashboard', 'refresh');
            }
        }

        $this->content->ref_code = $ref_code;

        $this->load_view('otp_login', 'Login');
    }

    function forget_password() {
        $this->content->extra_css = array('login');
        $this->load_view('forget_password', 'Forget Password');
    }

    function update_password() {
        
    }

    function ajax_login() {
        if ($this->input->is_ajax_request()) {

            $this->load->library('form_validation');

            if ($this->form_validation->run('login_form') == FALSE) {

                echo json_encode($this->form_validation->error_array());

                exit;
            }

            $status = 'success';

            $error_type = '';

            $post = $this->input->post();

            $login_id = $post['email_id'];

            if (isset($post['action'])) {

                $password = $post['password'];
            } else {

                $password = $this->hash_password($post['password']);
            }

            $this->load->model('account_model');

            $user_data = $this->account_model->get_user_data_by_login_id($login_id);
//            echo $this->db->last_query();

            if (!empty($user_data)) {

                /* if($user_data->role == User_role::MEMBER && $user_data->is_login_rights == 0) {

                  $status = 'fail';

                  $error_type = 'no_login_rights';

                  } else */ if ($user_data->user_status == User_status::ACTIVE) {

                    if ($user_data->password == $password) {

                        $ipaddress = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'UNKNOWN';

                        if ($this->account_model->update_login_data($user_data->user_id, $ipaddress)) {

                            /* to do

                             *  for trainers and members add access token and athlete id.

                             */

                            $session_data = array(
                                'user_id' => $user_data->user_id,
                                'user_role' => $user_data->role,
                                'user_name' => toProperCase($user_data->first_name . ' ' . $user_data->last_name),
                                'email' => $user_data->email,
                                'balance' => $user_data->balance,
                            );

                            $this->session->set_userdata($session_data);
                        } else {

                            $status = 'fail';

                            $error_type = 'database';
                        }
                    } else {

                        $status = 'error';

                        $error_type = 'password';
                    }
                } else if ($user_data->user_status == User_status::DEACTIVATED) {

                    $status = 'fail';

                    $error_type = 'deactivated';
                } else if ($user_data->user_status == User_status::INACTIVE) {

                    $status = 'fail';

                    $error_type = 'inactive';
                }
            } else {

                $status = 'error';

                $error_type = 'login';
            }

            echo json_encode(array('status' => $status, 'error_type' => $error_type));
        } else {
            echo 'came';
//            show_400();
        }
    }

    function submit_otp_form() {

        if ($this->input->is_ajax_request()) {
            $this->load->model('account_model');

            $this->load->model('user_model');

            if ($this->form_validation->run('otp_login_form') == FALSE) {

                echo json_encode($this->form_validation->error_array());

                exit;
            }



            $status = 'success';

            $error_type = '';

            $post = $this->input->post();

            $mobile_no = $post['mobile_no'];

            $name = $post['name'];

            $email = $post['email'];

            $password = $post['password'];

            $app['first_name'] = strtolower($name);

            $app['user_ref_code'] = $post['user_ref_code'];

            $app['mobile'] = trim($mobile_no);

//            $app['email']       = $email;    

            $app['user_status'] = 1;

            $app['created_on'] = time();

            $app['password'] = $this->hash_password($password);

            $app['role'] = User_role::MEMBER;

            $user_data = $this->account_model->get_user_data_by_login_id($app['mobile']);

            if (empty($user_data)) {
                $user_id = $this->user_model->add_data(TBL_USERS, $app);

                $ref_code = substr(strtoupper($app['first_name']), 0, 4) . $user_id;

                $this->db->where('user_id', $user_id);
                $this->db->set('ref_code', $ref_code);
                $this->db->update('wp_user_master');

                if ($user_id) {

                    echo json_encode(array('status' => $status, 'error_type' => $error_type));
                }
            } else {
                echo json_encode(array('status' => 'error', 'error_type' => ''));
            }
        } else {

            echo 'came';

            show_400();
        }
    }

    function register_mobile() {
        $mobile_number = $this->input->post('mobile_number');
        $otp = random_int(100000, 999999);

        $this->db->select('*');
        $this->db->from('wp_registered_mobile');
        $this->db->where('mobile', $mobile_number);
        $per = $this->db->get()->row();
//        echo $this->db->last_query();
        if (!empty($per)) {
            echo 'duplicate';
            return;
        }

        $insert_array = array(
            'mobile' => $mobile_number,
            'otp' => $otp,
        );
        $this->db->insert('wp_registered_mobile', $insert_array);

        $message = 'Your otp verification code is ' . $otp;

        $url = "https://www.smsidea.co.in/smsstatuswithid.aspx";
//        $message = 'test';
        $fields = array(
            'mobile' => '7990086898',
            'pass' => '123456',
            'senderid' => 'TSTMSG',
            'to' => '91' . $mobile_number,
            'msg' => urlencode($message)
        );
//url-ify the data for the POST
        foreach ($fields as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        rtrim($fields_string, '&');
//open connection
        $ch = curl_init();
//set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
//execute post
        $result = curl_exec($ch);
//close connection
        curl_close($ch);

        echo json_encode(array('status' => 'success', 'error_type' => ''));
    }

    function forget_password_otp() {
        $mobile_number = $this->input->post('mobile_number');
        $otp = random_int(100000, 999999);

        $message = 'Your otp verification code for forget password is ' . $otp;

        $this->db->where('mobile', $mobile_number);
        $this->db->set('otp_no', $otp);
        $this->db->update('wp_user_master');

        $url = "https://www.smsidea.co.in/smsstatuswithid.aspx";
//        $message = 'test';
        $fields = array(
            'mobile' => '7990086898',
            'pass' => '123456',
            'senderid' => 'TSTMSG',
            'to' => '91' . $mobile_number,
            'msg' => urlencode($message)
        );
//url-ify the data for the POST
        foreach ($fields as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        rtrim($fields_string, '&');
//open connection
        $ch = curl_init();
//set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
//execute post
        $result = curl_exec($ch);
//close connection
        curl_close($ch);

        echo json_encode(array('status' => 'success', 'error_type' => ''));
    }

    function check_otp() {
        $mobile_number = $this->input->post('mobile_number');
        $otp = $this->input->post('otp_no');

        $this->db->select('*');
        $this->db->from('wp_registered_mobile');
        $this->db->where('mobile', $mobile_number);
        $this->db->where('otp', $otp);
        $record = $this->db->get()->row();
        if (!empty($record)) {
            $this->db->where('mobile', $mobile_number);
            $this->db->where('otp', $otp);
            $this->db->set('status', 1);
            $this->db->update('wp_registered_mobile');

            echo 'true';
        } else {
            echo 'false';
        }
    }

    function check_forget_password_otp() {
        $mobile_number = $this->input->post('mobile_number');
        $otp = $this->input->post('otp_no');

        $this->db->select('*');
        $this->db->from('wp_user_master');
        $this->db->where('mobile', $mobile_number);
        $this->db->where('otp_no', $otp);
        $record = $this->db->get()->row();

        if (!empty($record)) {
            $this->db->where('mobile', $mobile_number);
            $this->db->where('otp', $otp);
            $this->db->set('status', 1);
            $this->db->update('wp_registered_mobile');

            echo 'true';
        } else {
            echo 'false';
        }
    }

    function change_password() {
        $password = $this->input->post('password');
        $mobile_no = $this->input->post('mobile_no');

        $password = $this->hash_password($password);

        $this->db->where('mobile', $mobile_no);
        $this->db->set('password', $password);
        $this->db->update('wp_user_master');
        $this->load->model('account_model');
        $user_data = $this->account_model->get_user_data_by_login_id($mobile_no);

        $session_data = array(
            'user_id' => $user_data->user_id,
            'user_role' => $user_data->role,
            'user_name' => toProperCase($user_data->first_name . ' ' . $user_data->last_name),
            'email' => $user_data->email,
            'balance' => $user_data->balance,
        );

        $this->session->set_userdata($session_data);
        echo json_encode(array('status' => 'success', 'error_type' => ''));
    }

    /*

      function ajax_forgot_password() {

      if($this->input->is_ajax_request())

      {

      $this->load->library('form_validation');

      if ($this->form_validation->run('forgot_password_form') == FALSE)

      {

      echo json_encode($this->form_validation->error_array());

      exit;

      }

      $status = 'success';

      $error_type = '';

      $email = $this->input->post('email');

      $this->load->model('account_model');

      $user_data = $this->account_model->get_table_data_row('user_master', array('email' => $email, 'user_deleted' => Deleted_status::NOT_DELETED));



      if( ! empty($user_data))

      {

      if($user_data->user_status == User_status::ACTIVE)

      {

      $reset_code = md5($email.time());

      $this->load->model('verification_model');

      if($this->verification_model->add_password_reset_code($user_data->user_id,$reset_code))

      {

      if( ! $this->_send_reset_link($user_data,$reset_code,'reset_password'))

      {

      $status = 'fail';

      $error_type = 'mail';

      }

      }

      else

      {

      $status = 'fail';

      $error_type = 'database';

      }

      }

      else if($user_data->user_status == User_status::DEACTIVATED)

      {

      $status = 'fail';

      $error_type = 'deactivated';

      }

      else if($user_data->user_status == User_status::INACTIVE)

      {

      $status = 'fail';

      $error_type = 'inactive';

      }

      }

      else

      {

      $status = 'error';

      $error_type = 'email';

      }

      echo json_encode(array('status' => $status, 'error_type' => $error_type));

      }

      else

      {

      show_400();

      }

      }



      function reset_password() {

      $reset_code = $this->uri->segment(3);

      $this->content->reset_code = $reset_code;

      if($this->session->userdata('user_id')) {

      redirect('dashboard','refresh');

      } else if($reset_code == '') {

      redirect('','refresh');

      }



      $this->load->model('verification_model');

      $code_data = $this->verification_model->get_data_by_reset_code($reset_code);

      if(empty($code_data)) {

      show_404_page();

      }

      if($code_data) {

      $expire_time = $code_data->created_on + (30*60);

      if( ! ($expire_time > time())) {

      show_410('Link Expired !');

      }

      } else {

      show_404_page();

      }

      $this->load_view('reset_password_view','Reset Password');

      }



      function set_password() {

      $reset_code = $this->uri->segment(3);

      $this->content->reset_code = $reset_code;

      if($this->session->userdata('user_id')) {

      redirect('account','refresh');

      } else if($reset_code == '') {

      redirect('','refresh');

      }



      $this->load->model('verification_model');

      $code_data = $this->verification_model->get_data_by_reset_code($reset_code);

      if(empty($code_data)) {

      show_404_page();

      }



      if($code_data) {

      $expire_time = $code_data->created_on + (30*60);

      if( ! ($expire_time > time()))

      {

      show_410('Link Expired !');

      }

      } else {

      show_404_page();

      }

      $this->load_view('set_password_view','Create Password');

      }



      function ajax_register_user() {

      if($this->input->is_ajax_request())

      {

      $this->load->library('form_validation');



      if ($this->form_validation->run('registration-form') == FALSE)

      {

      echo json_encode($this->form_validation->error_array());

      exit;

      }



      $post = $this->input->post();



      $this->load->model('account_model');



      $user = new Register_user_entity();

      $user->first_name 	= $post['firstname'];

      $user->last_name 	= $post['lastname'];

      $user->mobile 		= $post['contact'];

      $user->landline 	= $post['landline'];

      $user->email 		= $post['email'];

      $user->password 	= $this->hash_password($post['password']);

      $user_id 			= $this->account_model->register_user($user);



      $client = new Register_client_entity();

      $client->user_id  	= $user_id;

      $client->user_type 	= $post['user_type'];



      $client_id = $this->account_model->register_client($client);



      if($user_id && $client_id)

      {

      $session_data = array(

      'user_id' 	=> $user_id,

      'client_id' => $client_id,

      'user_type' => $post['user_type'],

      'user_role' => User_role::MEMBER,

      'user_name' => toProperCase($post['firstname'] .' '. $post['lastname']),

      'email' 	=> $post['email'],

      'mobile' 	=> $post['contact']

      );

      $this->session->set_userdata($session_data);



      echo json_encode(array('status' => 'success', 'user_id' => $user_id));

      }

      }

      else

      {

      show_400();

      }

      }



      function ajax_reset_password() {

      if($this->input->is_ajax_request())

      {

      $this->load->library('form_validation');

      if ($this->form_validation->run('reset_password_form') == FALSE)

      {

      echo json_encode($this->form_validation->error_array());

      exit;

      }

      $post = $this->input->post();

      $this->load->model('verification_model');

      $new_password = $this->hash_password($post['new_password']);

      $reset_code = $post['reset_code'];



      $code_data = $this->verification_model->get_data_by_reset_code($reset_code);

      if($code_data)

      {

      //xdebug($code_data);

      if($this->verification_model->reset_password($code_data->user_id, $reset_code,$new_password))

      {

      $this->load->model('user_model');

      $login_data = $this->user_model->get_user_detail_userid($code_data->user_id);

      echo json_encode(array('status'=>'success', 'source' => $login_data->source, 'setup' => $login_data->setup_flag, 'user_id' => $login_data->user_id));

      }

      }

      }

      else

      {

      show_400();

      }

      }



      private function _send_register_mail($user) {

      $name = toProperCase($user->first_name.' '.$user->last_name);

      $data = array(

      'name' => $name

      );



      $this->load->library('email_service');

      $email_data                = new Send_email_options();

      $email_data->email_to      = $user->email;

      $email_data->email_subject = BASENAME . ' | Welcome';

      $email_data->template      = 'register_account';

      $email_data->data          = $data;



      if($this->email_service->send_email($email_data)) {

      return TRUE;

      }

      return FALSE;

      }



      private function _send_admin_register_mail($user,$source,$city) {

      $name = toProperCase($user->first_name.' '.$user->last_name);

      $data = array(

      'name'   => $name,

      'mobile' => $user->mobile,

      'email'  => $user->email,

      'city'   => $city,

      'source' => $source,

      );



      $this->load->library('email_service');

      $email_data = new Send_email_options();

      if(ENVIRONMENT == 'developers' || ENVIRONMENT == 'development') {

      $email_data->email_to = '';

      }

      if(ENVIRONMENT == 'testing') {

      $email_data->email_to = '';

      }

      if(ENVIRONMENT == 'production') {

      $email_data->email_to = '';

      }

      $email_data->email_subject = BASENAME . ' | Member Details';

      $email_data->template      = 'member_register_mail_admin';

      $email_data->data          = $data;



      if($this->email_service->send_email($email_data)) {

      return TRUE;

      }

      return FALSE;

      }

     */

    function signout() {

        $this->session->sess_destroy();

        redirect('account', 'refresh');
    }

    function secondsToTime($seconds) {

        $dtF = new DateTime("@0");

        $dtT = new DateTime("@$seconds");

        return $dtF->diff($dtT)->format('%a');
    }

    private function load_view($viewname = 'login_view', $page_title) {

        $this->masterpage->setMasterPage('login_master_page');

        $this->masterpage->setPageTitle($page_title);

        $this->masterpage->addContentPage('account/' . $viewname, 'content', $this->content);

        $this->masterpage->show();
    }

    function generateDraw() {


        $this->db->set('is_active', 0);

        $this->db->update('wp_draw_master');

        $minutes_to_add = 3;

        $time = new DateTime(date('Y-m-d h:i:s'));

        $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));

        $stamp = $time->format('Y-m-d H:i');

        $completed_time = date("Y-m-d H:i:s", strtotime("+3 minutes"));

        $this->db->select('*');
        $this->db->from('wp_day_count');
        $this->db->where('draw_date', date('Y-m-d'));
        $day_row = $this->db->get()->row();

        if (empty($day_row)) {
            $day_array = array(
                'draw_date' => date('Y-m-d'),
                'number' => 1,
            );
            $this->db->insert('wp_day_count', $day_array);
            $draw_name = date("Ymd") . '1';
        } else {

            $draw_no = $day_row->number + 1;
            $draw_name = date("Ymd") . $draw_no;

            $this->db->where('draw_date', date('Y-m-d'));
            $this->db->set('number', $draw_no);
            $this->db->update('wp_day_count');
        }


        $draw_array = array(
            'draw_name' => $draw_name,
            'start_time' => date('Y-m-d H:i:s'),
            'end_time' => $completed_time,
            'is_active' => 1,
        );

        $this->db->insert('wp_draw_master', $draw_array);

        $last_id = $this->db->insert_id();

        $sub_array = array(
            'draw_id' => $last_id,
            'completed_time' => $completed_time,
        );

        $this->db->insert('wp_draw_result', $sub_array);

        sleep(155);

        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_id);
        $this->db->where_in('game_id', array(1, 2, 3));
        $color_draw = $this->db->get()->result();
        $n1 = 0;
        $n2 = 0;
        $n3 = 0;
        $is_color_won = 0;
        if (!empty($color_draw)) {
            foreach ($color_draw as $d) {
                if ($d->game_id == 1) {
                    $n1 += $d->betted_amount;
                }
                if ($d->game_id == 2) {
                    $n2 += $d->betted_amount;
                }
                if ($d->game_id == 3) {
                    $n3 += $d->betted_amount;
                }
            }
            $lowest_color_array = array(
                '1' => $n1,
                '2' => $n2,
                '3' => $n3,
            );

            $lowest_color_array = array_diff($lowest_color_array, [0]);
            $color_win = array_keys($lowest_color_array, min($lowest_color_array));
            $colr_key = $color_win[0];
            $is_color_won = 1;
        } else {
            $colr_key = rand(1, 3);
        }



        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_id);
        $this->db->where_in('game_id', array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
        $number_draw = $this->db->get()->result();

        $n4 = 0;
        $n5 = 0;
        $n6 = 0;
        $n7 = 0;
        $n8 = 0;
        $n9 = 0;
        $n10 = 0;
        $n11 = 0;
        $n12 = 0;
        $n13 = 0;
        $is_number_won = 0;
        if (!empty($number_draw)) {
            foreach ($number_draw as $d) {
                if ($d->game_id == 4) {
                    $n4 += $d->betted_amount;
                }
                if ($d->game_id == 5) {
                    $n5 += $d->betted_amount;
                }
                if ($d->game_id == 6) {
                    $n6 += $d->betted_amount;
                }
                if ($d->game_id == 7) {
                    $n7 += $d->betted_amount;
                }
                if ($d->game_id == 8) {
                    $n8 += $d->betted_amount;
                }
                if ($d->game_id == 9) {
                    $n9 += $d->betted_amount;
                }
                if ($d->game_id == 10) {
                    $n10 += $d->betted_amount;
                }
                if ($d->game_id == 11) {
                    $n11 += $d->betted_amount;
                }
                if ($d->game_id == 12) {
                    $n12 += $d->betted_amount;
                }
                if ($d->game_id == 13) {
                    $n13 += $d->betted_amount;
                }
            }
            $lowest_number_array = array(
                '4' => $n4,
                '5' => $n5,
                '6' => $n6,
                '7' => $n7,
                '8' => $n8,
                '9' => $n9,
                '10' => $n10,
                '11' => $n11,
                '12' => $n12,
                '13' => $n13,
            );

            $lowest_number_array = array_diff($lowest_number_array, [0]);
            $number_win = array_keys($lowest_number_array, min($lowest_number_array));
            $number_key = $number_win[0];
            $is_number_won = 1;
        } else {
            $number_key = rand(4, 13);
        }



        $even = array(6, 8, 10, 12);
        $odd = array(5, 7, 11, 13);
//        $even = array(4, 6, 8, 10, 12);
//        $odd = array(5, 7, 9, 11, 13);

        if ($is_number_won == 1) {
            if ($colr_key == 1) {
                if (in_array($number_key, $odd)) {
                    $lvl_one_win_number = $number_key;
                } else {
                    $not_found_number_od = 0;
                    foreach ($number_win as $n) {
                        if (in_array($n, $odd)) {
                            $lvl_one_win_number = $n;
                            $not_found_number_od = 1;
                            break;
                        }
                    }
                    if ($not_found_number_od == 0) {
                        $random_keys = array_rand($odd, 1);
                        $lvl_one_win_number = $odd[$random_keys];
                    }
                }
            }

            if ($colr_key == 3) {
                if (in_array($number_key, $even)) {
                    $lvl_one_win_number = $number_key;
                } else {
                    $not_found_number_even = 0;
                    foreach ($number_win as $n) {
                        if (in_array($n, $even)) {
                            $lvl_one_win_number = $n;
                            $not_found_number_even = 1;
                            break;
                        }
                    }
                    if ($not_found_number_even == 0) {
                        $random_keys = array_rand($even, 1);
                        $lvl_one_win_number = $even[$random_keys];
                    }
                }
            }
            $is_win_color_array = 0;
            if ($colr_key == 2) {
                $is_found_second_color = 0;
                $is_win_color_array = 1;
                if (isset($color_win[1])) {
                    if ($color_win[1] == 1) {
                        $is_found_second_color = 1;
                        $win_colr_key_array = array(1, 2);
                        $colr_key = '1,2';
                        $lvl_one_win_number = 9;
                    }
                    if ($color_win[1] == 3) {
                        $is_found_second_color = 2;
                        $win_colr_key_array = array(3, 2);
                        $colr_key = '3,2';
                        $lvl_one_win_number = 4;
                    }
                }
                if ($is_found_second_color == 0) {
                    $win_colr_key_array = array(3, 2);
                    $colr_key = '3,2';
                    $lvl_one_win_number = 4;
                }
            }
        } else {
            $came_no = 0;
            echo 'bugcame='.$colr_key.'<br>';
            if ($colr_key === 2) {
                echo 'key1<br>';
                $is_win_color_array = 1;
                $win_colr_key_array = array(1, 2);
                $colr_key = '1,2';
                $lvl_one_win_number = 9;
                $came_no = 1;
            }

            if ($colr_key === 1) {
                if (in_array($number_key, $odd)) {
                     echo 'key2<br>';
                    $lvl_one_win_number = $number_key;
                    $came_no = 2;
                } else {
                     echo 'key3<br>';
                     echo '<pre>';
                     print_r($odd);
                    $random_keys = array_rand($odd, 1);
                    $lvl_one_win_number = $odd[$random_keys];
                    $came_no = 3;
                }
            }

            if ($colr_key === 3) {
                if (in_array($number_key, $even)) {
                     echo 'key4<br>';
                    $lvl_one_win_number = $number_key;
                    $came_no = 4;
                } else {
                     echo 'key5<br>';
                     
                     echo '<pre>';
                     print_r($even);
                    $random_keys = array_rand($even, 1);
                   $lvl_one_win_number = $even[$random_keys];
                    $came_no = 5;
                }
            }
            
            $bug_array = array(
              'media'  => $colr_key,
              'module'  => $came_no,
            );
            $this->db->insert('wp_media',$bug_array);
        }
        
        echo 'colr_key='.$colr_key.'<br>';
        echo 'level_ahead='.$lvl_one_win_number.'<br>';
        if ($colr_key === '1,2') {
//            echo 'cameeeeeee';
            $lvl_one_win_number = 9;
        }
        if ($colr_key === '3,2') {
            $lvl_one_win_number = 4;
        }
//         echo 'level_behind='.$lvl_one_win_number.'<br>';
        
        $lvl_one_win_color = $colr_key;
        
          echo 'colr_key='.$colr_key.'<br>';
        echo 'level_last='.$lvl_one_win_number.'<br>';
        
        $ic_combo = 0;
        if (isset($win_colr_key_array)) {
            $ic_combo = 1;
        }


        $update_array = array(
            'win_color' => $colr_key,
            'win_number' => $lvl_one_win_number,
            'is_combo' => $ic_combo,
//            'win_color_price' => $lowest_color_array[$colr_key],
//            'win_number_price' => $lowest_number_array[$number_key],
//            'win_number_name' => $number_array[$number_key],
//            'win_color_name' => $color_array[$colr_key],
        );
        $this->db->where('id', $last_id);
        $this->db->update('wp_draw_master', $update_array);
        echo $this->db->last_query();   
//        $update_array = array(
//            'win_color' => $lvl_one_win_color,
//            'win_number' => $lvl_one_win_number,
//            'win_color_price' => $lowest_color_array[$colr_key],
//            'win_number_price' => $lowest_number_array[$number_key],
//            'updated_time' => date('Y-m-d H:i:s'),
//            'is_completed' => 1,
//        );
//
//        $this->db->where('draw_id', $last_id);
//        $this->db->update('wp_draw_result', $update_array);

        $this->db->select('SUM(betted_amount) as number_sum');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_id);
        $this->db->where_in('game_id', array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
        $number_sum = $this->db->get()->row();

        $this->db->select('SUM(betted_amount) as color_sum');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_id);
        $this->db->where_in('game_id', array(1, 2, 3));
        $color_sum = $this->db->get()->row();
//        echo $colr_key;
        if ($colr_key === '1' || $colr_key === '3') {
//             echo 'came1';
            $this->db->select('*');
            $this->db->from('wp_betted_transaction');
            $this->db->where('active_game_id', $last_id);
            $this->db->where('game_id', $colr_key);
            $final_color_draw = $this->db->get()->result();
        } else {
//            echo 'came';
            $this->db->select('*');
            $this->db->from('wp_betted_transaction');
            $this->db->where('active_game_id', $last_id);
            $this->db->where_in('game_id', $win_colr_key_array);
            $final_color_draw = $this->db->get()->result();
        }
        
//        echo $this->db->last_query();
//        print_r($final_color_draw);
        
        $color_win_sum = 0;
        if (!empty($final_color_draw)) {
            if (!empty($final_color_draw)) {
                foreach ($final_color_draw as $cdraw) {

                    $this->db->select('*');
                    $this->db->from('wp_color_master');
                    $this->db->where('id', $cdraw->game_id);
                    $color_data = $this->db->get()->row();

                    $this->db->select('*');
                    $this->db->from('wp_user_master');
                    $this->db->where('user_id', $cdraw->user_id);
                    $userdrawdata = $this->db->get()->row();

                    $win_amount = $cdraw->betted_amount * $color_data->multiplied;
                    $color_win_sum += $win_amount;
                    $final_amount = $win_amount;
                }
            }
        }

        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_id);
        $this->db->where('game_id', $lvl_one_win_number);
        $final_nunmer_draw = $this->db->get()->result();

        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('id', $lvl_one_win_number);
        $color_data = $this->db->get()->row();
        $number_win_sum = 0;
        if (!empty($final_nunmer_draw)) {
            foreach ($final_nunmer_draw as $cdraw) {

                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_id', $cdraw->user_id);
                $userdrawdata = $this->db->get()->row();

                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_ref_code', $userdrawdata->ref_code);
                $this->db->limit(3);
                $all_sub = $this->db->get()->result();

                $win_amount = $cdraw->betted_amount * $color_data->multiplied;

                $number_win_sum += $win_amount;
                $final_amount = $win_amount - $reduce;
            }
        }
//        echo '<br>etst='.$color_win_sum.'----'.$color_sum->color_sum.'<br>';
        if ($color_win_sum > $color_sum->color_sum) {
            if ($colr_key === '1' || $colr_key === '3') {
                echo 'came';
                $lvl_one_win_color = '3,2';
                $colr_key = '3,2';
                $final_color_win = '3,2';
                $win_colr_key_array = array(3, 2);
                $ic_combo = 1;
            } 
            else{
//                 echo 'colorrrrdddr='.$colr_key.'<br>';
                if($colr_key == '3,2')
                {
                    $colr_key = '3,2';
                    $lvl_one_win_color = '3,2';
                    $final_color_win = '3,2';
                }    
                if($colr_key == '1,2')
                {
                    $colr_key = '1,2';
                    $lvl_one_win_color = '1,2'; 
                    $final_color_win = '1,2';
                }    
                
            }
//            else if ($lvl_one_win_color == '3,2' || $lvl_one_win_color == '1,2') {
//                $lvl_one_win_color = 1;
//                $final_color_win = 1;
//            }
        }
//        echo 'colorrrrr='.$colr_key.'<br>';
//        echo $color_win_sum.'--'.$color_sum->color_sum.'<br>';
//        
//        echo $lvl_one_win_color;
//        echo $number_win.'--'.$number_sum->number_sum;
        if ($number_win_sum > $number_sum->number_sum) {
            $number_array = array(
                '4' => '0',
                '5' => '1',
                '6' => '2',
                '7' => '3',
                '8' => '4',
                '9' => '5',
                '10' => '6',
                '11' => '7',
                '12' => '8',
                '13' => '9',
            );
            echo 'finalllllll='.$final_color_win;
            if($final_color_win === '3,2')
            {
                $number_key = 4;
                $lvl_one_win_number = $number_key;
                $final_number_win = $lvl_one_win_number;
            }
            else if($final_color_win === '1,2')
            {
                $number_key = 9;
                $lvl_one_win_number = $number_key;
                $final_number_win = $lvl_one_win_number;
            }
            else
            {
                unset($number_array[$lvl_one_win_number]);
                $random_number_array = array_rand($number_array, 1);
                $number_key = $random_number_array;
                $lvl_one_win_number = $number_key;
                $final_number_win = $lvl_one_win_number;
            }
            
        }else{
           
        }
        
       

        $update_array = array(
            'win_color' => $lvl_one_win_color,
            'win_number' => $lvl_one_win_number,
            'is_combo' => $ic_combo,
//            'win_color_price' => $lowest_color_array[$colr_key],
//            'win_number_price' => $lowest_number_array[$number_key],
//            'win_number_name' => $number_array[$number_key],
//            'win_color_name' => $color_array[$colr_key],
        );
        $this->db->where('id', $last_id);
        $this->db->update('wp_draw_master', $update_array);
        
        echo 'quer2='.$this->db->last_query();
        
        if ($lvl_one_win_color === '1' || $lvl_one_win_color === '3') {
            $this->db->select('*');
            $this->db->from('wp_betted_transaction');
            $this->db->where('active_game_id', $last_id);
            $this->db->where('game_id', $lvl_one_win_color);
            $final_color_draw = $this->db->get()->result();

            $this->db->select('*');
            $this->db->from('wp_betted_transaction');
            $this->db->where('active_game_id', $last_id);
            $this->db->where('game_id !=', $lvl_one_win_color);
            $this->db->where_not_in('game_id', array(4,5,6,7,8,9,10,11,12,13));
            $non_win_color_array = $this->db->get()->result();
        } else {
            $this->db->select('*');
            $this->db->from('wp_betted_transaction');
            $this->db->where('active_game_id', $last_id);
            $this->db->where_in('game_id', $win_colr_key_array);
            $final_color_draw = $this->db->get()->result();

            $this->db->select('*');
            $this->db->from('wp_betted_transaction');
            $this->db->where('active_game_id', $last_id);
            $this->db->where_not_in('game_id', $win_colr_key_array);
            $this->db->where_not_in('game_id', array(4,5,6,7,8,9,10,11,12,13));
            $non_win_color_array = $this->db->get()->result();
        }


        $platform_amount = 0;
        if (!empty($final_color_draw)) {
            foreach ($final_color_draw as $cdraw) {

                $this->db->select('*');
                $this->db->from('wp_color_master');
                $this->db->where('id', $cdraw->game_id);
                $color_data = $this->db->get()->row();

                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_id', $cdraw->user_id);
                $userdrawdata = $this->db->get()->row();
                //                echo 'q'.$this->db->last_query();
                //                echo '<pre>';
                //                print_r($userdrawdata);
                $level_one = array();
                $level_two = array();
                $level_three = array();
                if ($userdrawdata->user_ref_code != '' && $userdrawdata->user_ref_code != NULL && $userdrawdata->user_ref_code != 'NULL' && $userdrawdata->user_ref_code != 'null') {
                    $this->db->select('*');
                    $this->db->from('wp_user_master');
                    $this->db->where('ref_code', $userdrawdata->user_ref_code);
                    $level_one = $this->db->get()->row();

                    //                echo 'q1'.$this->db->last_query();
                    //                echo '<pre>';
                    //                print_r($level_one);
                    //                $level_one = $all_sub;

                    if (!empty($level_one) && $level_one->user_ref_code != '' && $level_one->user_ref_code != NULL && $level_one->user_ref_code != 'NULL' && $level_one->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_one->user_ref_code);
                        $level_two = $this->db->get()->row();
                    }
                    else{
                        $level_two = array();
                    }
//                    echo 'level2='.$level_one->ref_code.'<br>';;

                    if (!empty($level_two) && $level_two->user_ref_code != '' && $level_two->user_ref_code != NULL && $level_two->user_ref_code != 'NULL' && $level_two->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_two->user_ref_code);
                        $level_three = $this->db->get()->row();
                    }
                    else{
                        $level_three = array();
                    }
                }
                //                echo 'q3'.$this->db->last_query();
                //
                //                echo '<pre>';
                //                print_r($level_three);


                $win_amount = $cdraw->betted_amount * $color_data->multiplied;
                $win_amount1 = $cdraw->betted_amount;
                $betted_amount = $cdraw->betted_amount;

                $commision_per = $color_data->platform_charge;
                $reduced_comission_amount = ($win_amount1 * $commision_per) / 100;
                $final_ref_amount = $win_amount1 - $reduced_comission_amount;
                
              
                $reduce = 0;
                //                if (!empty($all_sub)) {
                if (!empty($level_one)) {
                    $sub1 = array(
                        'user_id' => $level_one->user_id,
                        'draw_id' => $last_id,
                        'level' => 1,
                        't_id' => $cdraw->id,
                        'refcode' => $level_one->ref_code,
                        'amount' => ($reduced_comission_amount * 50) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub1);
                    $reduce += ($reduced_comission_amount * 50) / 100;

                    $this->db->where('user_id', $level_one->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 50) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 50) / 100;
                    $platform_amount += ($reduced_comission_amount * 50) / 100;
                }

                if (!empty($level_two)) {
                    $sub2 = array(
                        'user_id' => $level_two->user_id,
                        'draw_id' => $last_id,
                        'level' => 2,
                        't_id' => $cdraw->id,
                        'refcode' => $level_two->ref_code,
                        'amount' => ($reduced_comission_amount * 30) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub2);
                    $reduce += ($reduced_comission_amount * 30) / 100;

                    $this->db->where('user_id', $level_two->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 30) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 30) / 100;
                    $platform_amount += ($reduced_comission_amount * 30) / 100;
                }

                if (!empty($level_three)) {
                    $sub3 = array(
                        'user_id' => $level_three->user_id,
                        'draw_id' => $last_id,
                        'level' => 3,
                        't_id' => $cdraw->id,
                        'refcode' => $level_three->ref_code,
                        'amount' => ($reduced_comission_amount * 20) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub3);
                    $reduce += ($reduced_comission_amount * 20) / 100;

                    $this->db->where('user_id', $level_three->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 20) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 20) / 100;
                    $platform_amount += ($reduced_comission_amount * 20) / 100;
                }
                //                }
                echo $win_amount.'--'.$reduce;
                $final_amount = $win_amount - $reduce;
                $this->db->where('id', $cdraw->id);
                $this->db->set('win_amount', $final_amount);
                $this->db->set('status', 1);
                $this->db->update('wp_betted_transaction');

                $this->db->where('user_id', $cdraw->user_id);
                $this->db->set('balance', 'balance + ' . $final_amount, false);
                $this->db->update('wp_user_master');
            }
        } else {
            $platform_array = array(
                'draw_id' => $last_id,
                'amount' => $color_sum->color_sum,
            );

            $this->db->insert('wp_platform_transactions', $platform_array);
        }
        
        echo '<pre>';
        print_r($non_win_color_array);

        if (!empty($non_win_color_array)) {
            foreach ($non_win_color_array as $cdraw) {

                $this->db->select('*');
                $this->db->from('wp_color_master');
                $this->db->where('id', $cdraw->game_id);
                $color_data = $this->db->get()->row();

                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_id', $cdraw->user_id);
                $userdrawdata = $this->db->get()->row();
                //                echo 'q'.$this->db->last_query();
                //                echo '<pre>';
                //                print_r($userdrawdata);
                $level_one = array();
                $level_two = array();
                $level_three = array();
                if ($userdrawdata->user_ref_code != '' && $userdrawdata->user_ref_code != NULL && $userdrawdata->user_ref_code != 'NULL' && $userdrawdata->user_ref_code != 'null') {
                    $this->db->select('*');
                    $this->db->from('wp_user_master');
                    $this->db->where('ref_code', $userdrawdata->user_ref_code);
                    $level_one = $this->db->get()->row();

                    //                echo 'q1'.$this->db->last_query();
                    //                echo '<pre>';
                    //                print_r($level_one);
                    //                $level_one = $all_sub;

                     if (!empty($level_one) && $level_one->user_ref_code != '' && $level_one->user_ref_code != NULL && $level_one->user_ref_code != 'NULL' && $level_one->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_one->user_ref_code);
                        $level_two = $this->db->get()->row();
                    }
                    else{
                        $level_two = array();
                    }
//                    echo 'level2='.$level_one->ref_code.'<br>';;

                    if (!empty($level_two) && $level_two->user_ref_code != '' && $level_two->user_ref_code != NULL && $level_two->user_ref_code != 'NULL' && $level_two->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_two->user_ref_code);
                        $level_three = $this->db->get()->row();
                    }
                    else{
                        $level_three = array();
                    }
                }
                //                echo 'q3'.$this->db->last_query();
                //
                //                echo '<pre>';
                //                print_r($level_three);


                $win_amount = $cdraw->betted_amount;
                $betted_amount = $cdraw->betted_amount;

                $commision_per = $color_data->platform_charge;
                $reduced_comission_amount = ($win_amount * $commision_per) / 100;
                $final_ref_amount = $win_amount - $reduced_comission_amount;
                //                $final_ref_amount = $win_amount - $reduced_comission_amount;

                $reduce = 0;
                //                if (!empty($all_sub)) {
                if (!empty($level_one)) {
                    $sub1 = array(
                        'user_id' => $level_one->user_id,
                        'draw_id' => $last_id,
                        'level' => 1,
                        't_id' => $cdraw->id,
                        'refcode' => $level_one->ref_code,
                        'amount' => ($reduced_comission_amount * 50) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub1);
                    $reduce += ($reduced_comission_amount * 50) / 100;

                    $this->db->where('user_id', $level_one->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 50) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 50) / 100;
                    $platform_amount += ($reduced_comission_amount * 50) / 100;
                }

                if (!empty($level_two)) {
                    $sub2 = array(
                        'user_id' => $level_two->user_id,
                        'draw_id' => $last_id,
                        'level' => 2,
                        't_id' => $cdraw->id,
                        'refcode' => $level_two->ref_code,
                        'amount' => ($reduced_comission_amount * 30) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub2);
                    $reduce += ($reduced_comission_amount * 30) / 100;

                    $this->db->where('user_id', $level_two->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 30) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 30) / 100;
                    $platform_amount += ($reduced_comission_amount * 30) / 100;
                }

                if (!empty($level_three)) {
                    $sub3 = array(
                        'user_id' => $level_three->user_id,
                        'draw_id' => $last_id,
                        'level' => 3,
                        't_id' => $cdraw->id,
                        'refcode' => $level_three->ref_code,
                        'amount' => ($reduced_comission_amount * 20) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub3);
                    $reduce += ($reduced_comission_amount * 20) / 100;

                    $this->db->where('user_id', $level_three->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 20) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 20) / 100;
                    $platform_amount += ($reduced_comission_amount * 20) / 100;
                }
//                //                }
//
//                $final_amount = $win_amount - $reduce;
                $this->db->where('id', $cdraw->id);
//                $this->db->set('win_amount', $final_amount);
                $this->db->set('status', 2);
                $this->db->update('wp_betted_transaction');
//
//                $this->db->where('user_id', $cdraw->user_id);
//                $this->db->set('balance', 'balance + ' . $final_amount, false);
//                $this->db->update('wp_user_master');
            }
        }


        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_id);
        $this->db->where('game_id', $lvl_one_win_number);
        $final_nunmer_draw = $this->db->get()->result();

        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_id);
        $this->db->where('game_id !=', $lvl_one_win_number);
        $this->db->where_not_in('game_id', array(1,2,3));
        $non_win_nunbmer_draw = $this->db->get()->result();

        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('id', $lvl_one_win_number);
        $color_data = $this->db->get()->row();
        
        echo count($final_nunmer_draw);
        print_r($final_nunmer_draw);
        if (!empty($final_nunmer_draw)) {
            foreach ($final_nunmer_draw as $cdraw) {
//  echo 'came';
                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_id', $cdraw->user_id);
                $userdrawdata = $this->db->get()->row();

                $level_one = array();
                $level_two = array();
                $level_three = array();
                if ($userdrawdata->user_ref_code != '' && $userdrawdata->user_ref_code != NULL && $userdrawdata->user_ref_code != 'NULL' && $userdrawdata->user_ref_code != 'null') {


                    $this->db->select('*');
                    $this->db->from('wp_user_master');
                    $this->db->where('ref_code', $userdrawdata->user_ref_code);
                    $level_one = $this->db->get()->row();
                    
//                    echo 'level1='.$userdrawdata->user_ref_code.'<br>';
                    //                $level_one = $all_sub;
                    if (!empty($level_one) && $level_one->user_ref_code != '' && $level_one->user_ref_code != NULL && $level_one->user_ref_code != 'NULL' && $level_one->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_one->user_ref_code);
                        $level_two = $this->db->get()->row();
                    }
                    else{
                        $level_two = array();
                    }
//                    echo 'level2='.$level_one->ref_code.'<br>';;

                    if (!empty($level_two) && $level_two->user_ref_code != '' && $level_two->user_ref_code != NULL && $level_two->user_ref_code != 'NULL' && $level_two->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_two->user_ref_code);
                        $level_three = $this->db->get()->row();
                    }
                    else{
                        $level_three = array();
                    }
                    
//                    echo 'level3='.$level_two->ref_code.'<br>';
                }
                
                echo '<pre>';
                print_r($level_one);
                print_r($level_two);
                print_r($level_three);
                //
                //                $this->db->select('*');
                //                $this->db->from('wp_user_master');
                //                $this->db->where('user_ref_code', $userdrawdata->ref_code);
                //                $this->db->limit(3);
                //                $all_sub = $this->db->get()->result();
                //                echo '<pre>';
                //                print_r($all_sub);


//                $win_amount = $cdraw->betted_amount * $color_data->multiplied;
//                $betted_amount = $cdraw->betted_amount;
//
//                $commision_per = $color_data->platform_charge;
//                $reduced_comission_amount = ($win_amount * $commision_per) / 100;
//                $final_ref_amount = $win_amount - $reduced_comission_amount;
                
                
                $win_amount = $cdraw->betted_amount * $color_data->multiplied;
                $win_amount1 = $cdraw->betted_amount;
                $betted_amount = $cdraw->betted_amount;

                $commision_per = $color_data->platform_charge;
                $reduced_comission_amount = ($win_amount1 * $commision_per) / 100;
                $final_ref_amount = $win_amount1 - $reduced_comission_amount;

                $reduce = 0;

                if (!empty($level_one)) {
                    $sub1 = array(
                        'user_id' => $level_one->user_id,
                        'draw_id' => $last_id,
                        'level' => 1,
                        'status' => 2,
                        't_id' => $cdraw->id,
                        'refcode' => $level_one->ref_code,
                        'amount' => ($reduced_comission_amount * 50) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub1);
                    $reduce += ($reduced_comission_amount * 50) / 100;

                    $this->db->where('user_id', $level_one->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 50) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 50) / 100;
                    $platform_amount += ($reduced_comission_amount * 50) / 100;
                }

                if (!empty($level_two)) {
                    $sub2 = array(
                        'user_id' => $level_two->user_id,
                        'draw_id' => $last_id,
                        'level' => 2,
                        'status' => 2,
                        't_id' => $cdraw->id,
                        'refcode' => $level_two->ref_code,
                        'amount' => ($reduced_comission_amount * 30) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub2);
                    $reduce += ($reduced_comission_amount * 30) / 100;

                    $this->db->where('user_id', $level_two->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 30) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 30) / 100;
                    $platform_amount += ($reduced_comission_amount * 30) / 100;
                }

                if (!empty($level_three)) {
                    $sub3 = array(
                        'user_id' => $level_three->user_id,
                        'draw_id' => $last_id,
                        'level' => 3,
                        'status' => 2,
                        't_id' => $cdraw->id,
                        'refcode' => $level_three->ref_code,
                        'amount' => ($reduced_comission_amount * 20) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub3);
                    $reduce += ($reduced_comission_amount * 20) / 100;

                    $this->db->where('user_id', $level_three->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 20) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 20) / 100;
                    $platform_amount += ($reduced_comission_amount * 20) / 100;
                }

                $final_amount = $win_amount - $reduce;
                $this->db->where('id', $cdraw->id);
                $this->db->set('win_amount', $final_amount);
                $this->db->set('status', 1);
                $this->db->update('wp_betted_transaction');

                $this->db->where('user_id', $cdraw->user_id);
                $this->db->set('balance', 'balance + ' . $final_amount, false);
                $this->db->update('wp_user_master');
            }
        } else {
            $platform_array = array(
                'draw_id' => $last_id,
                'amount' => $number_sum->number_sum,
            );

            $this->db->insert('wp_platform_transactions', $platform_array);
        }

//        echo '<pre>';
//        print_r($non_win_nunbmer_draw);
//        count($non_win_nunbmer_draw).'<br>';
        if (!empty($non_win_nunbmer_draw)) {
            foreach ($non_win_nunbmer_draw as $cdraw) {
                echo 'came';
                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_id', $cdraw->user_id);
                $userdrawdata = $this->db->get()->row();
                
                $this->db->select('*');
                $this->db->from('wp_color_master');
                $this->db->where('id', $cdraw->game_id);
                $color_data = $this->db->get()->row();

                $level_one = array();
                $level_two = array();
                $level_three = array();
                if ($userdrawdata->user_ref_code != '' && $userdrawdata->user_ref_code != NULL && $userdrawdata->user_ref_code != 'NULL' && $userdrawdata->user_ref_code != 'null') {


                    $this->db->select('*');
                    $this->db->from('wp_user_master');
                    $this->db->where('ref_code', $userdrawdata->user_ref_code);
                    $level_one = $this->db->get()->row();
                    //                $level_one = $all_sub;

                   if (!empty($level_one) && $level_one->user_ref_code != '' && $level_one->user_ref_code != NULL && $level_one->user_ref_code != 'NULL' && $level_one->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_one->user_ref_code);
                        $level_two = $this->db->get()->row();
                    }
                    else{
                        $level_two = array();
                    }
//                    echo 'level2='.$level_one->ref_code.'<br>';;

                    if (!empty($level_two) && $level_two->user_ref_code != '' && $level_two->user_ref_code != NULL && $level_two->user_ref_code != 'NULL' && $level_two->user_ref_code != 'null') {
                        $this->db->select('*');
                        $this->db->from('wp_user_master');
                        $this->db->where('ref_code', $level_two->user_ref_code);
                        $level_three = $this->db->get()->row();
                    }
                    else{
                        $level_three = array();
                    }
                }
                
              
                
                //
                //                $this->db->select('*');
                //                $this->db->from('wp_user_master');
                //                $this->db->where('user_ref_code', $userdrawdata->ref_code);
                //                $this->db->limit(3);
                //                $all_sub = $this->db->get()->result();
                //                echo '<pre>';
                //                print_r($all_sub);


                $win_amount = $cdraw->betted_amount;
//                $betted_amount = $cdraw->betted_amount;

                $commision_per = $color_data->platform_charge;
                $reduced_comission_amount = ($win_amount * $commision_per) / 100;
                $final_ref_amount = $win_amount - $reduced_comission_amount;

                $reduce = 0;

                if (!empty($level_one)) {
                    $sub1 = array(
                        'user_id' => $level_one->user_id,
                        'draw_id' => $last_id,
                        'level' => 1,
                        't_id' => $cdraw->id,
                        'refcode' => $level_one->ref_code,
                        'status' => 1,
                        'amount' => ($reduced_comission_amount * 50) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub1);
                    $reduce += ($reduced_comission_amount * 50) / 100;

                    $this->db->where('user_id', $level_one->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 50) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 50) / 100;
                    $platform_amount += ($reduced_comission_amount * 50) / 100;
                }

                if (!empty($level_two)) {
                    $sub2 = array(
                        'user_id' => $level_two->user_id,
                        'draw_id' => $last_id,
                        'level' => 2,
                        't_id' => $cdraw->id,
                        'status' => 1,
                        'refcode' => $level_two->ref_code,
                        'amount' => ($reduced_comission_amount * 30) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub2);
                    $reduce += ($reduced_comission_amount * 30) / 100;

                    $this->db->where('user_id', $level_two->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 30) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 30) / 100;
                    $platform_amount += ($reduced_comission_amount * 30) / 100;
                }

                if (!empty($level_three)) {
                    $sub3 = array(
                        'user_id' => $level_three->user_id,
                        'draw_id' => $last_id,
                        'level' => 3,
                        't_id' => $cdraw->id,
                        'status' => 1,
                        'refcode' => $level_three->ref_code,
                        'amount' => ($reduced_comission_amount * 20) / 100,
                    );
                    $this->db->insert('wp_ref_bonus', $sub3);
                    $reduce += ($reduced_comission_amount * 20) / 100;

                    $this->db->where('user_id', $level_three->user_id);
                    $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 20) / 100, false);
                    $this->db->update('wp_user_master');
                } else {
                    $reduce += ($reduced_comission_amount * 20) / 100;
                    $platform_amount += ($reduced_comission_amount * 20) / 100;
                }
                 $this->db->where('id', $cdraw->id);
//                $this->db->set('win_amount', $final_amount);
                $this->db->set('status', 2);
                $this->db->update('wp_betted_transaction');

//                $final_amount = $win_amount - $reduce;
//                $this->db->where('id', $cdraw->id);
//                $this->db->set('win_amount', $final_amount);
//                $this->db->set('status', 1);
//                $this->db->update('wp_betted_transaction');
//
//                $this->db->where('user_id', $cdraw->user_id);
//                $this->db->set('balance', 'balance + ' . $final_amount, false);
//                $this->db->update('wp_user_master');
            }
        }


        $platform_array = array(
            'draw_id' => $last_id,
            'amount' => $platform_amount,
        );

        $this->db->insert('wp_platform_transactions', $platform_array);

        /*
          $color_array = array(
          '1' => '#4caf50',
          '2' => '#9c27b0',
          '3' => '#f44336',
          );
          $number_array = array(
          '4' => '0',
          '5' => '1',
          '6' => '2',
          '7' => '3',
          '8' => '4',
          '9' => '5',
          '10' => '6',
          '11' => '7',
          '12' => '8',
          '13' => '9',
          );

          $this->db->select('SUM(betted_amount) as number_sum');
          $this->db->from('wp_betted_transaction');
          $this->db->where('active_game_id', $last_id);
          $this->db->where_in('game_id', array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
          $number_sum = $this->db->get()->row();

          $this->db->select('SUM(betted_amount) as color_sum');
          $this->db->from('wp_betted_transaction');
          $this->db->where('active_game_id', $last_id);
          $this->db->where_in('game_id', array(1, 2, 3));
          $color_sum = $this->db->get()->row();
          //        $this->db->last_query().'<br>';
          $this->db->select('*');
          $this->db->from('wp_betted_transaction');
          $this->db->where('active_game_id', $last_id);
          $this->db->where('game_id', $colr_key);
          $final_color_draw = $this->db->get()->result();

          $this->db->select('*');
          $this->db->from('wp_color_master');
          $this->db->where('id', $colr_key);
          $color_data = $this->db->get()->row();

          $color_win_sum = 0;

          if (!empty($final_color_draw)) {
          foreach ($final_color_draw as $cdraw) {

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('user_id', $cdraw->user_id);
          $userdrawdata = $this->db->get()->row();

          //                 echo '<pre>';
          //                print_r($userdrawdata);


          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('user_ref_code', $userdrawdata->ref_code);
          $this->db->limit(3);
          $all_sub = $this->db->get()->result();

          $win_amount = $cdraw->betted_amount * $color_data->multiplied;
          $color_win_sum += $win_amount;
          $final_amount = $win_amount - $reduce;
          }
          }


          $this->db->select('*');
          $this->db->from('wp_betted_transaction');
          $this->db->where('active_game_id', $last_id);
          $this->db->where('game_id', $number_key);
          $final_nunmer_draw = $this->db->get()->result();

          $this->db->select('*');
          $this->db->from('wp_color_master');
          $this->db->where('id', $number_key);
          $color_data = $this->db->get()->row();
          $number_win_sum = 0;
          if (!empty($final_nunmer_draw)) {
          foreach ($final_nunmer_draw as $cdraw) {

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('user_id', $cdraw->user_id);
          $userdrawdata = $this->db->get()->row();

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('user_ref_code', $userdrawdata->ref_code);
          $this->db->limit(3);
          $all_sub = $this->db->get()->result();

          $win_amount = $cdraw->betted_amount * $color_data->multiplied;

          $number_win_sum += $win_amount;
          $final_amount = $win_amount - $reduce;

          }
          }

          if ($color_win_sum < $color_sum->color_sum) {
          }

          else {

          if ($color_win_sum == 0) {
          $zero_array = array(
          '1' => '#4caf50',
          '2' => '#9c27b0',
          '3' => '#f44336',
          );
          unset($zero_array[$color_win[0]]);
          $random_keys = array_rand($zero_array, 1);
          $color_win[0] = $random_keys;
          $colr_key = $random_keys;

          $iarr = array(
          'draw_id' => $last_id,
          'sum' => $color_win_sum,
          'win_sum' => $color_sum->color_sum,
          );
          $this->db->insert('wp_sum', $iarr);
          } else {


          $this->db->select('id');
          $this->db->from('wp_color_master');
          $this->db->where_in('id', array(1, 2, 3));
          $this->db->where_not_in('id', $color_win[0]);
          $color_win = $this->db->get()->result();

          $color_array = array();
          foreach ($color_win as $nm) {
          array_push($color_array, $nm->id);
          }
          $random_keys = array_rand($color_array, 1);
          $color_win[0] = $random_keys;
          $colr_key = $random_keys;
          }
          }

          if ($number_win_sum < $number_sum->number_sum) {

          }
          else {
          if ($number_win_sum == 0) {
          $number_win[0] = rand(4, 13);
          $number_key = rand(4, 13);
          } else {
          $this->db->select('id');
          $this->db->from('wp_color_master');
          $this->db->where_in('id', array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
          $this->db->where_not_in('id', $number_win[0]);
          $number_win = $this->db->get()->result();

          $number_array = array();
          foreach ($number_win as $nm) {
          array_push($number_array, $nm->id);
          }
          $random_keys1 = array_rand($number_array, 3);

          $number_win[0] = $random_keys1[0];
          $number_key = $random_keys1[0];
          }
          }

          $update_array = array(
          'win_color' => $colr_key,
          'win_number' => $number_key,
          'win_color_price' => $lowest_color_array[$colr_key],
          'win_number_price' => $lowest_number_array[$number_key],
          'updated_time' => date('Y-m-d H:i:s'),
          'is_completed' => 1,
          );

          $this->db->where('draw_id', $last_id);
          $this->db->update('wp_draw_result', $update_array);

          $update_array = array(
          'win_color' => $colr_key,
          'win_number' => $number_key,
          'win_color_price' => $lowest_color_array[$colr_key],
          'win_number_price' => $lowest_number_array[$number_key],
          'win_number_name' => $number_array[$number_key],
          'win_color_name' => $color_array[$colr_key],
          );

          $this->db->where('id', $last_id);
          $this->db->update('wp_draw_master', $update_array);

          $this->db->select('*');
          $this->db->from('wp_betted_transaction');
          $this->db->where('active_game_id', $last_id);
          $this->db->where('game_id', $colr_key);
          $final_color_draw = $this->db->get()->result();

          $this->db->select('*');
          $this->db->from('wp_color_master');
          $this->db->where('id', $colr_key);
          $color_data = $this->db->get()->row();

          if (!empty($final_color_draw)) {
          foreach ($final_color_draw as $cdraw) {

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('user_id', $cdraw->user_id);
          $userdrawdata = $this->db->get()->row();
          //                echo 'q'.$this->db->last_query();
          //                echo '<pre>';
          //                print_r($userdrawdata);
          $level_one = array();
          $level_two = array();
          $level_three = array();
          if ($userdrawdata->user_ref_code != '' || $userdrawdata->user_ref_code != NULL) {
          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('ref_code', $userdrawdata->user_ref_code);
          $level_one = $this->db->get()->row();

          //                echo 'q1'.$this->db->last_query();
          //                echo '<pre>';
          //                print_r($level_one);
          //                $level_one = $all_sub;

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('ref_code', $level_one->user_ref_code);
          $level_two = $this->db->get()->row();
          //                echo 'q2'.$this->db->last_query();
          //
          //                 echo '<pre>';
          //                print_r($level_two);

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('ref_code', $level_two->user_ref_code);
          $level_three = $this->db->get()->row();
          }
          //                echo 'q3'.$this->db->last_query();
          //
          //                echo '<pre>';
          //                print_r($level_three);


          $win_amount = $cdraw->betted_amount * $color_data->multiplied;
          $betted_amount = $cdraw->betted_amount;

          $commision_per = $color_data->platform_charge;
          $reduced_comission_amount = ($win_amount * $commision_per) / 100;
          $final_ref_amount = $win_amount - $reduced_comission_amount;
          //                $final_ref_amount = $win_amount - $reduced_comission_amount;

          $reduce = 0;
          //                if (!empty($all_sub)) {
          if (!empty($level_one)) {
          $sub1 = array(
          'user_id' => $level_one->user_id,
          'draw_id' => $last_id,
          'level' => 1,
          't_id' => $cdraw->id,
          'refcode' => $level_one->ref_code,
          'amount' => ($reduced_comission_amount * 50) / 100,
          );
          $this->db->insert('wp_ref_bonus', $sub1);
          $reduce += ($reduced_comission_amount * 50) / 100;

          $this->db->where('user_id', $level_one->user_id);
          $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 50) / 100, false);
          $this->db->update('wp_user_master');
          }
          if (!empty($level_two)) {
          $sub2 = array(
          'user_id' => $level_two->user_id,
          'draw_id' => $last_id,
          'level' => 2,
          't_id' => $cdraw->id,
          'refcode' => $level_two->ref_code,
          'amount' => ($reduced_comission_amount * 30) / 100,
          );
          $this->db->insert('wp_ref_bonus', $sub2);
          $reduce += ($reduced_comission_amount * 30) / 100;

          $this->db->where('user_id', $level_two->user_id);
          $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 30) / 100, false);
          $this->db->update('wp_user_master');
          }
          if (!empty($level_three)) {
          $sub3 = array(
          'user_id' => $level_three->user_id,
          'draw_id' => $last_id,
          'level' => 3,
          't_id' => $cdraw->id,
          'refcode' => $level_three->ref_code,
          'amount' => ($reduced_comission_amount * 20) / 100,
          );
          $this->db->insert('wp_ref_bonus', $sub3);
          $reduce += ($reduced_comission_amount * 20) / 100;

          $this->db->where('user_id', $level_three->user_id);
          $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 20) / 100, false);
          $this->db->update('wp_user_master');
          }
          //                }

          $final_amount = $win_amount - $reduce;
          $this->db->where('id', $cdraw->id);
          $this->db->set('win_amount', $final_amount);
          $this->db->set('status', 1);
          $this->db->update('wp_betted_transaction');

          $this->db->where('user_id', $cdraw->user_id);
          $this->db->set('balance', 'balance + ' . $final_amount, false);
          $this->db->update('wp_user_master');
          }
          }


          $this->db->select('*');
          $this->db->from('wp_betted_transaction');
          $this->db->where('active_game_id', $last_id);
          $this->db->where('game_id', $number_key);
          $final_nunmer_draw = $this->db->get()->result();

          $this->db->select('*');
          $this->db->from('wp_color_master');
          $this->db->where('id', $number_key);
          $color_data = $this->db->get()->row();

          if (!empty($final_nunmer_draw)) {
          foreach ($final_nunmer_draw as $cdraw) {

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('user_id', $cdraw->user_id);
          $userdrawdata = $this->db->get()->row();

          $level_one = array();
          $level_two = array();
          $level_three = array();
          if ($userdrawdata->user_ref_code != '' || $userdrawdata->user_ref_code != NULL) {


          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('ref_code', $userdrawdata->user_ref_code);
          $level_one = $this->db->get()->row();
          //                $level_one = $all_sub;

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('ref_code', $level_one->ref_code);
          $level_two = $this->db->get()->row();

          $this->db->select('*');
          $this->db->from('wp_user_master');
          $this->db->where('ref_code', $level_two->ref_code);
          $level_three = $this->db->get()->row();
          }
          //
          //                $this->db->select('*');
          //                $this->db->from('wp_user_master');
          //                $this->db->where('user_ref_code', $userdrawdata->ref_code);
          //                $this->db->limit(3);
          //                $all_sub = $this->db->get()->result();
          //                echo '<pre>';
          //                print_r($all_sub);


          $win_amount = $cdraw->betted_amount * $color_data->multiplied;
          $betted_amount = $cdraw->betted_amount;

          $commision_per = $color_data->platform_charge;
          $reduced_comission_amount = ($win_amount * $commision_per) / 100;
          $final_ref_amount = $win_amount - $reduced_comission_amount;

          $reduce = 0;


          if (!empty($level_one)) {
          $sub1 = array(
          'user_id' => $level_one->user_id,
          'draw_id' => $last_id,
          'level' => 1,
          't_id' => $cdraw->id,
          'refcode' => $level_one->ref_code,
          'amount' => ($reduced_comission_amount * 50) / 100,
          );
          $this->db->insert('wp_ref_bonus', $sub1);
          $reduce += ($reduced_comission_amount * 50) / 100;

          $this->db->where('user_id', $level_one->user_id);
          $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 50) / 100, false);
          $this->db->update('wp_user_master');
          }
          if (!empty($level_two)) {
          $sub2 = array(
          'user_id' => $level_two->user_id,
          'draw_id' => $last_id,
          'level' => 2,
          't_id' => $cdraw->id,
          'refcode' => $level_two->ref_code,
          'amount' => ($reduced_comission_amount * 30) / 100,
          );
          $this->db->insert('wp_ref_bonus', $sub2);
          $reduce += ($reduced_comission_amount * 30) / 100;

          $this->db->where('user_id', $level_two->user_id);
          $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 30) / 100, false);
          $this->db->update('wp_user_master');
          }
          if (!empty($level_three)) {
          $sub3 = array(
          'user_id' => $level_three->user_id,
          'draw_id' => $last_id,
          'level' => 3,
          't_id' => $cdraw->id,
          'refcode' => $level_three->ref_code,
          'amount' => ($reduced_comission_amount * 20) / 100,
          );
          $this->db->insert('wp_ref_bonus', $sub3);
          $reduce += ($reduced_comission_amount * 20) / 100;

          $this->db->where('user_id', $level_three->user_id);
          $this->db->set('balance', 'balance + ' . ($reduced_comission_amount * 20) / 100, false);
          $this->db->update('wp_user_master');
          }

          $final_amount = $win_amount - $reduce;
          $this->db->where('id', $cdraw->id);
          $this->db->set('win_amount', $final_amount);
          $this->db->set('status', 1);
          $this->db->update('wp_betted_transaction');

          $this->db->where('user_id', $cdraw->user_id);
          $this->db->set('balance', 'balance + ' . $final_amount, false);
          $this->db->update('wp_user_master');
          }
          }
         */
    }

    function generateDrawResult() {
        $this->db->select('*');
        $this->db->from('wp_draw_result');
        $this->db->where('is_completed', 0);
        $this->db->where('completed_time <=', date('Y-m-d H:i:s'));
        $last_draw = $this->db->get()->row();
        if (empty($last_draw)) {
            return;
        }



        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_draw->draw_id);
        $this->db->where_in('game_id', array(1, 2, 3));
        $color_draw = $this->db->get()->result();
        $n1 = 0;
        $n2 = 0;
        $n3 = 0;
        if (!empty($color_draw)) {
            foreach ($color_draw as $d) {
                if ($d->game_id == 1) {
                    $n1 += $d->betted_amount;
                }
                if ($d->game_id == 2) {
                    $n2 += $d->betted_amount;
                }
                if ($d->game_id == 3) {
                    $n3 += $d->betted_amount;
                }
            }
        }

        $lowest_color_array = array(
            '1' => $n1,
            '2' => $n2,
            '3' => $n3,
        );

        $lowest_color_array = array_diff($lowest_color_array, [0]);
        $color_win = array_keys($lowest_color_array, min($lowest_color_array));

        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', $last_draw->draw_id);
        $this->db->where_in('game_id', array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
        $number_draw = $this->db->get()->result();

        $n4 = 0;
        $n5 = 0;
        $n6 = 0;
        $n7 = 0;
        $n8 = 0;
        $n9 = 0;
        $n10 = 0;
        $n11 = 0;
        $n12 = 0;
        $n13 = 0;
        if (!empty($number_draw)) {
            foreach ($number_draw as $d) {
                if ($d->game_id == 4) {
                    $n4 += $d->betted_amount;
                }
                if ($d->game_id == 5) {
                    $n5 += $d->betted_amount;
                }
                if ($d->game_id == 6) {
                    $n6 += $d->betted_amount;
                }
                if ($d->game_id == 7) {
                    $n7 += $d->betted_amount;
                }
                if ($d->game_id == 8) {
                    $n8 += $d->betted_amount;
                }
                if ($d->game_id == 9) {
                    $n9 += $d->betted_amount;
                }
                if ($d->game_id == 10) {
                    $n10 += $d->betted_amount;
                }
                if ($d->game_id == 11) {
                    $n11 += $d->betted_amount;
                }
                if ($d->game_id == 12) {
                    $n12 += $d->betted_amount;
                }
                if ($d->game_id == 13) {
                    $n13 += $d->betted_amount;
                }
            }
        }


        $lowest_number_array = array(
            '4' => $n4,
            '5' => $n5,
            '6' => $n6,
            '7' => $n7,
            '8' => $n8,
            '9' => $n9,
            '10' => $n10,
            '11' => $n11,
            '12' => $n12,
            '13' => $n13,
        );

        $lowest_number_array = array_diff($lowest_number_array, [0]);
        $number_win = array_keys($lowest_number_array, min($lowest_number_array));
        $colr_key = $color_win[0];
        $number_key = $number_win[0];

        $update_array = array(
            'win_color' => $color_win[0],
            'win_number' => $number_win[0],
            'win_color_price' => $lowest_color_array[$colr_key],
            'win_number_price' => $lowest_number_array[$number_key],
            'updated_time' => date('Y-m-d H:i:s'),
            'is_completed' => 1,
        );

        $this->db->where('draw_id', $last_draw->draw_id);
        $this->db->update('wp_draw_result', $update_array);

        $update_array = array(
            'win_color' => $color_win[0],
            'win_number' => $number_win[0],
            'win_color_price' => $lowest_color_array[$colr_key],
            'win_number_price' => $lowest_number_array[$number_key],
        );

        $this->db->where('id', $last_draw->draw_id);
        $this->db->update('wp_draw_master', $update_array);

        if (!empty($color_draw)) {
            foreach ($color_draw as $cdraw) {
                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_id', $cdraw->user_id);
                $userdata = $this->db->get()->row();

                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_ref_code', $userdata->user_id);
                $this->db->limit(3);
                $all = $this->db->get()->result();
            }
        }
    }

    function drawData() {

        $this->db->select('*');

        $this->db->from('wp_draw_master');

        $this->db->where('is_active', 0);

        $this->db->where('start_time >', date('Y-m-d') . ' 00:00:00');

        $this->db->where('end_time <', date('Y-m-d') . ' 23:59:59');

        $this->db->order_by('id', 'desc');

        $data = $this->db->get()->result();

        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('type', 1);
        $color_array = $this->db->get()->result();

        $this->db->select('*');
        $this->db->from('wp_color_master');
        $this->db->where('type', 2);
        $number_array = $this->db->get()->result();

        $number = array_column($number_array, 'name', 'id');
        $color = array_column($color_array, 'color_code', 'id');

        foreach ($data as $data) {

            echo '<tr>';

            echo '<td>' . $data->draw_name . '</td>';

            echo '<td>' . (rand(14500, 15500)) . '</td>';

            if ($data->win_number != '' || $data->win_number != NULL) {
                echo '<td>' . $number[$data->win_number] . '</td>';
            } else {
                echo '<td></td>';
            }

            if ($data->win_color != '' || $data->win_color != NULL) {
//                echo '<td><div class="test rounded-circle" style="width: 25px;height: 25px;background-color: ' . $color[$data->win_color] . ' ;"></div></td>';
                if($data->win_color == '3,2')
                    {
                        echo '<td>'
                        . '<div class="test rounded-circle" style="background-color: #f44336;"></div>'
                        . '<div class="test rounded-circle" style="background-color: #9c27b0;"></div>'
                                . '</td>';
                    }
                    else if($data->win_color == '1,2')
                    {
                        echo '<td>'
                        . '<div class="test rounded-circle" style="background-color: #4caf50;"></div>'
                        . '<div class="test rounded-circle" style="background-color: #9c27b0;"></div>'
                                . '</td>';
                    }
                    else 
                    {    
                      echo '<td><div class="test rounded-circle" style="background-color: ' . $color[$data->win_color] . ' ;"></div></td>';
                    }
            } else { 
                echo '<td></td>';
            }



            echo '</tr>';
        }
    }

    function get_data() {
        $id = $this->input->post('color_id');

        $this->db->select('*');

        $this->db->from('wp_color_master');

        $this->db->join('wp_color_price', 'wp_color_price.color_id = wp_color_master.id');

        $this->db->where('wp_color_master.id', $id);

        $all_data = $this->db->get()->result();

        $this->db->select('*');

        $this->db->from('wp_draw_master');

        $this->db->where('is_active', 1);

        $last_draw = $this->db->get()->row();

        // echo '<pre>';
        // print_r($all_data);
        echo '<div class="row">';
        echo '<form id="bet_form">';
        echo '<h5 style="margin-left:3% !important">Contract Money</h5>';
        echo '</div>';
        echo '<div class="row">';

        foreach ($all_data as $data) {
            echo '<div class="col-xl-1 col-3">
                    <button class="btn btn-default bet_amount" data-amount="' . $data->to_price . '" >' . $data->to_price . '</button>
                    </div>';
        }
        echo '<br><input type="hidden" name="betted_amount" id="betted_amount" value="">
                    <input type="hidden" name="game_id" id="game_id" value="' . $id . '">
                    <input type="hidden" name="active_game_id" id="active_game_id" value="' . $last_draw->id . '">';
        echo '</div>';

        echo '<div class="row mt-10">';
        echo '<h5 style="margin-left:3% !important">Number</h5>';
        echo '</div>';
        echo '<div class="row " style="margin-left:3% !important">';
        echo '<input type="hidden" id="range_val" value="0">';
        echo '<input type="hidden" id="step" value="10">';
        echo '<button class="btn btn-primary range_selector" data-type="minus" type="button"><i class="fas fa-minus"></i></button>';
        echo '<button class="ml-1 btn btn-primary range_selector" data-type="plus" type="button"><i class="fas fa-plus"></i></button>';
        echo '<h5 style="margin-left:3% !important" id="range_value">Total contract money is </h5></div>';
        echo '<h5 style="margin-left:3% !important;color:red" id="error_msg"></h5>';
        echo '</form>';
        echo '</div>';
    }

    function active_draw_data() {
        $this->db->select('end_time,draw_name');

        $this->db->from('wp_draw_master');

        $this->db->where('is_active', 1);

        $last_draw = $this->db->get()->row();

        $current_time = date('Y-m-d H:i:s');
        $time2 = new DateTime($last_draw->end_time);
        $time1 = new DateTime($current_time);
        $timediff = $time1->diff($time2);
        $timediffrence = $timediff->format('%i : %s');
        $diffInSeconds = $timediff->s;

        echo json_encode(array('draw' => $last_draw->draw_name, 'timer' => $timediffrence, 'tot_seconds' =>
            $time2->getTimestamp() - $time1->getTimestamp()));
    }

    function submitBet() {

        $i_array = array(
            'user_id' => $this->session->userdata('user_id'),
            'game_id' => $this->input->post('game_id'),
            'active_game_id' => $this->input->post('active_game_id'),
            'betted_amount' => $this->input->post('betted_amount'),
            'created_at' => date('Y-m-d H::s'),
        );
        $this->db->insert('wp_betted_transaction', $i_array);

        $this->db->where('user_id', $this->session->userdata('user_id'));
        $this->db->set('balance', 'balance - ' . $this->input->post('betted_amount'), false);
        $this->db->update('wp_user_master');
    }

    function get_level() {
        $this->db->select('*');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', 1044);
        $this->db->where('game_id', 2);
        $color_draw = $this->db->get()->result();

        if (!empty($color_draw)) {
            foreach ($color_draw as $cdraw) {
                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_id', $cdraw->user_id);
                $userdata = $this->db->get()->row();

                $this->db->select('*');
                $this->db->from('wp_user_master');
                $this->db->where('user_ref_code', 'VISH42');
                $this->db->limit(3);
                $all_sub = $this->db->get()->result();

                $win_amount = $cdraw->betted_amount * $cdraw->game_times;
                $betted_amount = $cdraw->betted_amount;

                $reduce = 0;
                if (!empty($all_sub)) {
                    if (isset($all_sub[0])) {
                        $sub1 = array(
                            'user_id' => $all_sub[0]->user_id,
                            'draw_id' => 1044,
                            'amount' => ($betted_amount * 5) / 100,
                        );
                        $this->db->insert('wp_ref_bonus', $sub1);
                        $reduce += ($betted_amount * 5) / 100;
                    }
                    if (isset($all_sub[1])) {
                        $sub1 = array(
                            'user_id' => $all_sub[1]->user_id,
                            'draw_id' => 1044,
                            'amount' => ($betted_amount * 3) / 100,
                        );
                        $this->db->insert('wp_ref_bonus', $sub1);
                        $reduce += ($betted_amount * 3) / 100;
                    }
                    if (isset($all_sub[2])) {
                        $sub1 = array(
                            'user_id' => $all_sub[2]->user_id,
                            'draw_id' => 1044,
                            'amount' => ($betted_amount * 2) / 100,
                        );
                        $this->db->insert('wp_ref_bonus', $sub1);
                        $reduce += ($betted_amount * 2) / 100;
                    }
                }

                $final_amount = $win_amount - $reduce;
                $this->db->where('id', $cdraw->id);
                $this->db->set('win_amount', $final_amount);
                $this->db->update('wp_betted_transaction');
            }
        }
    }

    function send_sms() {
        $this->db->select('SUM(betted_amount) as number_sum');
        $this->db->from('wp_betted_transaction');
        $this->db->where('active_game_id', 21);
        $this->db->where_in('game_id', array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
        $number_sum = $this->db->get()->row();
//                echo $number_sum->number_sum;
//                print_r($number_sum);
    }

}

/* end of account */