<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// use PhpOffice\PhpSpreadsheet\Spreadsheet;
// use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class User extends MY_Controller {

    function __construct()
    {
        parent::__construct();

        // module
        $this->ml_users = Module::USER;

        // tables
        $this->tbl_users            = TBL_USERS;
        $this->tbl_session_master   = TBL_SESSION;

        $this->load->model(
                array(
                    'user_model',
                    'general_model',
                    'activity_model'
                )
        );
    }

    function index() {
        $title = 'Micro App';
        $this->load_view('app_view', $title);
    }

    function add() {
        $title = 'Add User';
        $this->content->breadcrumb = array(
            'User' => 'console/user',
            $title => NULL
        );

        $this->load->library('form_validation');

        if ($this->form_validation->run('add_user')) {
            $post = $this->input->post();
            $app = array();

            $app['first_name'] = strtolower($post['first_name']);
            $app['last_name'] = strtolower($post['last_name']);
            $app['email'] = strtolower($post['email']);
            $app['mobile'] = $post['mobile'];
            $app['user_status'] = (isset($post['status']) ? $post['status'] : NULL);
            $app['user_key'] = $this->hash_password(strtolower($post['first_name']));
            $app['password'] = $this->hash_password('123456');
            $app['role'] = User_role::MEMBER;
            $app['created_by'] = $this->session->userdata('user_id');
            $app['created_on'] = time();
            $user_id = $this->user_model->add_data($this->tbl_users, $app);

            if (isset($user_id) && !empty($user_id)) {
                // add activity log
                $this->_activity_log($user_id, Action::Add, $this->ml_users);
                redirect('console/user/view', 'refresh');
            }
        }

        $this->content->title = $title;
        $this->content->status = Status::getValue();
        $this->load_view('form_view', $title);
    }

    function edit() {
       
        $user_id = $this->uri->segment(4);
        if (!$user_id) {
            redirect('console/user/view', 'refresh');
        }

        $title = 'Edit User';
        $this->content->breadcrumb = array(
            'User' => 'console/user',
            $title => NULL
        );

       
        if (isset($post['balance'])) {
            $post = $this->input->post();
            //	xdebug($post);
            $user = array();
            $user['balance'] = $post['balance'];
            $user['updated_by'] = $this->session->userdata('user_id');
            $user['updated_on'] = time();
            $user_id = $this->user_model->edit_data($this->tbl_users, $user, 'user_id', $post['user_id']);

            if (isset($user_id) && !empty($user_id)) :
                $this->_activity_log($user_id, Action::Edit, $this->ml_users);
                redirect('console/user/view', 'refresh');

            endif;
        }

        $this->content->title = $title;
        $this->content->status = Status::getValue();
        $this->content->edit = $this->user_model->user_detail($user_id);
        $this->load_view('edit_form_view', $title);
    }
    
    public function updateBalance()
    {
            $post = $this->input->post();
            //	xdebug($post);
//            $user = array();
//            $user['balance'] = $post['balance'];
//            $user['updated_by'] = $this->session->userdata('user_id');
//            $user['updated_on'] = time();
//            $user_id = $this->user_model->edit_data($this->tbl_users, $user, 'user_id', $post['user_id']);
            
            $this->db->where('user_id',$post['user_id']);
            $this->db->set('balance','balance +'.$post['balance'],false);
            $this->db->update($this->tbl_users);
            
            header("Location: ".base_url()."console/user/view");
    }        

    function view() {
        $title = 'View User';

        $this->content->breadcrumb = array(
            'User' => 'console/user',
            'View User' => 'console/user/view',
        );

        $this->content->title   = $title;
        $this->content->_status = User_status::getValue();
        $this->content->action  = base_url('console/user/add');
        $this->load_view('user_view', $title);
    }


    function get_list() {
        $post = $this->input->post();

        $data = $this->user_model->get_users($post);
        echo json_encode($data);
    }
    
    function recharge_request()
    {
        $title = 'View Request';

        $this->content->breadcrumb = array(
            'User' => 'console/user',
            'View Request' => 'console/user/recharge_request',
        );

        $this->content->title   = $title;
        
        $this->db->select('wp_balance_request.*,wp_user_master.first_name,wp_user_master.mobile');
        $this->db->from('wp_balance_request');
        $this->db->join('wp_user_master','wp_user_master.user_id = wp_balance_request.user_id');
        $this->db->order_by('id','desc');
        $res = $this->db->get()->result();
        $this->content->_requests = $res;
//        $this->content->action  = base_url('console/user/recharge_request');
        $this->load_view('recharge_request', $title);
    }
    
    function upi()
    {
        $title = 'UPI';

        $this->content->breadcrumb = array(
            'User' => 'console/user',
            'View UPI' => 'console/user/upi',
        );

        $this->content->title   = $title;
        
        $this->db->select('*');
        $this->db->from('wp_upi');
        $res = $this->db->get()->result();
        $this->content->_requests = $res;
        $this->content->action  = base_url('console/user/addUpi');
        $this->load_view('upi', $title);
    }
    
    function addUpi()
    {
        $title = 'Add UPI';

        $this->content->breadcrumb = array(
            'User' => 'console/user',
            'View UPI' => 'console/user/upi',
        );

        $this->content->title   = $title;
        
        
        $this->load_view('addUpi', $title);
    }
    
    function saveUpi()
    {
        $upi = $this->input->post('upi');
        $data = array(
            'upi' => trim($upi)
        );
        $this->db->insert('wp_upi',$data);
        
        header("Location: ".base_url()."console/user/upi");
        
        exit();
    }
    
    
    function withdrawl_request()
    {
        $title = 'UPI';

        $this->content->breadcrumb = array(
            'User' => 'console/user',
            'View UPI' => 'console/user/upi',
        );

        $this->content->title   = $title;
        
        $this->db->select('withdrawl_request.*,wp_user_master.first_name');
        $this->db->from('wp_withdrawl_request');
        $this->db->join('wp_user_master','wp_user_master.user_id = wp_withdrawl_request.user_id');
        $this->db->order_by('id','desc');
        $res = $this->db->get()->result();
        $this->content->_requests = $res;
        $this->content->action  = base_url('console/user/withdrawl_request');
        $this->load_view('withdrawl_request', $title);
    }
    
    public function approve_withdrawl()
    {
         $id = $this->input->post('id');
         $this->db->where('id',$id);
         $this->db->set('status',1);
         $this->db->update('wp_withdrawl_request');
          header('Location: '.base_url('console/user/withdrawl_request'));
        exit;
    }
    
    public function reject_withdrawl()
    {
         $id = $this->input->post('id');
         $amount = $this->input->post('amount');
         
//        $this->db->select('*');
//        $this->db->from('wp_settings');
//        $this->db->where('type','cancle');
//        $charge_res = $this->db->get()->row();
//        
//        $charge_per = $charge_res->charge;
//        $cancle_charge = ($amount * $charge_per)/100;
         
         $this->db->where('id',$id);
         $this->db->set('status',2);
//         $this->db->set('c_charge',round($cancle_charge));
         $this->db->update('wp_withdrawl_request');
          header('Location: '.base_url('console/user/withdrawl_request'));
        exit;
    }
    
    
    function change_status()
    {
        $id = $this->input->post('id');
        $amount = $this->input->post('amount');
        $userid = $this->input->post('userid');
        
        $this->db->where('id',$id);
        $this->db->set('status',1);
        $this->db->update('wp_balance_request');
        
        $this->db->where('user_id',$userid);
        $this->db->set('balance','balance +'.$amount,false);
        $this->db->update('wp_user_master');
        
        echo $this->db->last_query();
        
    }

    function detail() {
        $user_id = $this->uri->segment(4);
        if (!$user_id) {
            redirect('console/user/view', 'refresh');
        }

        $detail = $this->user_model->user_detail($user_id);
        $title = toPropercase($detail->first_name . ' ' . $detail->last_name);
        $this->content->breadcrumb = array(
            'User' => 'console/user',
            'View User' => 'console/user/view',
            $title => NULL
        );

        // Where condition
        $mc_where = 'user_id = ' . $user_id;

        /** get user model ids * */
        $mo_table = TBL_MODEL;
        $where = "user_id = '" . $user_id . "' AND  is_deleted = " . Deleted_status::NOT_DELETED;
        $models = $this->user_model->get_comma_value($mo_table, $where, 'model_id', 'model_id');

        /** get model view count * */
        $total_view_count = 0;
        if (isset($models) && !empty($models)) {
            $vi_table = TBL_VIEWS;
            $where = "model_id IN (" . $models . ")";
            $total_view_count = $this->user_model->get_result_count($vi_table, $where);
        }

        $this->content->detail = $detail;
        $this->content->model_view_count = $total_view_count;
        $this->content->model_count = $this->activity_model->get_result_count($mo_table, $mc_where);
        $this->load_view('detail_view', $title);
    }

    function delete() {
        $id = $this->input->post('id');
        $row = $this->input->post('row');
        $table = $this->input->post('table');
        $file = $this->input->post('file');
        if (!$id && !$table && !$column) {
            redirect('console/app', 'refresh');
        }
        $this->load->model(array('app_model'));

        $data = array();
        $data[$row] = $id;
        $data['updated_by'] = $this->session->userdata['user_id'];
        $data['updated_on'] = time();
        $data['is_deleted'] = Deleted_status::DELETED;
        $affected_id = $this->app_model->edit_data($table, $data, $row, $id);

        if (isset($affected_id) && !empty($affected_id)) {

            if (isset($table) && !empty($table) && isset($file) && !empty($file)) {
                @unlink($file);
            }
            // add activity log
            $this->_activity_log($affected_id, Action::Delete, $this->ml_users);

            echo 'success';
        }
    }

    function ajaxStatus() {
        $id = $this->input->post('id');
        $row = $this->input->post('row');
        $table = $this->input->post('table');
        $status = $this->input->post('status');
        if (!$id && !$table && !$column) {
            redirect('console/user', 'refresh');
        }

        $this->load->model(array('user_model'));
        $data = array();
        $data[$row] = $id;
        $data['updated_by'] = $this->session->userdata['user_id'];
        $data['updated_on'] = time();
        $data['user_status'] = $status;
        $affected_id = $this->user_model->edit_data($table, $data, $row, $id);
        if (isset($affected_id) && !empty($affected_id)) {
            // add activity log
            // $this->_activity_log($affected_id, Action::Delete, $this->ml_users);
            echo 'success';
        }
    }

    function export() {
        $this->load->model(array('user_model'));
        $fileName = 'users.xlsx';
        $_user = $this->user_model->get_users_by_role(User_role::MEMBER);
        $spreadsheet = new Spreadsheet();

        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', BASEFULLNAME);
        $sheet->setCellValue('A1', 'No');
        $sheet->setCellValue('B1', 'User');
        $sheet->setCellValue('C1', 'Email');
        $sheet->setCellValue('D1', 'Mobile');
        $sheet->setCellValue('E1', 'City');
        $sheet->setCellValue('F1', 'State');
        $rows = 2;
        $no = 1;
        foreach ($_user as $user) :
            $sheet->setCellValue('A' . $rows, $no);
            $sheet->setCellValue('B' . $rows, toPropercase($user->first_name . ' ' . $user->last_name));
            $sheet->setCellValue('C' . $rows, $user->email);
            $sheet->setCellValue('D' . $rows, $user->mobile);
            $sheet->setCellValue('E' . $rows, toPropercase($user->city));
            $sheet->setCellValue('F' . $rows, toPropercase($user->state));
            $rows++;
            $no++;
        endforeach;
        $writer = new Xlsx($spreadsheet);
        $writer->save('upload/excel/' . $fileName);
        header('Content-Type: application/vnd.ms-excel');
        redirect(base_url() . '/upload/excel/' . $fileName);
    }

    private function load_view($viewname = 'user_view', $page_title)
    {
        $this->masterpage->setMasterPage('master_page');
        $this->masterpage->setPageTitle($page_title);
        $this->masterpage->addContentPage('console/user/' . $viewname, 'content', $this->content);
        $this->masterpage->show();
    }
    
    

}

/* end of user */