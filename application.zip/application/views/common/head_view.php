<?php $current_url = $this->uri->segment(1); ?>
<head>
    <base href='<?= ASSETS_URL; ?>'>
    <meta charset='utf-8' />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title><mp:Title/> || <?= BASEFULLNAME ?></title>
    <meta name='description' content='' />

    <link rel="apple-touch-icon-precomposed" href="media/favicon.jpg" />
    <link rel="shortcut icon" href="media/favicon.jpg" type="image/x-icon" />
    <!--begin::Fonts-->
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700'/>
    <link href='plugins/custom/datatables/datatables.bundle.css' rel='stylesheet' />
    <link href='css/pages/error/error-5.css' rel='stylesheet' type='text/css' />
    <link href='plugins/global/plugins.bundle.css' rel='stylesheet' />
    <link href='plugins/custom/prismjs/prismjs.bundle.css' rel='stylesheet' />
    <link href='css/style.bundle.css' rel='stylesheet' />
    <!--custom css-->
    <link href='css/custom.css' rel='stylesheet' />
    <link href='css/responsive.css' rel='stylesheet' />
    <?php
    if (isset($extra_css) && is_array($extra_css) && count($extra_css) > 0) {
        foreach ($extra_css as $css) :
            echo '<link href="custom/css/' . $css . '.css?' . time() . '" rel="stylesheet"/>';
        endforeach;
    }
    ?>
    <script src='js/jquery.js'></script>
</head>

<script>

    var base_url = '<?= ROOT_URL; ?>';

<?php
if (isset($current_url)) {
    ?>

        var current_url = '<?= $current_url; ?>';

    <?php
}
?>

    var error_report_mail = '<?= error_report_mail('link'); ?>';

<?php
if (isset($sess_expiration_time)) {
    ?>

        var sess_expiration_time = '<?= $sess_expiration_time; ?>';

    <?php
}
?>

</script>