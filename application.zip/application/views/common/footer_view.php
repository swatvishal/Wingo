			<!--begin::Footer-->
			<div class="footer bg-white py-4 d-flex flex-lg-column" id="kt_footer">
				<!--begin::Container-->
				<div class="container d-flex flex-column flex-md-row align-items-center justify-content-between">
					<!--begin::Copyright-->
					<div class="text-dark order-2 order-md-1">
						<span class="text-muted font-weight-bold mr-2">2021©</span>
						<a href="javascript:;" class="text-dark-75 text-hover-primary">
							<?= ( isset($app_name) && !empty($app_name) ? $app_name : BASEFULLNAME ) ?>
						</a>
					</div>
					<!--end::Copyright-->
					<!--begin::Nav-->
					<!-- <div class="nav nav-dark order-1 order-md-2">
						<a href="#" target="_blank" class="nav-link pr-3 pl-0">About</a>
						<a href="#" target="_blank" class="nav-link px-3">Team</a>
						<a href="#" target="_blank" class="nav-link pl-3 pr-0">Contact</a>
					</div> -->
					<!--end::Nav-->
				</div>
				<!--end::Container-->
			</div>
			<!--end::Footer-->
                        <?php $base_url = base_url(); ?>
			<div class="mobfooter-icons d-lg-none flex-lg-column">
			    <ul class="nav text-center d-flex justify-content-around">
			        <li class="nav-item nav-item-foot <?php echo $current_url == 'index' ? 'active' : ''; ?>">
			            <a class="nav-link nav-foot" href="<?= $base_url; ?>">
			                <i class="fa fa-home icon-lg"></i>
			                <p>Home</p>
			           </a>
			        </li>

			        

			        <li class="nav-item nav-item-foot <?php echo $current_url == 'availablity-view' ? 'active' : ''; ?>">
			            <a class="nav-link nav-foot" href="<?= $base_url; ?>">
			            <i class="fa fa-search icon-lg"></i>
			                <p>Search</p>
			            </a>
			        </li>

			        <li class="nav-item nav-item-foot <?php echo $current_url == 'dashboard' ? 'active' : ''; ?>">
			            <a class="nav-link nav-foot" href="<?= $base_url; ?>member/dashboard">  
			                <i class="fas fa-crown icon-lg"></i>
			                <p>Win</p>
			            </a>
			        </li>

			        <li class="nav-item nav-item-foot <?php echo $current_url == 'user-panel' ? 'active' : ''; ?>">
			            <a class="nav-link nav-foot" href="<?= $base_url; ?>member/dashboard/user-panel">  
			                <i class="fas fa-user-alt icon-lg"></i>
			                <p>My Account</p>
			            </a>
			        </li>
			    </ul>
			</div>

		</div>
		<!--end::Wrapper-->
	</div>
	<!--end::Page-->
</div>
<!--end::Main-->
<!-- begin::User Panel-->
<?php $this->load->view('common/include_user_panel'); ?>
<!-- end::User Panel-->
<?php $this->load->view('common/include_footer_js'); ?>