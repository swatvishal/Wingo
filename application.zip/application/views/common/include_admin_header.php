<?php 
$uname             = strtoupper($userdata['user_name']);
$current           = $this->uri->segment(2);
$user_role         = $userdata['user_role'];
$has_admin_access  = [User_role::SUPER_ADMIN, User_role::SYSTEM_ADMIN];
$has_member_access = [];
?>
<div id='kt_header' class='header flex-column header-fixed'>
	<!--begin::Top-->
	<div class='header-top'>
		<!--begin::Container-->
		<div class='container'>
			<!--begin::Left-->
			<div class='d-none d-lg-flex align-items-center mr-3'>
				<!--begin::Logo-->
				<a href='<?= BASE_URL; ?>' class='mr-20'>
					<span class="font-size-h1 font-weight-boldest text-white"><?= BASEFULLNAME; ?></span>
					<!-- <img alt='<?= BASENAMESMALL; ?>' src='<?= WHITE_LOGO; ?>' class='max-h-60px' /> -->
				</a>
				<!--end::Logo-->
			</div>
			<!--end::Left-->
			<!--begin::Topbar-->
			<div class='topbar'>
				<!--begin::User-->
				<div class='topbar-item'>
					<div class='btn btn-icon btn-hover-transparent-white w-auto d-flex align-items-center btn-lg px-2' id='kt_quick_user_toggle'>
						<div class='d-flex flex-column text-right pr-3'>
							<span class='opacity-50 font-weight-bold font-size-sm d-none d-md-inline'>Welcome</span>
							<span class='font-weight-bolder font-size-sm d-none d-md-inline'><?= toPropercase($userdata['user_name']); ?></span>
						</div>
						<span class='symbol symbol-35'>
							<span class='symbol-label font-size-h5 font-weight-bold text-white bg-white-o-30'><?= $uname[0]; ?></span>
						</span>
					</div>
				</div>
				<!--end::User-->
			</div>
			<!--end::Topbar-->
		</div>
		<!--end::Container-->
	</div>
	<!--end::Top-->
	
</div>