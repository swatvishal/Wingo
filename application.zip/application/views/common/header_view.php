<!--begin::Header Mobile-->
<?php $this->load->view('common/include_mobile_header'); ?>
<!--end::Header Mobile-->
<div class='d-flex flex-column flex-root'>
	<!--begin::Page-->
	<div class='d-flex flex-row flex-column-fluid page'>
		<!--begin::Wrapper-->
		<div class='d-flex flex-column flex-row-fluid wrapper' id='kt_wrapper'>
			<!--begin::Header-->
			<?php $this->load->view('common/include_header'); ?>