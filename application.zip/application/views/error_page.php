<!DOCTYPE html>
<html lang="en">
	
		<?php $this->load->view('common/head_view'); ?>
		
		<body id="kt_body" class="quick-panel-right demo-panel-right offcanvas-right header-fixed header-mobile-fixed subheader-enabled aside-enabled aside-static page-loading">
			
				<!--begin::Main-->
				<div class="d-flex flex-column flex-root">
						
						<!--begin::Error-->
						<mp:Content/>
						<!--end::Error-->

				</div>
				<!--end::Main-->

				<?php $this->load->view('common/include_footer_js'); ?>

		</body>
	
</html>