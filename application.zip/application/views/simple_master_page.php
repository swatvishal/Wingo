<!DOCTYPE html>
<html lang="en">
	
        <?php $this->load->view('common/head_view'); ?>
	
        <body id="kt_body" class="quick-panel-right demo-panel-right offcanvas-right header-fixed header-mobile-fixed subheader-enabled aside-enabled aside-static page-loading">
            
            		<?php $this->load->view('common/admin_header_view'); ?>

                    <!-- <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
                        <div class="subheader py-3 py-lg-2 subheader-transparent mt60" id="kt_subheader">
                            <div class="container-fluid">
                            </div>
                        </div>
                        
                        <div class="d-flex flex-column-fluid pb-10">
                            <div class="container-fluid"> -->
                                
                            	<!--begin::Content-->
                                <mp:Content/>
                                <!--end::Content-->
                                
                            <!-- </div>
                        </div>
                    </div> -->

                    <?php $this->load->view('common/footer_view'); ?>

        </body>

</html>