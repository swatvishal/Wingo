<?php foreach($color_array as $c){ ?>
<div class="c_progress progress mt-3" style="height: 20px;">
  <!--<div class="progress-bar progress-bar-striped" role="progressbar" style="width: <?php echo round(($draw_count * $color_count[$c->id])/100)  ?>%;background-color:<?php echo $c->color_code; ?> !important" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"><?php echo $c->name.' : '.$color_count[$c->id]; ?></div>-->
  <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 100%;background-color:<?php echo $c->color_code; ?> !important" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"><?php echo $c->name.' : '.$color_count[$c->id]; ?></div>
</div>
<?php } ?>
<?php foreach($number_array as $c){ ?>
<div class="c_progress progress mt-3" style="height: 20px;">
  <!--<div class="progress-bar progress-bar-striped" role="progressbar" style="width: <?php echo round(($draw_count * $number_count[$c->id])/100)  ?>%;background-color:<?php echo $c->color_code; ?> !important" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"><?php echo $c->name.' : '.$number_count[$c->id]; ?></div>-->
  <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 100%;background-color:<?php echo $c->color_code; ?> !important" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"><?php echo $c->name.' : '.$number_count[$c->id]; ?></div>
</div>
<?php } ?>

