<div class="col-md-12 mt-5">
    <table class="table table-striped" id="draw_table1">
        <thead>
        <!--<th>Betted Amount</th>-->
        <th>Parity</th>
        <th>Amount</th>
        <th>Status</th>
        </thead>
       <tbody id="draw_data">
            <?php
            foreach ($data_profile_tran as $data) {
                if ($data->status == 1) {
                    $symbol = '+';
                    $style = "style='color:green !important'";
                    $amnt = $data->win_amount;
                }
                else if ($data->status == 2) {
                    $symbol = '-';
                    $style = "style='color:red !important'";
                    $amnt = $data->betted_amount;
                }
                else if ($data->status == 0) {
                    $symbol = '-';
                    $style = "style='color:black !important'";
                    $amnt = $data->betted_amount;
                }
                echo '<tr>';
                echo '<td>' . $data->draw_name . '</td>';
//                echo '<td>'. $amnt . '</td>';
//                echo '<td ' . $style . '>' . date("d-m-Y h:i:s A") . '</td>';

                if ($data->status == 1) {
                    echo '<td ' . $style . '>+ '.$amnt.'</td>';
                }
                if ($data->status == 0 && $data->updated_at != NULL) {
                    echo '<td ' . $style . '>- '.$amnt.'</td>';
//                    echo '<td ' . $style . '>Waiting</td>';
                }
                if ($data->status == 0 && $data->updated_at == NULL) {
                    echo '<td>'.$amnt.'</td>';
//                    echo '<td ' . $style . '>Waiting</td>';
                }
                if ($data->status == 2) {
                    echo '<td ' . $style . '>- '.$amnt.'</td>';
                }
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
</div> 
<script>
    $(document).ready(function () {
        $('#draw_table1').DataTable({
            "aaSorting": []
        });
    });
</script>

