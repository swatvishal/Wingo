<?php // xdebug($_topic); ?>
<div class="row">
	<?php
	foreach( $_topic as $topic ) :
		?>
		<div class="col-xl-4">
			<div class="card card-custom gutter-b card-stretch">
				
				<div class="card-body">
					<div class="d-flex flex-wrap align-items-center py-1">
						<div class="symbol symbol-80 symbol-light-danger mr-5">
							<span class="symbol-label">
								<img src="assets/media/svg/misc/008-infography.svg" class="h-50 align-self-center" alt="">
							</span>
						</div>
						
						<div class="d-flex flex-column flex-grow-1 my-lg-0 my-2 pr-3">
							<a href="<?= MEMBER . '/question/' . $topic->url_key; ?>" class="text-dark font-weight-bolder text-hover-primary font-size-h5">
								<?= toPropercase($topic->topic_name); ?>
							</a>
							<span class="text-muted font-weight-bold font-size-lg"></span>
						</div>
					</div>
				</div>

			</div>
		</div>
		<?php
	endforeach;
	?>
</div>