<div class="col-md-12 user-panel-cnt">
    <ul class="user_info_block">
        <li><?php echo strtoupper($data_profile->first_name) . ' - ' . $data_profile->ref_code; ?></li>
        <li><?php echo 'USERID : 91' . $data_profile->mobile ?></li>
        <li><button class="btn btn-primary copy_link" id="myInput" value="<?php echo base_url('account/otp_login/' . $data_profile->ref_code); ?>" >Copy Link</button></li>
    </ul>
    <?php
    if (!empty($data_ref))
        $i = 1;
    foreach ($data_ref as $ref) {
        ?>

                <!--<span class="mt-2 label label-primary" style="height: 30px !important;width:200px !important;border-radius: 2% !important;">Refrence <?php echo $i . ' - ' . strtoupper($ref->first_name); ?></span>-->

        <?php
        $i++;
    }
    ?>
    <div class='navi navi-spacer-x-0 p-0'>
        <a href='<?= base_url('member/dashboard/bankAccount'); ?>' class='navi-item'>
            <div class='navi-link'>
                <div class='symbol symbol-40 bg-light mr-3'>
                    <div class='symbol-label'>
                        <i class="fas fa-building"></i>
                    </div>
                </div>
                <div class='navi-text'>
                    <div class='font-weight-bold'>Bank Account</div>
                    <!--<div class='text-muted'>Account settings and more-->
                    <!--<span class='label label-light-danger label-inline font-weight-bold'>update</span></div>-->
                </div>
            </div>
        </a>
    </div>
    <div class='navi navi-spacer-x-0 p-0'>
        <a href='<?= base_url('member/dashboard/recharge'); ?>' class='navi-item'>
            <div class='navi-link'>
                <div class='symbol symbol-40 bg-light mr-3'>
                    <div class='symbol-label'>
                        <i class="fas fa-credit-card"></i>
                    </div>
                </div>
                <div class='navi-text'>
                    <div class='font-weight-bold'>Recharge</div>
                    <!--<div class='text-muted'>Account settings and more-->
                    <!--<span class='label label-light-danger label-inline font-weight-bold'>update</span></div>-->
                </div>
            </div>
        </a>
    </div>
    <div class='navi navi-spacer-x-0 p-0'>
        <a href='<?= base_url('member/dashboard/transactions'); ?>' class='navi-item'>
            <div class='navi-link'>
                <div class='symbol symbol-40 bg-light mr-3'>
                    <div class='symbol-label'>
                        <i class="fas fa-retweet"></i>
                    </div>
                </div>
                <div class='navi-text'>
                    <div class='font-weight-bold'>Transactions</div>
                    <!--<div class='text-muted'>Account settings and more-->
                    <!--<span class='label label-light-danger label-inline font-weight-bold'>update</span></div>-->
                </div>
            </div>
        </a>
    </div>
    <div class='navi navi-spacer-x-0 p-0'>
        <a href='<?= base_url('member/dashboard/withdrawlRequest'); ?>' class='navi-item'>
            <div class='navi-link'>
                <div class='symbol symbol-40 bg-light mr-3'>
                    <div class='symbol-label'>
                        <i class="fas fa-coins"></i>
                    </div>
                </div>
                <div class='navi-text'>
                    <div class='font-weight-bold'>Withdrawal Request</div>
                    <!--<div class='text-muted'>Account settings and more-->
                    <!--<span class='label label-light-danger label-inline font-weight-bold'>update</span></div>-->
                </div>
            </div>
        </a>
    </div>
    <div class='navi navi-spacer-x-0 p-0'>
        <a href='<?= base_url('member/dashboard/commisssion'); ?>' class='navi-item'>
            <div class='navi-link'>
                <div class='symbol symbol-40 bg-light mr-3'>
                    <div class='symbol-label'>
                        <i class="fas fa-list"></i>
                    </div>
                </div>
                <div class='navi-text'>
                    <div class='font-weight-bold'>Commission</div>
                    <!--<div class='text-muted'>Account settings and more-->
                    <!--<span class='label label-light-danger label-inline font-weight-bold'>update</span></div>-->
                </div>
            </div>
        </a>
    </div>
    <div class='navi navi-spacer-x-0 p-0'>
        <a href='<?= base_url('account/signout'); ?>' class='navi-item'>
            <div class='navi-link'>
                <div class='symbol symbol-40 bg-light mr-3'>
                    <div class='symbol-label'>
                        <i class="fas fa-power-off"></i>
                    </div>
                </div>
                <div class='navi-text'>
                    <div class='font-weight-bold'>Sign Out</div>
                    <!--<div class='text-muted'>Account settings and more-->
                    <!--<span class='label label-light-danger label-inline font-weight-bold'>update</span></div>-->
                </div>
            </div>
        </a>
    </div>
</div> 
<script>
    $(document).ready(function () {
//        var link = $(this).attr('data-link');
        $(".copy_link").click(function(){
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(this).val()).select();
            document.execCommand("copy");
            $temp.remove();
            $(this).text('Link Copied');
        });
        
    });
</script>


