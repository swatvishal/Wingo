<div class="card card-custom gutter-b example example-compact">
    <!--begin::Form-->
    <form id="user-form" class="form" method="post" action="<?= base_url('member/dashboard/savewithdrawlRequest'); ?>" >
        <div class="card-footer bg-gray-100 border-top-0">
            <div class="row align-items-center">
                <div class="col text-left">

                    <h3><b>Current Balance : <?php echo $data_profile->balance; ?></b></h3>

                </div>
                
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                    <label>Enter Amount</label>
                    <input type="number" class="form-control" name="amount" id="amount" placeholder="Enter amount" value="" required=""/>
                    <span class="form-text text-danger" id="error_ac_no"></span>
                </div>
            </div>
            <div class="row">
                    <input type="hidden" name="user_id" value="<?= $data_profile->user_id; ?>" />
                    <input type="hidden" id="c_balance" value="<?= $data_profile->balance; ?>" />
                    <!--<input type="hidden" name="previous" id="previous" value="<?= isset($edit) && isset($edit->email) ? $edit->email : set_value('email'); ?>" />-->
                    <a href="<?= base_url('member/dashboard'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

                    <button type="button" data-url="console/user/upi" class="btn btn-primary font-weight-bolder submit_btn"> <i class="ki ki-check icon-sm"></i>Save </button>
                </div>

        </div>
    </form>

    <div class="card-body">


        <table class="table table-separate table-head-custom table-checkable" id="ctm_datatable">
            <thead>
                <tr>
                    <th width="1%">No</th>
                    <th width="1%">Amount</th>
                    <th width="1%">Status</th>
                    <th width="1%">Create At</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                foreach ($data_request as $req) {
                    echo '<tr>';
                    echo '<td>' . $i;
                    $i++ . '</td>';
                    echo '<td>' . $req->amount . '</td>';
                    if ($req->status == 1) {

                        echo '<td>Approved</td>';
                    }
                    if ($req->status == 0) {

                        echo '<td>Pending</td>';
                    }
                    if ($req->status == 2) {

                        echo '<td>Rejected</td>';
                    }
                    echo '<td>' . date('d-m-Y h:i:s', strtotime($req->created_at)) . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $(".submit_btn").click(function () {
            var amount = $("#amount").val();
            var balance = $("#c_balance").val();

            if (parseInt(amount) < 300) {
                $("#error_ac_no").html('Minimum withdrawal amount is 300');
                return false;
            }
            else if (parseInt(amount) > parseInt(balance))
            {
                $("#error_ac_no").html(' Withdrawal amount should be less than balance');
                return false;
            }
            else 
            {
                $(this).attr('disabled','disabled');
                $("#error_ac_no").html('');
                $("#user-form").submit();
            }
            

            

        });

    });
</script>

