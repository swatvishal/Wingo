<!DOCTYPE html>
<html lang="en">
		
		<?php $this->load->view('common/head_view'); ?>

		<body id="kt_body" class="header-fixed header-mobile-fixed subheader-enabled page-loading">
			
				<!--begin::Main-->
				<mp:Content/>
				<!--end::Main-->

				<?php $this->load->view('common/include_footer_js'); ?>
		
		</body>

</html>