<style>
    ul.list-group.rd-url-group {
    display: inline-block;
    border: none !important;
}
li.list-group-item.rd-url-item {

    border: none;

    border-right: 1px solid #000;

    display: inline-block;

    padding-top: 0;

    padding-bottom: 0;

    border-radius: 0 !important;

    padding-left: 7px;

    padding-right: 13px;

    color: #b81ef0;

}

.rd-urls {

    text-align: right;

    margin-right: 11%;

    margin-top: -3%;

}

@media(max-width: 767.98px){

.rd-urls {

    left: 0%;

    text-align: center;

    margin-right: 0;

}

.mob-lgn {

    margin: 0 !important;

}

}

		</style>

<div class="d-flex flex-column flex-root">

    <!--begin::Login-->

    <div class="login login-1 login-signin-on d-flex flex-column flex-lg-row flex-column-fluid bg-white" id="kt_login">

        <!--begin::Aside-->

        <div class="login-aside d-flex flex-column flex-row-auto" style="background-color: #031838;box-shadow: 0 2px 11px -2px rgb(0 0 0 / 17%);">

            <!--begin::Aside Top-->

            <div class="d-flex flex-column-auto flex-column pt-5 pb-5">

                <!--begin::Aside header-->

                <!-- <a href="<?= BASE_URL; ?>" class="text-center mb-10 font-size-h1 font-weight-boldest clr-purple">

                <?= BASEFULLNAME; ?>

                </a> -->

                <a href="<?= BASE_URL; ?>" class="text-center">

                <!-- <span class="font-size-h1 font-weight-boldest clr-purple"><?= BASEFULLNAME; ?></span> -->

                    <!--<img alt="<?= BASENAMESMALL; ?>" src="<?= MAIN_LOGO_NEW; ?>" class="logo-default  max-h-100px">-->

                    <span class="font-size-h1 font-weight-boldest text-white"><?= BASEFULLNAME; ?></span>

                </a>

         

            </div>

            <!--end::Aside Top-->

            <!--begin::Aside Bottom-->

            <div class="aside-img d-flex flex-row-fluid bgi-no-repeat bgi-position-y-bottom bgi-position-x-center login-bn" style="background-image: url(<?= asset_url(); ?>media/files/saarthiuat.jpg);background-size: cover;"></div>

            <!--end::Aside Bottom-->

        </div>

        <!--begin::Aside-->

        <!--begin::Content-->

        <div class="login-content flex-row-fluid d-flex flex-column justify-content-center position-relative overflow-hidden p-7 mx-auto">

            <!--begin::Content body-->

            <div class="d-flex flex-column-fluid flex-center">

                <!--begin::Signin-->

                <div class="login-form login-signin">

                    <!--begin::Form-->
                       <form action="javascript:;" id="otp_login_form" class="form" novalidate="novalidate" method="post" >

                        <div class="pb-13 pt-lg-0 pt-5">

                            <h4 class="font-weight-bolder text-dark font-size-h4 font-size-h1-lg">

                                Enter details

                            </h4>

                        </div>



                        <div class="form-group">

                            <label class="c_label text-dark">Mobile Number</label>

                            <input class="form-control form-control-solid h-auto py-5 px-6 rounded-lg"  type="text" name="otp_number" id="otp_number" autocomplete="off" placeholder="Enter mobile no." maxlength="10" />

                            <span id="otp_error_mobile_no" class="text-danger"></span>

                        </div>

                        
                        <div class="form-group otp_div" style="display:none">

                            <label class="c_label text-dark" >Enter Otp</label>

                            <input class="form-control form-control-solid h-auto py-5 px-6 rounded-lg" placeholder="Enter otp" type="text" name="otp_no" id="otp_no" autocomplete="off" maxlength="6"/>

                            <span id="error_otp" class="text-danger"></span>

                        </div>


                        <div class="pb-lg-0 pb-5">

                            <button type="button" id="check_otp" class="btn btn-primary font-weight-bolder font-size-h6 px-8 py-4 my-3 mr-3" style="display:none;">Submit Otp</button>

                            <button type="button" id="get_otp" class="btn btn-primary font-weight-bolder font-size-h6 px-8 py-4 my-3 mr-3 btn-block">Get OTP</button>

                        </div>

                        <!--<label class="font-size-h6" >By clicking, I accept the <a href="https://ctllab.in/terms-condition" target="_blank">Terms & Conditions</a> & <a href="https://ctllab.in/privacy-policy" target="_blank">Privacy Policy</a></label>-->

                    </form>

                    <form action="javascript:;" id="login_form" class="form" novalidate="novalidate" method="post" style="display:none;">

                        <div class="pb-13 pt-lg-0 pt-5">

                            <h4 class="font-weight-bolder text-dark font-size-h4 font-size-h1-lg">

                                Enter details

                            </h4>

                        </div>



                        <div id="error_form"></div>

                        <div class="form-group">

                            <label class="c_label text-dark">Name</label>

                            <input class="form-control form-control-solid h-auto py-5 px-4 rounded-lg" type="text" name="name" id="name" autocomplete="off" placeholder="Enter name" />

                            <span id="error_name" class="text-danger"></span>

                        </div>

                        <div class="form-group d-none">

                            <label class="c_label text-dark">Email</label>

                            <input class="form-control form-control-solid h-auto py-5 px-6 rounded-lg" type="text" name="email" id="email" autocomplete="off" placeholder="Enter email" />

                            <span id="error_email" class="text-danger"></span>

                        </div>

                        <div class="form-group">

                            <label class="c_label text-dark">Mobile Number</label>

                            <input class="form-control form-control-solid h-auto py-5 px-6 rounded-lg" readonly="readonly"  type="text" name="mobile_no" id="mobile_no" autocomplete="off" placeholder="Enter mobile no." maxlength="10" />

                            <span id="error_mobile_no" class="text-danger"></span>

                        </div>

                        <div class="form-group">

                            <label class="c_label text-dark">Password</label>

                            <input class="form-control form-control-solid h-auto py-5 px-6 rounded-lg" type="password" name="password" id="password" autocomplete="off" placeholder="Enter password" />

                            <span id="error_password" class="text-danger"></span>

                        </div>

                        <div class="form-group">
                            <?php
                                if(isset($ref_code) && $ref_code != '' && $ref_code != null)
                                {
                                    $ref_code = $ref_code;
                                    $read_only = 'readonly="readonly"';
                                } 
                                else{
                                    $ref_code = '';
                                    $read_only = '';
                                }
                            ?>
                            <label class="c_label text-dark" >Reference Code</label>

                            <input class="form-control form-control-solid h-auto py-5 px-6 rounded-lg" placeholder="Enter Code" type="text" name="user_ref_code" id="user_ref_code" autocomplete="off" value="<?php echo $ref_code ?>" <?php echo $read_only; ?>"/>

                            <span id="error_otp" class="text-danger"></span>

                        </div>
                        
                        
                        <!--						<div class="form-group">

                                                                                <div class="d-flex justify-content-between mt-n5">

                                                                                        <label class="c_label text-dark pt-5">Password</label>

                                                                                         <a href="javascript:;" class="text-primary c_label text-hover-primary pt-5" id="kt_login_forgot">Forgot Password ?</a> 

                                                                                </div>

                                                                                <input class="form-control form-control-solid h-auto py-7 px-6 rounded-lg" type="password" name="password" id="password" autocomplete="off" />

                                                                                <span id="error_password" class="text-danger"></span>

                                                                        </div>-->

                        <div class="pb-lg-0 pb-5">

                            <!--<button type="submit" id="login_btn" class="btn btn-primary font-weight-bolder font-size-h6 px-8 py-4 my-3 mr-3">Get Otp</button>-->

                            <button type="button" id="otp_btn" class="btn btn-primary font-weight-bolder font-size-h6 px-8 py-4 my-3 mr-3 btn-block">Sign Up</button>

                        </div>

                        <!--<label class="font-size-h6" >By clicking, I accept the <a href="https://ctllab.in/terms-condition" target="_blank">Terms & Conditions</a> & <a href="https://ctllab.in/privacy-policy" target="_blank">Privacy Policy</a></label>-->

                    </form>

                    <!--end::Form-->

                </div>



            </div>

            <!--end::Content body-->

        </div>

        <!--end::Content-->

    </div>

    

    <!--end::Login-->

</div>

<script type="text/javascript">

    $(document).ready(function () {

        var continue_to = base_url + 'account';



        $('#login_btn').click(function (event) {

            event.preventDefault();

            var is_valid = 1;

            if ($('#mobile_no').val() == '') {

                is_valid = 0;

                $('#mobile_no').parents('.form-group').addClass('has-error');

                $('#error_email_id').html('Enter mobile number').show();

            }



            if (is_valid) {

                submit_login_form();

            }

        });

        $('#get_otp').click(function (event) {
//            event.preventDefault();
            var mobile_number = $("#otp_number").val();
            $(this).attr('disabled','disabled');
            if (mobile_number == '' || mobile_number.length < 10) {

                is_valid = 0;

                $('#otp_number').parents('.form-group').addClass('has-error');

                $('#otp_error_mobile_no').html('Enter valid mobile number').show();
                $('#get_otp').removeAttr('disabled','disabled');

            }
            else
            {
                 $.ajax({

                type: 'POST',

                url: base_url + 'account/register_mobile',

                data: {mobile_number : mobile_number},

//                dataType: 'json',

                success: function (data) {

                   
                        $('#otp_error_mobile_no').html('').hide();

                        if(data == 'duplicate')
                        {
                            $('#otp_error_mobile_no').html('Duplicate mobile number').show();
                             $('#get_otp').removeAttr('disabled','disabled');

                        }
                        else
                        {
                            $("#get_otp").hide();
                            $("#otp_number").attr('readonly','readonly');
                            $("#check_otp").show();
                            $(".otp_div").show();
                            $('#get_otp').removeAttr('disabled','disabled');
                            
                        }    

                        
                    
                   




                }, error: function (data) {


                }

            });
            }
         
            
        });
        $('#check_otp').click(function (event) {
//            event.preventDefault();
            var mobile_number = $("#otp_number").val();
            var otp_no = $("#otp_no").val();
            $(this).attr('disabled','disabled');
            if (otp_no == '') {

                is_valid = 0;

                $('#otp_no').parents('.form-group').addClass('has-error');
                $('#error_otp').html('Enter OTP').show();
                $('#check_otp').removeAttr('disabled','disabled');

            }
            else
            {
                $.ajax({

                type: 'POST',

                url: base_url + 'account/check_otp',

                data: {'mobile_number' : mobile_number,'otp_no':otp_no},

//                dataType: 'json',

                success: function (data) {

                   if(data == 'true')
                   {
                       $("#otp_login_form").hide();
                       $("#login_form").show();
                       $("#mobile_no").val(mobile_number);
                   }    
                   if(data == 'false')
                   {    
                       $('#check_otp').removeAttr('disabled','disabled');
                       $('#error_otp').html('Invalid OTP').show();
                   }    
                   




                }, error: function (data) {


                }

            });
            }
         
            
        });
        
        
        $('#otp_btn').click(function (event) {

            event.preventDefault();

            var is_valid = 1;

            if ($('#mobile_no').val() == '') {

                is_valid = 0;

                $('#mobile_no').parents('.form-group').addClass('has-error');

                $('#error_mobile_no').html('Enter mobile number').show();

            }

//            if ($('#email').val() == '') {
//
//                is_valid = 0;
//
//                $('#email').parents('.form-group').addClass('has-error');
//
//                $('#error_email').html('Enter email address').show();
//
//            }

            if ($('#name').val() == '') {

                is_valid = 0;

                $('#otp_no').parents('.form-group').addClass('has-error');

                $('#error_name').html('Enter name').show();

            }

            if ($('#password').val() == '') {

                is_valid = 0;

                $('#otp_no').parents('.form-group').addClass('has-error');

                $('#error_password').html('Enter password').show();

            }



            if (is_valid) {

                submit_otp_form();

            }

        });





        function submit_otp_form() {

            $('#otp_btn').html('<span class="fa fa-spinner fa-spin"></span> Connecting...');

            $.ajax({

                type: 'POST',

                url: base_url + 'account/submit-otp-form',

                data: $('#login_form').serialize(),

                dataType: 'json',

                success: function (data) {

                    //console.log(data);

                    $('#error_form').html('').hide();

                    if (data.status == 'success') {

                        $('#otp_btn').html('<span class="fa fa-check"></span> Sign Up Successful...');

                        setTimeout(function () {

                            $('#otp_btn').html('<span class="fa fa-spinner fa-spin"></span> Redirecting...');

                        }, 700);



                        setTimeout(function () {

                            window.location = '<?php echo base_url(); ?>';

                        }, 1000)

                    }
                    
                    if (data.status == 'error') {
                        $('#otp_btn').html('Sign Up');

                        $('#mobile_no').parents('.form-group').addClass('has-error');

                        $('#error_mobile_no').html('Duplicate Mobile Number').show();


                    }





                }, error: function (data) {

                    $('#login_btn').html('Sign In');

                    quick_swal(data.status);

                }

            });

        }

        // end login form



        // start forgot password form

    });

</script>