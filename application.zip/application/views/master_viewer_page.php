<!DOCTYPE html>
<html lang="en">
	<!--begin::Head-->
	<head>
		<base href='<?= ASSETS_URL; ?>'>
	  	<title><mp:Title/> <?= BASEFULLNAME ?></title>
	  	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
	  	<script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
	  	<?php
	    if (isset($extra_css) && is_array($extra_css) && count($extra_css) > 0) {
	        
	        foreach ($extra_css as $css) :
	            echo '<link href="custom/css/' . $css . '.css?'.time().'" rel="stylesheet"/>';
	        endforeach;

	    }
	    ?>
	</head>
	<!--end::Head-->
	
	<!--begin::Body-->
	<body>
		<mp:Content/>
	</body>
	<!--end::Body-->
</html>