<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Thank-You</title>

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
        <!-- Main-StyleSheet include -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    </head>
    <body>
        <div id="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        <div class="check_mark_img">
                            <center><img src="<?php echo base_url(); ?>/assets/media/checkmark.png" alt="image_not_found"></center>
                        </div>
                        <div class="sub_title">
                            <span><center>Your submission has been received</center></span>
                        </div>
                        <div class="title pt-1">
                            <h3><center>Thank you</center></h3>
                        </div>
                    </div>
                    <div class="col-md-4"></div>
                </div>
            </div>
        </div>

    </body>
</html>