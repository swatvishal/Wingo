<div class="card card-custom gutter-b">
    <div class="card-body">
        <div class="row mb-6">
            <div class="col-lg-9">
            </div>

            <div class="col-lg-1">
            </div>
            
            <div class="col-lg-2">
                <a href="<?= base_url() . 'console/user//qrcodeGenerator/'; ?>" target="_blank" class="btn btn-warning float-right new_session">
                    Start New Session
                </a>
            </div>
        </div>

        <table class="table table-separate table-head-custom table-checkable">
            <thead>
                <tr>
                    <th width="1%">Session</th>
                    <th width="2%">Status</th>
                    <th width="3%">Created</th>
                    <th width="4%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                if (!empty($_session))
                {
                    foreach ($_session as $session)
                    {
                        ?>
                        <tr>
                            <td><?php echo $session->session_id; ?></td>
                            <td>
                                <?php
                                if ($session->status == 0)
                                {
                                    echo 'Active';
                                } else {
                                    echo 'Inactive';
                                }
                                ?>
                            </td>
                            <td><?php echo date('d-M-Y h:i:s', $session->created_at) ?></td>
                            <td>
                                <a href="<?php echo ROOT_URL . 'leaderboard/' . $session->session_id; ?>" class="btn btn-info new_session">
                                    Lederboard
                                </a>

                                <button class="btn btn-danger start_session" data-id="<?php echo $session->session_id; ?>">
                                    Start Session
                                </button>           
                            </td>
                        </tr>
                        <?php
                         $i++;
                    }
                }
                else
                {
                    echo '<tr><td colspan="14"><center>No data found</center></td></tr>';
                }
                ?>
            </tbody>
        </table>

    </div>
</div>
<script>
$(document).on('click','.start_session',function()
{
    var base_url = '<?php echo base_url()?>';
    $.ajax({
        type: 'POST',
        url: base_url + 'general/startSession/',
        data: {'session_id': $(this).attr('data-id')},
        success: function (result) {
            window.location.href = '<?php echo base_url(); ?>leaderboard/'+result;
        }
    });
});
</script>
