<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="row mb-6">
			<div class="col-lg-12">
				<a href="<?= base_url().'console/user/export/'; ?>" class="btn btn-light-success float-right">
				    <i class="fas fa-arrow-down"></i> Export
				</a>
			</div>
		</div>

		

		<table class="table table-separate table-head-custom table-checkable" id="ctm_datatable">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="1%">User</th>
                                        <?php
                                            if(!empty($_questions))
                                                foreach($_questions as $key => $que)
                                                {
                                                    echo '<th width="1%">Q'.($key+1).'</th>';
                                                }    
                                        ?>
					<th width="1%">Total Points</th>
					<th width="1%">Total Time</th>
				</tr>
			</thead>
		</table>
	</div>
</div>
<script>
$(document).ready(function() {
    

	/******************* datatable & search *******************/
	var userDT = $('#ctm_datatable').DataTable({ 
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
//        'searching': false,
        //'order': [],
        'ajax': {
            'url': base_url + 'console/user/get-scoreboard',
            
        },
        'columns': [
            { data: 'user_id' },
            { data: 'name' },
            { data: 'Q1' },
            { data: 'Q2' },
            { data: 'Q3' },
            { data: 'Q4' },
            { data: 'Q5' },
            { data: 'Q6' },
            { data: 'Q7' },
            { data: 'Q8' },
            { data: 'Q9' },
            { data: 'Q10' },
            { data: 'time' },
            { data: 'total' },
            
        ],
//        'columnDefs' : [
//        	{ 'orderable': false, 'targets': [0, 1, 2, 3, 4, 5] },
//        	{ 'visible': false, 'targets': [0] }
//    	]
    });

    $('#status').change(function() {
        userDT.draw();
    });

    $('#name, #mobile').keyup(function() {
    	userDT.draw();
    });
	/******************* datatable & search *******************/
});
</script>