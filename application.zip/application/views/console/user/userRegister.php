<div class="row">
    <div class="col-md-4"></div>
    
    <div class="col-md-4">
        
        <center>
            <h1 class="mt-20">SESSION NO - <?php echo $session_data->session_id; ?></h1>
        </center>

        <center><h3 class="mt-20"><b>Scan this QR Code</b></h3></center>

        <center>
            <img src="<?php echo base_url('assets/qrcode/' . $session_data->qr_name); ?>">
        </center>

        <center>
            <button class="btn btn-lg btn-warning start_session mt-20">
                Start Session
            </button>
        </center>
        
    </div>
    <div class="col-md-4"></div>
</div>
<script>
    $(document).on('click','.start_session',function(){
            var base_url = '<?php echo base_url()?>';
            $.ajax({
                type: 'POST',
                url: base_url + 'general/startSession/',
                data: {'session_id': '<?php echo $session_data->session_id; ?>'},
                success: function (result) {
                    window.location.href = '<?php echo base_url(); ?>leaderboard/'+result;
                }
            });
    });
</script>