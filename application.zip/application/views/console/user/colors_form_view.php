<div class="card card-custom gutter-b example example-compact">
    <!--begin::Form-->
    <form id="user-form" class="form" method="post" enctype="multipart/form-data">
        <div class="card-footer bg-gray-100 border-top-0">
            <div class="row align-items-center">
                <div class="col text-left"></div>
                <div class="col text-right">
                    <input type="hidden" name="user_id" value="<?= isset($edit) && isset($edit->user_id) ? $edit->user_id : set_value('user_id'); ?>" />
                    <input type="hidden" name="previous" id="previous" value="<?= isset($edit) && isset($edit->email) ? $edit->email : set_value('email'); ?>" />
                    <a href="<?= base_url('console/user/view'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

                    <button type="submit" data-url="console/user/view" class="btn btn-primary font-weight-bolder submit_btn"> <i class="ki ki-check icon-sm"></i>Save </button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                    <label>Color Name*</label>
                    <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter name" value="<?= isset($edit) && isset($edit->name) ? $edit->name : set_value('first_name'); ?>" />
                    <span class="form-text text-danger" id="error_first_name"></span>
                </div>
                <!--                                <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                                                        <label>Platform Charge*</label>
                                                        <input type="text" class="form-control" name="platform_charge" id="platform_charge" placeholder="Enter price" maxlength="10" value="<?= isset($edit) && isset($edit->platform_charge) ? $edit->platform_charge : set_value('platform_charge'); ?>" />
                                                        <span class="form-text text-danger" id="error_mobile"></span>
                                                </div>-->
                <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                    <label>Status*</label>
                    <div class="radio-inline">
                        <?php
                        foreach ($status as $key => $value):
                            $checked = (isset($edit) && isset($edit->user_status) && $edit->user_status == $key ? 'checked' : '');
                            ?>
                            <label class="radio radio-rounded radio-brand">
                                <input type="radio" name="status" class="user_status" value="<?= $key; ?>" <?= $checked; ?>> <?= $value; ?>
                                <span></span>
                            </label>
<?php endforeach; ?>
                    </div>
                    <span class="form-text text-danger" id="error_user_status"></span>
                </div>

            </div>

            <div class="row">
                <h3 class="font-size-lg text-dark font-weight-bold mb-6">Platform Charge:</h3>
            </div>

            <div class="ctm_repeater">
                <div class="row form-group">
                    <div data-repeater-list="doses" class="col-lg-12">
                        <div data-repeater-item="" class="form-group row align-items-center parent">
                            <div class="col-lg-3 col-12">
                                <div class="form-group">
                                    <label class="col-form-label text-dark">From Price*</label>
                                    <input type="text" class="form-control amount_only price" name="from_price" placeholder="Enter price" value="" />
                                    <span class="form-text text-danger error_price"></span>
                                </div>
                            </div>

                            <div class="col-lg-3 col-12">
                                <div class="form-group">
                                    <label class="col-form-label text-dark">To Price*</label>
                                    <input type="text" class="form-control amount_only price" name="to_price" placeholder="Enter price" value="" />
                                    <span class="form-text text-danger error_price"></span>
                                </div>
                            </div>

                            <div class="col-lg-3 col-12">
                                <div class="form-group">
                                    <label class="col-form-label text-dark">Charge*</label>
                                    <input type="text" class="form-control amount_only price" name="platform_price" placeholder="Enter price" value="" />
                                    <span class="form-text text-danger error_price"></span>
                                </div>
                            </div>


                            <div class="col-md-1 mt-5">
                                <a href="javascript:;" data-repeater-delete="" class="btn btn-sm btn-light-danger btn-icon">
                                    <i class="la la-trash-o"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <hr>
                <div class="row form-group">
                    <div class="col-lg-4">
                        <a href="javascript:;" data-repeater-create="" class="btn btn-sm font-weight-bolder btn-light-primary">
                            <i class="la la-plus"></i>Add
                        </a>
                    </div>
                </div>
            </div>


        </div>
    </form>
</div>

<script type="text/javascript">
    $('.back_btn').click(function ()
    {
        window.location.href = base_url + 'console/user/view';
    });

    $(document).ready(function () {
        $('.ctm_repeater').repeater({
            initEmpty: false,

            show: function () {
              
                $(this).slideDown();

                $('.ctm_dt, .ctm_datepicker').datepicker({
                    rtl: KTUtil.isRTL(),
                    todayHighlight: true,
                    templates: arrows,
                    startDate: '-0m',
                    format: 'dd/mm/yyyy',
                });

                $('.ctm_tp, .ctm_timepicker').timepicker();

                //    $('.ctm_s2').select2();

                $('.select2-container').remove();
                $('.ctm_select2').select2({
                    width: '100%',
                    placeholder: 'Choose slots',
                    allowClear: true
                });

                $('.doses').trigger('change');

                $('.custom-file-input').on('change', function () {
                    var fileName = $(this).val();
                    $(this).next('.custom-file-label').addClass("selected").html(fileName);
                });
            },

            hide: function (deleteElement) {
                if (confirm('Are you sure you want to delete this element?')) {
                    $(this).slideUp(deleteElement);
                }
            }
        });

    });
</script>