<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="row mb-6">
			<div class="col-lg-12">
<!--				<a href="<?= base_url().'console/user/export/'; ?>" class="btn btn-light-success float-right">
				    <i class="fas fa-arrow-down"></i> Export
				</a>-->
			</div>
		</div>

		

		<table class="table table-separate table-head-custom table-checkable" id="ctm_datatable">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="1%">Name</th>
					<th width="1%">Amount</th>
					<th width="1%">Withdrawl<br>Charge</th>
					<th width="1%">Cancle<br>Charge</th>
					<th width="1%">Create At</th>
					<th width="1%">Action</th>
				</tr>
			</thead>
                        <tbody>
                            <?php
                            $i = 1;
                                foreach($_requests as $req)
                                {
                                    echo '<tr>';
                                    echo '<td>'.$i;$i++.'</td>';
                                    echo '<td>'.$req->first_name.'</td>';
                                    echo '<td>'.$req->amount.'</td>';
                                    echo '<td>'.$req->w_charge.'</td>';
                                    echo '<td>'.$req->c_charge.'</td>';
                                    echo '<td>'.date('d-m-Y h:i:s',strtotime($req->created_at)).'</td>';
                                    if($req->status == 0)
                                    {
                                        echo '<td>'
                                        . '<a href="javascript:;" data-id="' . $req->id . '" data-userid = "'.$req->user_id.'" data-amount="'.$req->amount.'" class="btn btn-primary btn-clean  mr-2 approve_btn" title="Approve">Approve</a>'
                                        . '<a href="javascript:;" data-id="' . $req->id . '" data-userid = "'.$req->user_id.'" data-amount="'.$req->amount.'" class="btn btn-danger btn-clean mr-2 reject_btn" title="Reject">Reject</a>'
                                                . '</td>';
                                    }
                                    if($req->status == 1)
                                    {
                                        echo '<td>Approved</td>';
                                    }
                                    if($req->status == 2)
                                    {
                                        echo '<td>Rejected</td>';
                                    }
                                    echo '</tr>';    
                                }    
                            ?>
                        </tbody>
		</table>
	</div>
</div>
<script>
$(document).ready(function() {
	$(document).on('click', '.approve_btn', function () {
                var id    = $(this).data('id');
                var amount    = $(this).data('amount');
                var userid    = $(this).data('userid');
		
		Swal.fire({
			title: 'Are you sure?',
			text: 'You won\'t be able to revert this!',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, approve it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/approve_withdrawl/',
					data:{'id' : id,'amount':amount,'userid':userid},
					success: function(result) {
						
						Swal.fire('Updated!', 'Request accepted.', 'success')
                                                location.reload();
					}
				});
			}
		});
	});
        
	$(document).on('click', '.reject_btn', function () {
                var id    = $(this).data('id');
                var amount    = $(this).data('amount');
                var userid    = $(this).data('userid');
		
		Swal.fire({
			title: 'Are you sure?',
			text: 'You won\'t be able to revert this!',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, reject it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/reject_withdrawl/',
					data:{'id' : id,'amount':amount,'userid':userid},
					success: function(result) {
						
						Swal.fire('Updated!', 'Request accepted.', 'success')
                                                location.reload();
					}
				});
			}
		});
	});

	
});
</script>