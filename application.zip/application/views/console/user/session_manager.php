<div class="card card-custom gutter-b">
    <div class="card-body">
        <div class="row mb-6">

            <div class="col-lg-9">

            </div>
            <div class="col-lg-1">
            </div>
            <div class="col-lg-2">
                <a href="<?= base_url() . 'console/user//qrcodeGenerator/'; ?>" target="_blank" class="btn btn-warning float-right new_session">
                    Start New Session
                </a>
            </div>

        </div>


        <input type="hidden" name="session_id" class="session_id" value="<?php echo $session_id; ?>">
        <table class="table table-separate table-head-custom table-checkable">
            <thead>
                <tr>
                    <th width="1%">Rank</th>
                    <th width="1%">Doctor</th>
                    <?php
                    if (!empty($_questions))
                        foreach ($_questions as $key => $que) {
                            echo '<th width="1%">Q' . ($key + 1) . '</th>';
                        }
                    ?>
                    <th width="1%">Points</th>
                    <th width="1%">Time</th>
                </tr>
            </thead>
            <tbody id="table_data">
                <?php $i = 1;
                if(!empty($_list)){
                foreach ($_list as $list) {
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo toPropercase($list->first_name); ?></td>
                        <td><?php echo $list->Q1; ?></td>
                        <td><?php echo $list->Q2; ?></td>
                        <td><?php echo $list->Q3; ?></td>
                        <td><?php echo $list->Q4; ?></td>
                        <td><?php echo $list->Q5; ?></td>
                        <td><?php echo $list->Q6; ?></td>
                        <td><?php echo $list->Q7; ?></td>
                        <td><?php echo $list->Q8; ?></td>
                        <td><?php echo $list->Q9; ?></td>
                        <td><?php echo $list->Q10; ?></td>
                        <td><?php echo $list->total; ?></td>
                        <td><?php echo $list->time; ?></td>
                    </tr>

                    <?php $i++;
                }
                }else{
                    echo '<tr><td colspan="14"><center>No data found</center></td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    $(document).ready(function () {
        var base_url = '<?php echo base_url()?>';
        setInterval(function(){ 
            $.ajax({
                type: 'POST',
                url: base_url + 'general/dynamicLederData/',
                data: {'session_id': $(".session_id").val()},
                success: function (result) {

                   $("#table_data").html('');
                   $("#table_data").html(result);
                }
            });
        }, 2000);



    });
</script>