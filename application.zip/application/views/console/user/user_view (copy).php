<?php $badge = '<i class="flaticon2-correct text-success icon-md"></i>'; ?>
<div class="card card-custom gutter-b">
	<div class="card-body">
		<table class="table table-separate table-head-custom table-checkable ctm_dt">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="3%">Shop Name</th>
					<th width="1%">Mobile No</th>
					<th width="1%">City</th>
					<th width="1%">State</th>
					<th width="1%">Intersted On</th>
					<!-- <th width="1%">Device</th> -->
					<th width="1%">Status</th>
					<th width="1%">Last Login</th>
					<th width="2%">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($_list as $list) : ?>
				<tr id="ur-<?= $list->user_id; ?>">
					<td><?= $list->user_id; ?></td>
					<td>
						<div class="d-flex align-items-center">
							<div class="ml-3">
                                <span class="text-primary font-weight-bold line-height-sm d-block pb-2"><?= toPropercase($list->shop_name); ?></span>
                                <a href="javascript:;" class="text-muted text-hover-primary"><?= $list->email.' '.($list->email_verified ? $badge : '' ); ?></a>
                            </div>
                        </div>
					</td>
					<td><?= $list->mobile.' '.($list->mobile_verified ? $badge : '' ); ?></td>
					<td><?= toPropercase($list->city); ?></td>
					<td><?= toPropercase($list->state); ?></td>
					<td>
						<?php if(isset($list->is_intersted) && !empty($list->is_intersted)) { ?>
						<span class="btn btn-link-primary font-weight-bold"><?= Intersted::getValue($list->is_intersted); ?></span>
						<?php } ?>
					</td>
					<!-- <td>
						<?php if(isset($list->is_device) && !empty($list->is_device)) { ?>
						<span class="btn btn-link-success font-weight-bold"><?= Device::getValue($list->is_device); ?></span>
						<?php } ?>
					</td> -->
					<td>
						<?php if(isset($list->user_status) && $list->user_status == User_status::INACTIVE) { ?>
							<span id="us-<?= $list->user_id; ?>" class="btn btn-link-danger font-weight-bold status_btn" data-id="<?= $list->user_id; ?>" data-table="user_master" data-row="user_id" data-status="<?= User_status::ACTIVE; ?>" data-value="Active" title="User Status"> <?= User_status::getValue($list->user_status); ?> </span>
						<?php } else { ?>
							<span id="us-<?= $list->user_id; ?>" class="btn btn-link-info label-inline mr-2 font-weight-bold status_btn" data-id="<?= $list->user_id; ?>" data-table="user_master" data-row="user_id" data-status="<?= User_status::INACTIVE; ?>" data-value="Inactive" title="User Status"> <?= User_status::getValue($list->user_status); ?> </span>
						<?php } ?>
					</td>
					<td><?= ($list->last_login ? date('d M Y H:i', $list->last_login) : ''); ?></td>
					<td>
						<!-- <a href="<?= base_url().'console/user/edit/'.$list->user_id; ?>" class="btn btn-sm btn-clean btn-icon mr-2" title="Edit"> <i class="flaticon-edit text-success"></i> </a> -->

						<a href="<?= base_url().'console/user/detail/'.$list->user_id; ?>" class="btn btn-sm btn-clean btn-icon mr-2" title="Detail"> <i class="flaticon2-user text-primary"></i> </a>

                        <!-- <a href="javascript:;" data-id="<?= $list->user_id; ?>" data-table="user_master" data-row="user_id" class="btn btn-sm btn-clean btn-icon mr-2 delete_btn" title="Delete"> <i class="far fa-trash-alt text-danger"></i> </a> -->
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<script>
$(document).ready(function() {
    // Delete user
	$('.ctm_dt').on('click', '.delete_btn', function () {
        var id    = $(this).data('id');
        var row   = $(this).data('row');
		var table = $(this).data('table');

		Swal.fire({
			title: 'Are you sure?',
			text: 'You won\'t be able to revert this!',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/delete/',
					data:{'table' : table, 'row' : row, 'id' : id},
					success: function(result) {
						if(result == 'success')
						Swal.fire('Deleted!', 'User has been deleted.', 'success')

						$('#ur-'+id).addClass('d-none');
					}
				});
			}
		});
	});

	// User status change
	$('.ctm_dt').on('click', '.status_btn', function () {
		var id     = $(this).data('id');
		var row    = $(this).data('row');
		var table  = $(this).data('table');
		var status = $(this).data('status');
		var value  = $(this).data('value');

		Swal.fire({
			title: 'Are you sure?',
			text: 'You want to change this!',
			icon: 'info',
			showCancelButton: true,
			confirmButtonText: 'Yes, change it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/ajaxStatus/',
					data:{'table' : table, 'row' : row, 'id' : id, 'status' : status},
					success: function(result) {
						if(result == 'success')
							Swal.fire('Changes!', 'User has been '+value, 'success')
							$('#us-'+id).addClass('d-none');
					}
				});
			}
		});
	});

});
</script>