<div class="card card-custom gutter-b example example-compact">
    <!--begin::Form-->
    <form id="user-form" class="form" method="post" enctype="multipart/form-data" action="<?php echo base_url(); ?>console/user/updateBalance">
<!--        <div class="card-footer bg-gray-100 border-top-0">
            <div class="row align-items-center">
                <div class="col text-left"></div>
                <div class="col text-right">
                    <input type="hidden" name="user_id" value="<?= isset($edit) && isset($edit->user_id) ? $edit->user_id : set_value('user_id'); ?>" />
                    <input type="hidden" name="previous" id="previous" value="<?= isset($edit) && isset($edit->email) ? $edit->email : set_value('email'); ?>" />
                    <a href="<?= base_url('console/user/view'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

                    <button type="submit" data-url="console/user/view" class="btn btn-primary font-weight-bolder submit_btn"> <i class="ki ki-check icon-sm"></i>Save </button>
                </div>
            </div>
        </div>-->
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                    <label>Balance</label>
                    <input type="text" class="form-control" name="balance" id="balance" placeholder="Enter Amount" value="<?= isset($edit) && isset($edit->balance) ? $edit->balance : set_value('balance'); ?>" />
                    <span class="form-text text-danger" id="error_first_name"></span>
                </div>
            </div>
            <div class="row">
                 <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                    <input type="hidden" name="user_id" value="<?= isset($edit) && isset($edit->user_id) ? $edit->user_id : set_value('user_id'); ?>" />
                    <input type="hidden" name="previous" id="previous" value="<?= isset($edit) && isset($edit->email) ? $edit->email : set_value('email'); ?>" />
                    <a href="<?= base_url('console/user/view'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

                    <button type="submit" data-url="console/user/view" class="btn btn-primary font-weight-bolder submit_btn"> <i class="ki ki-check icon-sm"></i>Save </button>
                </div>
            </div>
        </div>
    </form>
    <form id="user-form" class="form" method="post" enctype="multipart/form-data" action="<?php echo base_url(); ?>console/user/updateToken">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                    <label>Token</label>
                    <input type="text" class="form-control" name="token" id="token" placeholder="Enter Token" value="<?= isset($edit) && isset($edit->token) ? $edit->token : set_value('token'); ?>" />
                    <span class="form-text text-danger" id="error_first_name"></span>
                </div>
            </div>
            <div class="row">
                 <div class="col-sm-12 col-md-6 col-lg-4 form-group">
                    <input type="hidden" name="user_id" value="<?= isset($edit) && isset($edit->user_id) ? $edit->user_id : set_value('user_id'); ?>" />
                    <input type="hidden" name="previous" id="previous" value="<?= isset($edit) && isset($edit->email) ? $edit->email : set_value('email'); ?>" />
                    <a href="<?= base_url('console/user/view'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

                    <button type="submit" data-url="console/user/view" class="btn btn-primary font-weight-bolder submit_btn"> <i class="ki ki-check icon-sm"></i>Save </button>
                </div>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript">
    $('.back_btn').click(function ()
    {
        window.location.href = base_url + 'console/user/view';
    });

    $(document).ready(function () {
        var continue_to = base_url + 'console/user/view';

        $('body').on('change blur', 'input, select', function () {
            $(this).closest('.form-group').removeClass('is-invalid');
        });

        $('body').on('change blur', '#first_name', function () {
            $('#error_first_name').html('').hide();
            if ($(this).val().trim() == '') {
                $('#error_first_name').html('Enter first name').show();
            } else if (!validateName($(this).val().trim())) {
                $('#error_first_name').html('Numbers are not allowed').show();
            }
        });

        $('body').on('change blur', '#last_name', function () {
            $('#error_last_name').html('').hide();
            if ($(this).val().trim() == '') {
                $('#error_last_name').html('Enter last name').show();
            } else if (!validateName($(this).val().trim())) {
                $('#error_last_name').html('Numbers are not allowed').show();
            }
        });

        $('body').on('change blur', '#email', function () {
            $('#error_email').html('').hide();
            if ($(this).val().trim() == '') {
                $('#error_email').html('Enter email address').show();
            } else if (!validateEmail($(this).val().trim())) {
                $('#error_email').html('Enter valid email address').show();
            } else {
                var previous = $('#previous').val().trim();
                var email = $(this).val().trim();
                if ((previous != '' && previous != email) || (previous == '')) {
                    user_exist = false;
                    $('#email_loader').removeClass('d-none');
                    $.ajax({
                        type: 'POST',
                        url: base_url + 'common/ajax-check-user-exist',
                        data: {'email': email},
                        dataType: 'json',
                        success: function (data) {
                            setTimeout(function () {
                                $('#email_loader').addClass('d-none');
                                if (data.user_exist == true) {
                                    user_exist = true;
                                    $('#error_email').html('This email address is already exist').show();
                                    $('.submit_btn').attr('disabled', true);
                                } else {
                                    $('.submit_btn').attr('disabled', false);
                                }
                            }, 1000);
                        }, error: function (data) {
                            ajax_error_swal(data.status);
                        }
                    });
                } else {
                    $('.submit_btn').attr('disabled', false);
                }
            }
        });

        $('body').on('change blur', '#mobile', function () {
            $('#error_mobile').html('').hide();
            if ($('#mobile').val().trim() == '') {
                $('#error_mobile').html('Enter mobile no').show();
            } else if (!validateNumber($(this).val().trim())) {
                $('#error_mobile').html('Enter valid mobile no').show();
            } else if (!validateMobile($(this).val().trim())) {
                $('#error_mobile').html('Enter 10 digit mobile no').show();
            }
        });

        $(':radio[name=user_status]').change(function () {
            $('#error_user_status').html('').hide();
            if ($(this).val().trim() == '') {
                $('#error_user_status').html('Please choose status').show();
            }
        });

        $(':radio[name=is_intersted]').change(function () {
            $('#error_is_intersted').html('').hide();
            if ($(this).val().trim() == '') {
                $('#error_is_intersted').html('Please choose intersted on').show();
            }
        });

        $('#media').change(function () {
            $('#error_media').html('').hide();
            var fileSize = $('#media')[0].files[0].size;
            var fileExtension = ['jpeg', 'jpg', 'png'];

            if (fileSize > 2097152) {
                var msg = 'Upload file size up to 2 MB';
                $('#error_size').html(msg).show();
            }

            if ($(this).val() == '') {
                $('#error_media').html('Select file').show();
            } else if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                var msg = 'Only these formats are allowed : jpeg, jpg, png';
                $('#error_type').html(msg).show();
            }
        });

        $('#user-form').submit(function (e) {
            // e.preventDefault();
            var redirect = base_url + $(this).data('url');
            var isValid = 1;

            if ($('#first_name').val().trim() == '') {
                isValid = 0;
                $('#first_name').parents('.form-group').addClass('is-invalid');
                $('#error_first_name').html('Enter first name').show();
            } else if (!validateName($('#first_name').val().trim())) {
                isValid = 0;
                $('#first_name').parents('.form-group').addClass('is-invalid');
                $('#error_first_name').html('Numbers are not allowed').show();
            }

            if ($('#last_name').val().trim() == '') {
                isValid = 0;
                $('#last_name').parents('.form-group').addClass('is-invalid');
                $('#error_last_name').html('Enter last name').show();
            } else if (!validateName($('#last_name').val().trim())) {
                isValid = 0;
                $('#last_name').parents('.form-group').addClass('is-invalid');
                $('#error_last_name').html('Numbers are not allowed').show();
            }

            if ($('#email').val().trim() == '') {
                isValid = 0;
                $('#email').parents('.form-group').addClass('is-invalid');
                $('#error_email').html('Enter email address').show();
            } else if (!validateEmail($('#email').val().trim())) {
                isValid = 0;
                $('#email').parents('.form-group').addClass('is-invalid');
                $('#error_email').html('Enter valid email address').show();
            }

            if ($('#mobile').val().trim() == '') {
                isValid = 0;
                $('#mobile').parents('.form-group').addClass('is-invalid');
                $('#error_mobile').html('Enter mobile no').show();
            } else if (!validateNumber($('#mobile').val().trim())) {
                isValid = 0;
                $('#mobile').parents('.form-group').addClass('is-invalid');
                $('#error_mobile').html('Enter valid mobile no').show();
            } else if (!validateMobile($('#mobile').val().trim())) {
                isValid = 0;
                $('#mobile').parents('.form-group').addClass('is-invalid');
                $('#error_mobile').html('Enter 10 digit mobile no').show();
            }

            if ($('input[type=radio][name=status]:checked').length == 0) {
                isValid = 0;
                $('.user_status').parents('.form-group').addClass('is-invalid');
                $('#error_user_status').html('Please choose status').show();
            }

            /*if($('input[type=radio][name=is_intersted]:checked').length == 0) {
             isValid = 0;
             $('.is_intersted').parents('.form-group').addClass('is-invalid');
             $('#error_is_intersted').html('Please choose intersted on').show();
             }*/

            /*if($('#media').val() != '') {
             var fileExtension = ['jpeg', 'jpg', 'png'];
             var fileSize = 0;
             fileSize = $("#media")[0].files[0].size;
             
             if(fileSize > 2097152) {
             isValid = 0;
             var msg = 'Upload file size up to 2 MB';
             $('#error_size').html(msg).show();
             } else if ($.inArray($('#media').val().split('.').pop().toLowerCase(), fileExtension) == -1) {
             isValid = 0;
             var msg = 'Only these formats are allowed : jpeg, jpg, png';
             $('#error_type').html(msg).show();
             }
             }*/

            if (!isValid) {
                e.preventDefault();
            } else {
                // Start Block UI
                KTApp.blockPage({
                    overlayColor: 'red',
                    opacity: 0.1,
                    state: 'primary' // a bootstrap color
                });

                setTimeout(function () {
                    KTApp.unblockPage();
                }, 2000);
                // End Block UI
            }
        });

        $(window).bind('pageshow', function () {
            var form = $('form');
            form[0].reset();
        });

        // start file upload
        var media = new KTImageInput('ctm_media');

        media.on('cancel', function (imageInput) {
            swal.fire({
                title: 'Image successfully canceled !',
                type: 'success',
                buttonsStyling: false,
                confirmButtonText: 'Awesome!',
                confirmButtonClass: 'btn btn-primary font-weight-bold'
            });
        });

        media.on('change', function (imageInput) {
            swal.fire({
                title: 'Image successfully changed !',
                type: 'success',
                buttonsStyling: false,
                confirmButtonText: 'Awesome!',
                confirmButtonClass: 'btn btn-primary font-weight-bold'
            });
        });

        media.on('remove', function (imageInput) {
            var id = $('.delete').data('id');
            var row = $('.delete').data('row');
            var table = $('.delete').data('table');
            var table = $('.delete').data('table');
            var file = $('.delete').data('file');

            Swal.fire({
                title: 'Are you sure?',
                text: 'You won\'t be able to revert this!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!'
            }).then(function (result) {
                if (result.value) {
                    $.ajax({
                        type: 'POST',
                        url: base_url + 'console/app/delete/',
                        data: {'id': id, 'table': table, 'row': row, 'file': file},
                        success: function (result) {
                            if (result == 'success')
                                Swal.fire('Deleted!', 'Image successfully removed !', 'success')
                        }
                    });
                }
            });

        });

    });
</script>