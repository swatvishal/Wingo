<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="row mb-6">
			<div class="col-lg-12">
				<a href="<?= base_url().'console/user/export/'; ?>" class="btn btn-light-success float-right">
				    <i class="fas fa-arrow-down"></i> Export
				</a>
			</div>
		</div>

		<div class="row mb-6">
			<div class="col-lg-4 mb-lg-0 mb-6">
				<label class="font-weight-bolder">User Name</label>
				<input type="text" class="form-control" id="name" placeholder="E.g: John" />
			</div>

			<div class="col-lg-4 mb-lg-0 mb-6">
				<label class="font-weight-bolder">Mobile No</label>
				<input type="text" class="form-control" id="mobile" placeholder="E.g: 9876543210" />
			</div>

			<div class="col-lg-4 mb-lg-0 mb-6">
				<label class="font-weight-bolder">Status</label>
				<select class="form-control select2 ctm_s2" id="status" data-placeholder="Choose status">
					<option></option>
					<?php if(isset($_status) && !empty($_status)) {
					foreach($_status as $key => $value) : ?>
						<option value="<?= $key; ?>"><?= toPropercase($value); ?></option>
					<?php endforeach;
					} ?>
				</select>
			</div>
		</div>

		<table class="table table-separate table-head-custom table-checkable" id="ctm_datatable">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="1%">User</th>
					<th width="1%">Mobile No</th>
					<th width="1%">Balance</th>
					<th width="1%">Account Number</th>
					<th width="1%">Ifsc Code</th>
					<!-- <th width="1%">Role</th> -->
					<!--<th width="1%">Status</th>-->
					<th width="1%">Created On</th>
					<th width="1%">Actions</th>
				</tr>
			</thead>
		</table>
	</div>
</div>
<script>
$(document).ready(function() {
    // Delete user
	$('#ctm_datatable').on('click', '.delete_btn', function () {
        var id    = $(this).data('id');
        var row   = $(this).data('row');
		var table = $(this).data('table');

		Swal.fire({
			title: 'Are you sure?',
			text: 'You won\'t be able to revert this!',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/delete/',
					data:{'table' : table, 'row' : row, 'id' : id},
					success: function(result) {
						if(result == 'success')
						Swal.fire('Deleted!', 'User has been deleted.', 'success')

						$('#ur-'+id).addClass('d-none');
					}
				});
			}
		});
	});

	// User status change
	$('#ctm_datatable').on('click', '.status_btn', function () {
		var id     = $(this).data('id');
		var row    = $(this).data('row');
		var table  = $(this).data('table');
		var status = $(this).data('status');
		var value  = $(this).data('value');

		Swal.fire({
			title: 'Are you sure?',
			text: 'You want to change this!',
			icon: 'info',
			showCancelButton: true,
			confirmButtonText: 'Yes, change it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/ajaxStatus/',
					data:{'table' : table, 'row' : row, 'id' : id, 'status' : status},
					success: function(result) {
						if(result == 'success')
							Swal.fire('Changes!', 'User has been '+value, 'success')
							$('#us-'+id).addClass('d-none');
					}
				});
			}
		});
	});

	/******************* datatable & search *******************/
	var userDT = $('#ctm_datatable').DataTable({ 
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        //'searching': false,
        //'order': [],
        'ajax': {
            'url': base_url + 'console/user/get-list',
            'data': function(data) {
				data.name   = $('#name').val();
				data.mobile = $('#mobile').val();
				data.status = $('#status').val();
            }
        },
        'columns': [
            { data: 'user_id' },
            { data: 'name' },
            { data: 'mobile' },
            /*{ data: 'role' },*/
            { data: 'balance' },
            { data: 'ac_no' },
            { data: 'ifsc' },
            { data: 'created_on' },
            { data: 'action' },
        ],
        'columnDefs' : [
        	{ 'orderable': false, 'targets': [0, 1, 2, 3, 4, 5] },
        	{ 'visible': false, 'targets': [0] }
    	]
    });

    $('#status').change(function() {
        userDT.draw();
    });

    $('#name, #mobile').keyup(function() {
    	userDT.draw();
    });
	/******************* datatable & search *******************/
});
</script>