<div class="row mt-20">
    <div class="col-md-4"></div>
    <div class="col-md-4"><h1 style="text-align: center">Welcome to Sun Pharma Online Quiz.</h1><h1 style="text-align: center">We will let you in soon</h1></div>
    <div class="col-md-4"></div>
    <div class="col-md-4"></div>
    <input type="hidden" id="session_status" value="<?php echo $_sessiondata->session_id ?>">
    <input type="hidden" id="user_id" value="<?php echo $_userdata->user_id ?>">
</div>
<script>
    $(document).ready(function () {
       
        setInterval(function () {
                var user_id = $("#user_id").val();
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url('general/getSessionData') ?>',
                    data: {'session_status': $("#session_status").val()},
                    success: function (result) {
                        if(result == 'yes')
                        {    
                            var url = '<?php echo base_url() ?>/general/conductQuiz/'+$("#user_id").val();
                            window.location.href = url;
                        }
                    }
                });
                
            
        }, 1000);

    });
</script>