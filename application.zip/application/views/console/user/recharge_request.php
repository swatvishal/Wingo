<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="row mb-6">
			<div class="col-lg-12">
<!--				<a href="<?= base_url().'console/user/export/'; ?>" class="btn btn-light-success float-right">
				    <i class="fas fa-arrow-down"></i> Export
				</a>-->
			</div>
		</div>

		

		<table class="table table-separate table-head-custom table-checkable" id="ctm_datatable">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="1%">Name</th>
					<th width="1%">Mobile No</th>
					<th width="1%">Amount</th>
					<th width="1%">Utr No</th>
					<th width="1%">Created On</th>
					<th width="1%">Status</th>
					<th width="1%">Actions</th>
				</tr>
			</thead>
                        <tbody>
                            <?php
                            $i = 1;
                                foreach($_requests as $req)
                                {
                                    echo '<tr>';
                                    echo '<td>'.$i;$i++.'</td>';
                                    echo '<td>'.$req->first_name.'</td>';
                                    echo '<td>'.$req->mobile.'</td>';
                                    echo '<td>'.$req->amount.'</td>';
                                    echo '<td>'.$req->utr.'</td>';
                                    echo '<td>'.date('d-m-Y h:i:s',strtotime($req->created_at)).'</td>';
                                    if($req->status == 0)
                                    {
                                        echo '<td>Pending</td>';
                                    }
                                    if($req->status == 1)
                                    {
                                        echo '<td>Approved</td>';
                                    }
                                    if($req->status == 0)
                                    {
                                    echo '<td><a href="javascript:;" data-id="' . $req->id . '" data-userid = "'.$req->user_id.'" data-amount="'.$req->amount.'" class="btn btn-sm btn-clean btn-icon mr-2 delete_btn" title="Approve"> <i class="far fa-check-square text-danger"></i> </a></td>';
                                    }
                                    else
                                    {
                                        echo '<td>Approved</td>';
                                    }    
                                    echo '</tr>';    
                                }    
                            ?>
                        </tbody>
		</table>
	</div>
</div>
<script>
$(document).ready(function() {
    // Delete user
	$('#ctm_datatable').on('click', '.delete_btn', function () {
                var id    = $(this).data('id');
                var amount    = $(this).data('amount');
                var userid    = $(this).data('userid');
		
		Swal.fire({
			title: 'Are you sure?',
			text: 'You won\'t be able to revert this!',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, approve it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/change_status/',
					data:{'id' : id,'amount':amount,'userid':userid},
					success: function(result) {
						
						Swal.fire('Updated!', 'Request accepted.', 'success')
                                                location.reload();
					}
				});
			}
		});
	});

	// User status change
	$('#ctm_datatable').on('click', '.status_btn', function () {
		var id     = $(this).data('id');
		var row    = $(this).data('row');
		var table  = $(this).data('table');
		var status = $(this).data('status');
		var value  = $(this).data('value');

		Swal.fire({
			title: 'Are you sure?',
			text: 'You want to change this!',
			icon: 'info',
			showCancelButton: true,
			confirmButtonText: 'Yes, change it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/ajaxStatus/',
					data:{'table' : table, 'row' : row, 'id' : id, 'status' : status},
					success: function(result) {
						if(result == 'success')
							Swal.fire('Changes!', 'User has been '+value, 'success')
							$('#us-'+id).addClass('d-none');
					}
				});
			}
		});
	});

	/******************* datatable & search *******************/
	var userDT = $('#ctm_datatable').DataTable({ 
        
        });

    $('#status').change(function() {
        userDT.draw();
    });

    $('#name, #mobile').keyup(function() {
    	userDT.draw();
    });
	/******************* datatable & search *******************/
});
</script>