<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="row mb-6">
			<div class="col-lg-12">
<!--				<a href="<?= base_url().'console/user/export/'; ?>" class="btn btn-light-success float-right">
				    <i class="fas fa-arrow-down"></i> Export
				</a>-->
			</div>
		</div>

		

		<table class="table table-separate table-head-custom table-checkable" id="ctm_datatable">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="1%">UPI</th>
				</tr>
			</thead>
                        <tbody>
                            <?php
                            $i = 1;
                                foreach($_requests as $req)
                                {
                                    echo '<tr>';
                                    echo '<td>'.$i;$i++.'</td>';
                                    echo '<td>'.$req->upi.'</td>';
                                    echo '</tr>';    
                                }    
                            ?>
                        </tbody>
		</table>
	</div>
</div>
<script>
$(document).ready(function() {
    // Delete user
	$('#ctm_datatable').on('click', '.delete_btn', function () {
                var id    = $(this).data('id');
                var amount    = $(this).data('amount');
                var userid    = $(this).data('userid');
		
		Swal.fire({
			title: 'Are you sure?',
			text: 'You won\'t be able to revert this!',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, approve it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/change_status/',
					data:{'id' : id,'amount':amount,'userid':userid},
					success: function(result) {
						
						Swal.fire('Updated!', 'Request accepted.', 'success')
                                                location.reload();
					}
				});
			}
		});
	});

	// User status change
	$('#ctm_datatable').on('click', '.status_btn', function () {
		var id     = $(this).data('id');
		var row    = $(this).data('row');
		var table  = $(this).data('table');
		var status = $(this).data('status');
		var value  = $(this).data('value');

		Swal.fire({
			title: 'Are you sure?',
			text: 'You want to change this!',
			icon: 'info',
			showCancelButton: true,
			confirmButtonText: 'Yes, change it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/user/ajaxStatus/',
					data:{'table' : table, 'row' : row, 'id' : id, 'status' : status},
					success: function(result) {
						if(result == 'success')
							Swal.fire('Changes!', 'User has been '+value, 'success')
							$('#us-'+id).addClass('d-none');
					}
				});
			}
		});
	});

	/******************* datatable & search *******************/
	var userDT = $('#ctm_datatable').DataTable({ 
        
        });

    $('#status').change(function() {
        userDT.draw();
    });

    $('#name, #mobile').keyup(function() {
    	userDT.draw();
    });
	/******************* datatable & search *******************/
});
</script>