<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="row mb-6">
			<div class="col-lg-12">
				<a href="<?= base_url().'console/user/export/'; ?>" class="btn btn-light-success float-right">
				    <i class="fas fa-arrow-down"></i> Export
				</a>
			</div>
		</div>

		

		<table class="table table-separate table-head-custom table-checkable" id="ctm_datatable">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="1%">Name</th>
					<!--<th width="1%">Platform Charge</th>-->
					<!--<th width="1%">Status</th>-->
					<!--<th width="1%">Actions</th>-->
				</tr>
			</thead>
		</table>
	</div>
</div>
<script>
$(document).ready(function() {
    // Delete user
	$('#ctm_datatable').on('click', '.delete_btn', function () {
        var id    = $(this).data('id');
        var row   = $(this).data('row');
		var table = $(this).data('table');

		Swal.fire({
			title: 'Are you sure?',
			text: 'You won\'t be able to revert this!',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					type: 'POST',
					url: base_url + 'console/colors/delete/',
					data:{'table' : table, 'row' : row, 'id' : id},
					success: function(result) {
						if(result == 'success')
						Swal.fire('Deleted!', 'User has been deleted.', 'success')

						$('#ur-'+id).addClass('d-none');
					}
				});
			}
		});
	});

	

	/******************* datatable & search *******************/
	var userDT = $('#ctm_datatable').DataTable({ 
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        //'searching': false,
        //'order': [],
        'ajax': {
            'url': base_url + 'console/colors/get-list',
            
        },
        'columns': [
            { data: 'id' },
            { data: 'name' },
//            { data: 'platform_charge' },
//            { data: 'status' },
//            { data: 'action' },
        ],
        'columnDefs' : [
        	{ 'orderable': false, 'targets': [0, 1] },
        	{ 'visible': true, 'targets': [0, 1]  }
    	]
    });

   

	/******************* datatable & search *******************/
});
</script>