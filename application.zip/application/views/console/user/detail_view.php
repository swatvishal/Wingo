<?php //xdebug($detail); ?>
<?php $badge = '<i class="flaticon2-correct text-success icon-md ml-2"></i>'; ?>
<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="d-flex">
			<div class="flex-shrink-0 mr-7 mt-lg-0 mt-3">
				<?php if(isset($detail->media) && !empty($detail->media)) { ?>
				<div class="symbol symbol-50 symbol-lg-60">
					<img src="<?= muser().$detail->media; ?>" alt="<?= $detail->first_name; ?>" />
				</div>
				<?php } else { ?>
				<div class="symbol symbol-50 symbol-lg-60 symbol-primary">
					<span class="font-size-h3 symbol-label font-weight-boldest">
						<?= strtoupper(substr($detail->first_name, 0, 2)); ?>
					</span>
				</div>
				<?php } ?>
			</div>
			<div class="flex-grow-1">
				<div class="d-flex justify-content-between flex-wrap mt-1">
					<div class="d-flex mr-3">
						<span class="text-dark-75 text-hover-primary font-size-h5 font-weight-bold mr-3"><?= toPropercase($detail->first_name.' '.$detail->last_name); ?></span>
					</div>
					<div class="my-lg-0 my-3">
						<?php if($detail->last_login) { ?>
							<a href="javascript:;" class="btn btn-hover-bg-info btn-text-info btn-hover-text-white border-0 font-weight-bold mr-3" title="Last Login"><?= date('d M Y H:i', $detail->last_login); ?></a>
						<?php } ?>
						<a href="javascript:;" class="btn btn-hover-bg-success btn-text-success btn-hover-text-white border-0 font-weight-bold" title="User Status"><?= User_status::getValue($detail->user_status); ?></a>
						<a href="<?= base_url().'console/user/edit/'.$detail->user_id; ?>" class="btn btn-sm btn-clean btn-icon mr-2" title="Edit"><i class="flaticon-edit text-success"></i></a>
					</div>
				</div>
				<div class="d-flex flex-wrap justify-content-between mt-1">
					<div class="d-flex flex-column flex-grow-1 pr-8">
						<div class="d-flex flex-wrap mb-4">
							<a href="javascript:;" class="text-dark-50 text-hover-primary font-weight-bold mr-lg-8 mr-5 mb-lg-0 mb-2">
								<i class="flaticon2-new-email mr-2 font-size-lg"></i>
								<?= $detail->email.' '.($detail->email_verified ? $badge : '' ); ?>
							</a>
							<a href="javascript:;" class="text-dark-50 text-hover-primary font-weight-bold mr-lg-8 mr-5 mb-lg-0 mb-2">
								<i class="flaticon2-calendar-3 mr-2 font-size-lg"></i>
								<?= $detail->mobile.' '.($detail->mobile_verified ? $badge : '' ); ?>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="separator separator-solid"></div>
		<div class="d-flex align-items-center flex-wrap mt-8">
			<div class="d-flex align-items-center flex-lg-fill mr-5 mb-2">
				<span class="mr-4">
					<i class="flaticon-confetti display-4 text-muted font-weight-bold"></i>
				</span>
				<div class="d-flex flex-column text-dark-75">
					<span class="font-weight-bolder font-size-sm">Total Views</span>
					<span class="font-weight-bolder font-size-h5">
						<span class="text-dark-50 font-weight-bold"></span>
						<?= number_format($model_view_count, 0); ?>
					</span>
				</div>
			</div>

			<div class="d-flex align-items-center flex-lg-fill mr-5 mb-2">
				<span class="mr-4">
					<i class="flaticon-confetti display-4 text-muted font-weight-bold"></i>
				</span>
				<div class="d-flex flex-column text-dark-75">
					<span class="font-weight-bolder font-size-sm">Total Models</span>
					<span class="font-weight-bolder font-size-h5">
						<span class="text-dark-50 font-weight-bold"></span>
						<?= number_format($model_count, 0); ?>
					</span>
				</div>
			</div>
			
			<!-- <div class="d-flex align-items-center flex-lg-fill mr-5 mb-2">
				<span class="mr-4">
					<i class="flaticon-chat-1 display-4 text-muted font-weight-bold"></i>
				</span>
				<div class="d-flex flex-column">
					<span class="text-dark-75 font-weight-bolder font-size-sm">648 Comments</span>
					<a href="javascript:;" class="text-primary font-weight-bolder">View</a>
				</div>
			</div> -->
		</div>
	</div>
</div>
