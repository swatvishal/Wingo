<div class="container">
    <div class="row">
        <?php foreach ($_questions as $key => $que) { ?>
            <div class="col-lg-7">
                <form class="question_form" id="tab_<?php echo $que->question_id; ?>">
                    <input type="hidden" name="user_id" class="user_id" value="<?php echo $user_id; ?>">
                    <div class="multisteps_form_panel" >
                        <div class="question_title pb-4">
                            <input type="hidden" name="question_id" class="question_id" value="<?php echo $que->question_id; ?>">
                            <input type="hidden" name="correct_id" class="correct_id" value="<?php echo $que->correct_option; ?>">

                            <h1 class="bg-white rounded-pill position-relative"><?php echo $que->question; ?></h1>
                            <!-- Step-Progress-bar area -->
                            <div class="step_progress_bar position-absolute">
                                <div class="step position-relative" style="background-color: #f8d5b3;"></div>
                                <div class="step position-relative" style="background-color: #ffe090;"></div>
                                <div class="step position-relative" style="background-color: #f2c7db;"></div>
                                <div class="step position-relative" style="background-color: #bdcaff;"></div>
                            </div>
                        </div>
                        <div class="form_items">
                            <ul class="ms-5 p-0 list-unstyled">
                                <li>
                                    <label for="opt_<?php echo $key; ?>_1" class="step_1 rounded-pill position-relative animate__animated animate__fadeInRight animate_50ms">
                                        <input type="radio" id="opt_<?php echo $key; ?>_1" name="stp_select_option" value="1">
                                        <span class="text-white">A</span>
                                        <?php echo $que->option_a; ?>
                                        <span class="pinkLady"></span>
                                    </label>
                                </li>
                                <li>
                                    <label for="opt_<?php echo $key; ?>_2" class="step_1 rounded-pill position-relative animate__animated animate__fadeInRight animate_100ms">
                                        <input type="radio" id="opt_<?php echo $key; ?>_2" name="stp_select_option" value="2">
                                        <span class="text-white">B</span>
                                        <?php echo $que->option_b; ?>
                                        <span class="salomie"></span>
                                    </label>
                                </li>
                                <li>
                                    <label for="opt_<?php echo $key; ?>_3" class="active step_1 rounded-pill position-relative animate__animated animate__fadeInRight animate_150ms">
                                        <input type="radio" id="opt_<?php echo $key; ?>_3" name="stp_select_option" value="3">
                                        <span class="text-white">C</span>
                                        <?php echo $que->option_c; ?>
                                        <span class="wePeep"></span>
                                    </label>
                                </li>
                                <li>
                                    <label for="opt_<?php echo $key; ?>_4" class="step_1 rounded-pill position-relative animate__animated animate__fadeInRight animate_200ms">
                                        <input type="radio" id="opt_<?php echo $key; ?>_4" name="stp_select_option" value="4">
                                        <span class="text-white">D</span><?php echo $que->option_d; ?>
                                        <span class="periwinkle"></span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        <?php } ?>

        <div class="form_btn position-absolute" style="margin-top: -60px !important">
            <label style="color:red;display:none" class="err_msg">Please select answer</label><br>
            <!-- <button type="button" class="f_btn prev_btn text-white rounded-pill text-uppercase d-none" id="prevBtn" onclick="nextPrev(-1)"><span><i class="fas fa-arrow-left"></i></span> Previous Question</button> -->
            <button type="button" class="f_btn nextBtn text-white rounded-pill text-uppercase" id="nextBtn" onclick="nextPrev(1), move()">Next Question</button>
        </div>

    </div>
</div>
<script>
    $(document).ready(function () {
        var interval;

        function countdown() {
            clearInterval(interval);
            interval = setInterval(function () {
                var timer = $('.progress-value').html();
                timer = timer.split(':');
                var minutes = timer[0];
                var seconds = timer[1];
                seconds -= 1;
                if (minutes < 0)
                    return;
                else if (seconds < 0 && minutes != 0) {
                    minutes -= 1;
                    seconds = 59;
                } else if (seconds < 10 && length.seconds != 2)
                    seconds = '0' + seconds;

                $('.progress-value').html(minutes + ':' + seconds);

                if (minutes == 0 && seconds == 0)
                    clearInterval(interval);
            }, 1000);
        }
        
         countdown();
        var delay = 120000; 
        var URL = 'https://sunquizaioc2022.com/general/thankyou/';
        setTimeout(function(){ window.location = URL; }, delay);

    });
</script>