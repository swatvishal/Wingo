<div class="row mt-20">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <form id="add-form" method="post">
            <h3>Please fill following detail</h3>
            <div class="form-group mt-5">
                <input type="hidden" class="form-control" name="session_id" id="session_id" value="<?php echo $session_data->session_id ?>" />
                <input type="text" class="form-control" name="name" id="name" placeholder="Enter name" />
                <span class="form-text text-danger" id="error_first_name"></span>
            </div>
            <div class="form-group">
                <input type="text" class="form-control numbers_only" name="mobile" id="mobile" placeholder="Enter mobile no" maxlength="10" />
                <span class="form-text text-danger" id="error_mobile"></span>
            </div>
            <div class="form-group">
                <select class="form-control ctm_s2 state" name="state" data-placeholder="Choose state">
                    <option></option>
                    <?php
                        foreach ($_states as $location) :
                            $selected = '';
                            ?>
                            <option value="<?= $location->id; ?>" <?= $selected; ?>>
                                <?= strtoupper($location->name); ?>
                            </option>
                            <?php
                        endforeach;
                    ?>
                </select>
                <span class="form-text text-danger" id="error_state"></span>
            </div>
            <div class="form-group">
                <select class="form-control ctm_s2 city" name="city" data-placeholder="Choose city">
                    <option></option>
                </select>
                <span class="form-text text-danger" id="error_city"></span>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-warning center">
                    Join Live
                </button>
            </div>

        </form>
    </div>
    <div class="col-md-4"></div>


</div>
<script type="text/javascript">
    $(document).ready(function () {
        var base_url = '<?php echo base_url(); ?>';
//        alert();
//        var continue_to = base_url + 'console/settings';

        $('body').on('change blur', 'input, select', function () {
            $(this).closest('.form-group').removeClass('is-invalid');
        });
        
        $(document).on('change', '.state', function() {
		$.ajax({
					type: 'POST',
					url: base_url + 'general/get_city/',
					data:{'state_id' : $(this).val()},
					success: function(result) {
						$(".city").html(result);
					}
				});
	});
        $('body').on('change blur', '#name', function() {
		$('#error_first_name').html('').hide();
		if($(this).val().trim() == '') {
			$('#error_first_name').html('Enter name').show();
		}
	});

        $('body').on('change blur', '#mobile', function () {
            $('#error_mobile').html('').hide();
            if ($('#mobile').val().trim() == '') {
                $('#error_mobile').html('Enter contact no').show();
            } else if (!validateNumber($(this).val().trim())) {
                $('#error_mobile').html('Enter valid contact no').show();
            } else if (!validateMobile($(this).val().trim())) {
                $('#error_mobile').html('Enter 10 digit contact no').show();
            }
        });

        $('#add-form').submit(function (e) {
            var isValid = 1;

            if ($('#name').val().trim() == '') {
                isValid = 0;
                $('#name').parents('.form-group').addClass('is-invalid');
                $('#error_first_name').html('Enter name').show();
            }
            if ($('.state').val().trim() == '') {
                isValid = 0;
                $('.state').parents('.form-group').addClass('is-invalid');
                $('#error_state').html('Select State').show();
            }
            /*if ($('.city').val().trim() == '') {
                isValid = 0;
                $('.city').parents('.form-group').addClass('is-invalid');
                $('#error_city').html('Select City').show();
            }*/

            if ($('#mobile').val().trim() == '') {
                isValid = 0;
                $('#mobile').parents('.form-group').addClass('is-invalid');
                $('#error_mobile').html('Enter contact no').show();
            } else if (!validateNumber($('#mobile').val().trim())) {
                isValid = 0;
                $('#mobile').parents('.form-group').addClass('is-invalid');
                $('#error_mobile').html('Enter valid contact no').show();
            } else if (!validateMobile($('#mobile').val().trim())) {
                isValid = 0;
                $('#mobile').parents('.form-group').addClass('is-invalid');
                $('#error_mobile').html('Enter 10 digit contact no').show();
            }

            if (!isValid) {
                e.preventDefault();
            } else {
                // Start Block UI
                KTApp.blockPage({
                    overlayColor: 'red',
                    opacity: 0.1,
                    state: 'primary' // a bootstrap color
                });

                setTimeout(function () {
                    KTApp.unblockPage();
                }, 2000);
                // End Block UI
            }
        });

        $(window).bind('pageshow', function () {
            var form = $('form');
            form[0].reset();
        });
    });
</script>