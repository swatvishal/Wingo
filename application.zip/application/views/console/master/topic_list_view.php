<div class="card card-custom gutter-b">
	<div class="card-body">
		<!--begin: Datatable-->
		<table class="table table-bordered table-checkable" id="ctm_dt">
			<thead>
				<tr>
					<th width="1%">No</th>
					<th width="3%">Topic Name</th>
					<th width="2%">Category</th>
					<th width="2%">No of questions</th>
					<th width="2%">Status</th>
					<th width="2%">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($_list as $list) : ?>
				<tr id="ar-<?= $list->topic_id; ?>">
					<td><?= $list->topic_id; ?></td>
					<td class="font-weight-bold"><?= toPropercase($list->topic_name); ?></td>
					<td><?= toPropercase($list->name); ?></td>
					<td><?= $list->questions; ?></td>
					<td>
						<?php if( isset($list->status) && !empty($list->status) ) { ?>
							<span class="label label-light-primary label-inline font-weight-bolder mr-2">
								<?= Status::getValue($list->status); ?>
							</span>
						<?php } ?>
					</td>
					<td>
						<a href="<?= base_url() . 'console/master/edit-topic/' . $list->topic_id; ?>" class="btn btn-sm btn-clean btn-icon mr-2" title="Edit">
                            <i class="flaticon-edit text-success"></i>
                        </a>

                        <a href="<?= base_url() . 'console/question/' . $list->topic_id; ?>" class="btn btn-sm btn-clean btn-icon mr-2" title="View questions">
                            <i class="fas fa-list text-success"></i>
                        </a>

                        <a href="javascript:;" data-id="<?= $list->topic_id; ?>" data-table="<?= TBL_TOPIC; ?>" data-row="topic_id" class="btn btn-sm btn-clean btn-icon mr-2 delete_btn" title="Deactivate">
                            <i class="far fa-trash-alt text-danger"></i>
                        </a>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<!--end: Datatable-->
	</div>
</div>
<script>
$(document).ready(function() {
    
	$('#ctm_dt').on('click', '.delete_btn', function () {
        var table = $(this).data('table');
        var row   = $(this).data('row');
        var id    = $(this).data('id');

		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then(function (result) {
			if (result.value) {

				$.ajax({
					type: 'POST',
					url: base_url + 'console/master/delete/',
					data:{'table' : table, 'row' : row, 'id' : id},
					success: function(result) {
						if(result == 'success')
						Swal.fire('Deleted!', 'Your topic has been deleted.', 'success')

						$('#ar-'+id).addClass('d-none');
					}
				});

			}
		});

	});

});
</script>