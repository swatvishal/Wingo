<?php // xdebug($_list); ?>
<div class="card card-custom gutter-b">
	<div class="card-body">
		<table class="table table-bordered table-checkable" id="ctm_dt">
			<thead>
				<tr>
					<th>No</th>
					<th>App</th>
					<th>No</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($_list as $list) : ?>
				<tr>
					<td><?= $list->app_id; ?></td>
					<td><?= toPropercase($list->name); ?></td>
					<td>
						<a href="<?= base_url().'console/master/'.$segment.'/'.$list->app_id; ?>"> 
						<span class="btn btn-link-success font-weight-bold"><?= $list->count; ?></span> 
						</a>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>