<?php //xdebug($edit); ?>
<div class="card card-custom gutter-b example example-compact">
	
	<form id="add-form" class="form" method="post" enctype="multipart/form-data">
		<div class="card-footer bg-gray-100 border-top-0">
			<div class="row align-items-center">
				<div class="col text-left"></div>
				<div class="col text-right">
					<input type="hidden" name="topic_id" value="<?= isset($edit) && isset($edit->topic_id) ? $edit->topic_id : set_value('topic_id'); ?>" />
					<input type="hidden" name="previous" value="<?= isset($edit) && isset($edit->topic_name) ? $edit->topic_name : set_value('topic_name'); ?>" />
					<a href="<?= base_url('console/master/topic'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

					<button type="submit" data-url="console/master/topic" class="btn btn-primary font-weight-bolder submit_btn bt-group"> <i class="ki ki-check icon-sm"></i>Save </button>
				</div>
			</div>
		</div>

		<div class="card-body">
			<div class="row">
				<div class="col-sm-12 col-md-6 col-lg-6 form-group">
					<label>Choose Category</label>
					<select class="form-control select2 ctm_s2 ctm_s2_ar" id="parent" name="category_id" data-placeholder="Choose category">
						<option></option>
						<?php if(isset($_category) && !empty($_category)) {
						foreach($_category as $category) : 
						$selected = (isset($edit) && isset($edit->category_id) && $edit->category_id == $category->category_id ? 'selected' : ''); ?>
							<option value="<?= $category->category_id; ?>" <?= $selected; ?>><?= toPropercase($category->name); ?></option>
						<?php endforeach;
						} ?>
					</select>
					<span class="form-text text-danger" id="error_category_id"></span>
				</div>

				<div class="col-sm-12 col-md-6 col-lg-6 form-group">
					<label>Topic Name*</label>
					<input type="text" class="form-control" name="topic_name" id="topic_name" placeholder="Enter topic name" value="<?= isset($edit) && isset($edit->topic_name) ? $edit->topic_name : set_value('topic_name'); ?>" />
					<span class="form-text text-danger" id="error_topic_name"></span>
				</div>

				<div class="col-sm-12 col-md-6 col-lg-6 form-group">
					<label>Image</label>
					<div class="custom-file">
						<input type="file" class="custom-file-input" id="media" name="media" accept="image/x-png, image/jpeg" />
						<label class="custom-file-label">Choose file</label>
					</div>
					<span class="form-text text-danger" id="error_media"></span>
					<span class="form-text text-danger" id="error_type"></span>
					<span class="form-text text-danger" id="error_size"></span>
				</div>

				<div class="col-sm-12 col-md-2 col-lg-2 form-group">
					<label>No of questions</label>
					<input type="text" class="form-control numbers_only" name="questions" id="questions" placeholder="Enter no of questions" maxlength="2" value="<?= isset($edit) && isset($edit->questions) ? $edit->questions : set_value('questions'); ?>" />
					<span class="form-text text-danger" id="error_questions"></span>
				</div>

				<div class="col-sm-12 col-md-6 col-lg-2 form-group">
					<label>Status</label>
                    <div class="radio-inline">
                    <?php
                    foreach($status as $key => $value): 
                    	$checked = (isset($edit) && isset($edit->status) && $edit->status == $key ? 'checked' : '');
                    	?>
                    
                        <label class="radio radio-rounded radio-brand">
                            <input type="radio" name="status" class="status" value="<?= $key; ?>" <?= $checked; ?> /> <?= $value; ?>
                            <span></span>
                        </label>
                    
                    	<?php
                    endforeach;
                    ?>
                    </div>
					<span class="form-text text-danger" id="error_status"></span>
				</div>
			</div>
		</div>
	</form>

</div>
<script type="text/javascript">
$('.back_btn').click(function() {
	window.location.href = base_url + 'console/master/package';
});

$(document).ready(function() {
	var continue_to = base_url + 'console/master/package';
	
	$('body').on('change blur', 'input, select', function() {
		$(this).closest('.form-group').removeClass('is-invalid');
	});
	
	$('body').on('change blur', '#type', function() {
		$('#error_type').html('').hide();
		if($(this).val() == '') {
			$('#error_type').html('Choose type').show();
		}
	});

	$('body').on('change blur', '#topic_name', function() {
		$('#error_topic_name').html('').hide();
		if($(this).val().trim() == '') {
			$('#error_topic_name').html('Enter topic name').show();
		}
	});
	
	$('#media').change(function()
	{	
		$('#error_media').html('').hide();
		var fp            = $("#media");
		var lg            = fp[0].files.length;
		var items         = fp[0].files;
		var fileSize      = 0;
		var fileExtension = ['jpeg', 'jpg', 'png'];

		if (lg > 0) {
			for (var i = 0; i < lg; i++) {
				fileSize = fileSize+items[i].size; // get file size
			}
			if(fileSize > 52428800) {
				var msg = 'Upload file size up to 10 MB';
				$('#error_size').html(msg).show();
			}
		}
       
		if($(this).val() == '') {
			$('#error_media').html('Select file').show();
		} else if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
			var msg = 'Only these formats are allowed : jpeg, jpg, png';
			$('#error_type').html(msg).show();
        }
	});

	$('body').on('change blur', '#questions', function() {
		$('#error_questions').html('').hide();
		if($('#questions').val().trim() == '') {
			$('#error_questions').html('Enter no of questions').show();
		} else if(!validateNumber($(this).val().trim())) {
			$('#error_questions').html('Enter valid no of questions').show();
		}
	});
	
	$('#add-form').submit(function(e)
	{
		var redirect = base_url + $(this).data('url');
		var isValid  = 1;

		if($('#topic_name').val().trim() == '') {
			isValid = 0;
			$('#topic_name').parents('.form-group').addClass('is-invalid');
			$('#error_topic_name').html('Enter topic name').show();
		}

		if($('#questions').val().trim() == '') {
			isValid = 0;
			$('#questions').parents('.form-group').addClass('is-invalid');
			$('#error_questions').html('Enter no of questions').show();
		} else if(!validateNumber($('#questions').val().trim())) {
			isValid = 0;
			$('#questions').parents('.form-group').addClass('is-invalid');
			$('#error_questions').html('Enter valid no of questions').show();
		}

		if($('#media').val() != '') {
			var fileExtension = ['jpeg', 'jpg', 'png'];
			var fileSize = 0;
			fileSize = $("#media")[0].files[0].size;

			if(fileSize > 52428800)
			{
				isValid = 0;
				var msg = 'Upload file size up to 10 MB';
				$('#error_size').html(msg).show();
			} else if ($.inArray($('#media').val().split('.').pop().toLowerCase(), fileExtension) == -1) {
				isValid = 0;
				var msg = 'Only these formats are allowed : jpeg, jpg, png';
				$('#error_type').html(msg).show();
			}
		}

		if(!isValid) {
			e.preventDefault();
		} else {
			// Start Block UI
		    KTApp.blockPage({
		        overlayColor: 'red',
		        opacity: 0.1,
		        state: 'primary' // a bootstrap color
		    });

		    setTimeout(function() {
		        KTApp.unblockPage();
		    }, 2000);
		    // End Block UI
		}
	});

	$(window).bind('pageshow', function() {
		var form = $('form'); 
		form[0].reset();
	});

});
</script>