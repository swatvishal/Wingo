<div class="card card-custom gutter-b">
	<div class="card-body">
		<div class="example example-basic">
			<div class="row">
				<div class="col-md-4 mt-5">
					<div class="example-preview">
						<ul class="navi">
							<li class="navi-item">
								<a class="navi-link" href="<?= base_url('console/master/tax'); ?>">
									<span class="symbol symbol-50 mr-3">
										<span class="symbol-label">
											<i class="flaticon2-percentage icon-xl text-primary"></i>
										</span>
									</span>
									<div class="navi-text">
										<span class="d-block font-weight-bold">Tax</span>
										<!-- <span class="text-muted"></span> -->
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="col-md-4 mt-5">
					<div class="example-preview">
						<ul class="navi">
							<li class="navi-item">
								<a class="navi-link" href="<?= base_url('console/master/advertise'); ?>">
									<span class="symbol symbol-50 mr-3">
										<span class="symbol-label">
											<i class="flaticon-price-tag icon-xl text-primary"></i>
										</span>
									</span>
									<div class="navi-text">
										<span class="d-block font-weight-bold">Offer & Advertise</span>
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="col-md-4 mt-5">
					<div class="example-preview">
						<ul class="navi">
							<li class="navi-item">
								<a class="navi-link" href="<?= base_url('console/master/notification'); ?>">
									<span class="symbol symbol-50 mr-3">
										<span class="symbol-label">
											<i class="flaticon2-bell-5 icon-xl text-primary"></i>
										</span>
									</span>
									<div class="navi-text">
										<span class="d-block font-weight-bold">Send Notification</span>
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-4 mt-5">
					<div class="example-preview">
						<ul class="navi">
							<li class="navi-item">
								<a class="navi-link" href="<?= base_url('console/master/send_message'); ?>">
									<span class="symbol symbol-50 mr-3">
										<span class="symbol-label">
											<i class="flaticon2-email icon-xl text-primary"></i>
										</span>
									</span>
									<div class="navi-text">
										<span class="d-block font-weight-bold">Send Message</span>
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="col-md-4 mt-5">
					<div class="example-preview">
						<ul class="navi">
							<li class="navi-item">
								<a class="navi-link" href="<?= base_url('console/master/app/video'); ?>">
									<span class="symbol symbol-50 mr-3">
										<span class="symbol-label">
											<i class="fas fa-video icon-xl text-primary"></i>
										</span>
									</span>
									<div class="navi-text">
										<span class="d-block font-weight-bold">Video</span>
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="col-md-4 mt-5">
					<div class="example-preview">
						<ul class="navi">
							<li class="navi-item">
								<a class="navi-link" href="<?= base_url('console/master/app/state_meta'); ?>">
									<span class="symbol symbol-50 mr-3">
										<span class="symbol-label">
											<i class="flaticon2-percentage icon-xl text-primary"></i>
										</span>
									</span>
									<div class="navi-text">
										<span class="d-block font-weight-bold">State Wise Discount</span>
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>