<div class="col-md-12 mt-5">
    <ul class="nav nav-tabs mb-10">
        
        <li><button class="btn btn-primary ml-1" id="lvl1">Level 1</button></li>
        <li><button class="btn btn-primary ml-1" id="lvl2">Level 2</button></li>
        <li><button class="btn btn-primary ml-1" id="lvl3">Level 3</button></li>
    </ul>
    
    <table class="table table-striped lvl_one_tbl mt-5" id="draw_table" >

        <thead>

        <th>Name</th>

        <th>Amount</th>

       

        </thead>



        <tbody id="draw_data">

            <?php
            foreach ($data_profile1 as $data) {
                $style = "";
                
                echo '<tr>';


                echo '<td ' . $style . '>' . strtoupper($data->first_name) . '</td>';
                echo '<td ' . $style . '>' . $data->tot_level_1 . '</td>';
                

                echo '</tr>';
            }
            ?>

        </tbody>

    </table>
    <table class="table table-striped lvl_tow_tbl" id="draw_table1" style="display:none">

        <thead>

        <th>Name</th>

        <th>Amount</th>

       

        </thead>



        <tbody id="draw_data">

            <?php
            foreach ($data_profile2 as $data) {
                $style = "";
                
                echo '<tr>';


                echo '<td ' . $style . '>' . strtoupper($data->first_name) . '</td>';
                echo '<td ' . $style . '>' . $data->tot_level_2 . '</td>';
                

                echo '</tr>';
            }
            ?>

        </tbody>

    </table>
    <table class="table table-striped lvl_three_tbl mt-5" id="draw_table2" style="display:none">

        <thead>

        <th>Name</th>

        <th>Amount</th>

       

        </thead>



        <tbody id="draw_data">

            <?php
            foreach ($data_profile3 as $data) {
                $style = "";
                
                echo '<tr>';

                echo '<td ' . $style . '>' . strtoupper($data->first_name) . '</td>';
                echo '<td ' . $style . '>' . $data->tot_level_3 . '</td>';

                

                echo '</tr>';
            }
            ?>

        </tbody>

    </table>




</div> 
<script>
    $(document).ready(function () {
        var table = $('#draw_table').DataTable();
            table.destroy();
            $('#draw_table').DataTable({
                "aaSorting": []
            });
        $("#lvl1").click(function(){
             var table1 = $('#draw_table1').DataTable();
            table1.destroy();
            var table2 = $('#draw_table2').DataTable();
            table2.destroy();
            
            $('.lvl_one_tbl').show();
            $('.lvl_tow_tbl').hide();
            $('.lvl_three_tbl').hide();
            var table = $('#draw_table').DataTable();
            table.destroy();
            $('#draw_table').DataTable({
                "aaSorting": []
            });
           
        });
        $("#lvl2").click(function(){
            
            var table1 = $('#draw_table').DataTable();
            table1.destroy();
            var table2 = $('#draw_table2').DataTable();
            table2.destroy();
            
            $('.lvl_one_tbl').hide();
            $('.lvl_tow_tbl').show();
            $('.lvl_three_tbl').hide();
           
            $('#draw_table1').DataTable({
                "aaSorting": []
            });
            
        });
        $("#lvl3").click(function(){
            var table1 = $('#draw_table').DataTable();
            table1.destroy();
            var table2 = $('#draw_table1').DataTable();
            table2.destroy();
            
            $('.lvl_one_tbl').hide();
            $('.lvl_tow_tbl').hide();
            $('.lvl_three_tbl').show();
            var table = $('#draw_table2').DataTable();
            table.destroy();
            $('#draw_table2').DataTable({
                "aaSorting": []
            });
            
        });
//        $('#draw_table').DataTable({
//            "aaSorting": []
//        });
    });
</script>

