<div class="col-md-12 mt-5">
    <table class="table table-striped" id="draw_table">
        <thead>
        <!--<th>Betted Amount</th>-->
        <th>Parity</th>
        <th>Amount</th>
        <th>Status</th>
        </thead>
        <tbody id="draw_data">
            <?php
            foreach ($data_profile as $data) {
                if ($data->status == 1) {
                    $symbol = '+';
                    $style = "style='font-color:green !important'";
                } else {
                    $symbol = '-';
                    $style = "style='font-color:red !important'";
                }
                echo '<tr>';
                echo '<td ' . $style . '>' . $data->draw_name . '</td>';
                echo '<td ' . $style . '>'. $data->win_amount . '</td>';
//                echo '<td ' . $style . '>' . date("d-m-Y h:i:s A") . '</td>';

                if ($data->status == 1) {
                    echo '<td ' . $style . '>Win</td>';
                }
                if ($data->status == 0) {
                    echo '<td ' . $style . '>Waiting</td>';
                }
                if ($data->status == 2) {
                    echo '<td ' . $style . '>Loss</td>';
                }
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
</div> 
<script>
    $(document).ready(function () {
        $('#draw_table').DataTable({
            "aaSorting": []
        });
    });
</script>

