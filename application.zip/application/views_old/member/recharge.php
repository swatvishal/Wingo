
<style>
    .c_btn_cls{
        background-color: #f5f5f5 !important;
        color: black !important;
    }
    .active_cls{
        background-color: #0095ff !important;
        color: white !important;
    }
</style><div class="row">
    <div class="col-md-12">
        <div class="custom_well" role="alert">
            <center><h4>Balance : ₹ <?php echo $data_profile->balance; ?></h4></center>
        </div>
    </div>
</div>
<div class="row recharge_btn_group">
    <div class="col-md-12 number_btn_group">
        <div class="number_btn_item" role="alert">
            <button class="c_btn c_btn_cls" data-amount="500">
                ₹ 500
            </button>
        </div>
        <div class="number_btn_item" role="alert">
            <button class="c_btn c_btn_cls" data-amount="1000">
                ₹ 1000
            </button>
        </div>
        <div class="number_btn_item" role="alert">
            <button class="c_btn c_btn_cls" data-amount="2000">
                ₹ 2000
            </button>
        </div>
    </div>
</div>
<div class="row recharge_btn_group">
    <div class="col-md-12 number_btn_group">
        <div class="number_btn_item" role="alert">
            <button class="c_btn c_btn_cls" data-amount="5000">
                ₹ 5000
            </button>
        </div>
        <div class="number_btn_item" role="alert">
            <button class="c_btn c_btn_cls" data-amount="10000">
                ₹ 10000
            </button>
        </div>
        <div class="number_btn_item" role="alert">
            <button class="c_btn c_btn_cls" data-amount="49999">
                ₹ 49999
            </button>
        </div>
    </div>
    <div class="col-md-12 number_btn_group">
        <form method="post" action="<?php echo base_url('member/dashboard/recharge_request') ?>">
            <div class="number_btn_item text-center" role="alert" >
                <input type="hidden" id="amount_selected" name="amount_selected">
                <button type="submit" class="c_btn">
                    Submit
                </button>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {

        $(document).on('click', '.c_btn_cls', function () {

            $('.c_btn_cls').removeClass('active_cls');
            $(this).addClass('active_cls');
            var amount = $(this).attr('data-amount');
            alert(amount);
            $("#amount_selected").val(amount);



        });
    });
</script>