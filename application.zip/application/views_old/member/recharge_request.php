<div class="row">
    <div class="col-md-12">
        <div class="custom_well" role="alert">
            <h6>Step - 1  : Copy UPI Information</h6><br>
            <h6>Amount  : <?php echo $amount ?> <button data-copy="<?php echo $amount ?>" class="ml-2 btn btn-sm btn-primary btn-copy text-end">Copy</button></h6>
            <h6>Upi: test1234@oksbi&nbsp;&nbsp;<button data-copy="test1234@oksbi" class="ml-2 btn btn-sm btn-primary btn-copy">Copy</button></h6>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="custom_well" role="alert">
            <h6>Step - 2  : Transfer and don't modify this amount to us by UPI transfer.</h6><br>
            <h6><b>Please record your reference No.{Ref No.} after payment</b></h6>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="custom_well" role="alert">
            <h6>Step - 3  : Please enter Ref No. to complete the recharge</h6><br>
            <h6><b>Be sure to return this page to fill in the UTR numbers after you have completed your payment</b></h6>
            
            <input type="number" style="width: 100%" class="form-control utr_no" placeholder="Enter UTR( UPI Ref. Id) must be 12 digits"><br>
            <input type="hidden" class="form-control request_amount" value="<?php echo $amount ?>"><br>
            
            <button class="btn btn-primary submit_request" data-amount="500">
               Submit
            </button>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        
        $(document).on('click','.btn-copy',function(){
           var element = $(this);
          var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).attr('data-copy')).select();
            document.execCommand("copy");
            $temp.remove();
            

            $(this).tooltip('hide')
            .attr('data-original-title', 'Copied Successfully')
            .tooltip('show');

        });
        $(document).on('click','.submit_request',function(){
           var utr = $('.utr_no').val();
           var amount = $('.request_amount').val();
           if($.trim(utr) == '')
           {
                    $('.submit_request').tooltip('hide')
                    .attr('data-original-title', 'Please enter utr number')
                    .tooltip('show');
                    return false;

           }    
           if($.trim(utr).length < 12)
           {
                    $('.submit_request').tooltip('hide')
                    .attr('data-original-title', 'utr number must be 12 digits')
                    .tooltip('show');
                    return false;

           }    
           $.ajax({

                type: 'POST',

                url: base_url + 'member/dashboard//submit_balance_request/',

                data: {'utr': utr,'amount':amount},

                success: function (result) {
                    
                    if(result == 'true')
                    {
                        $('.submit_request').tooltip('hide')
                        .attr('data-original-title', 'Reuest submitted Successfully, we will verify your payment.')
                        .tooltip('show');
                    }
                    else if(result == 'pending')
                    {
                        $('.submit_request').tooltip('hide')
                        .attr('data-original-title', 'This request is already on pending mode.')
                        .tooltip('show');
                    }    
                    else if(result == 'approved')
                    {
                        $('.submit_request').tooltip('hide')
                        .attr('data-original-title', 'This request is already approved.')
                        .tooltip('show');
                    }    

                }

            });
          

        });
    });
</script>