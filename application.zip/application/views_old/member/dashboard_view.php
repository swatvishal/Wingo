<?php // xdebug($_topic);                   ?>

<div class="modal fade bd-example-modal-lg" tabindex="-1" id="exampleModal" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <input type="hidden" id="game_name" value="">
            </div>
            <div class="modal-body color_data">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                <button type="button" class="btn btn-primary confirma_bet">Confirm</button>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="custom_well" role="alert">
            <h4>Available Balance : ₹ <?php echo $data_profile->balance; ?></h4>
            <a class="c_btn_1" href="<?php echo base_url('member/dashboard/recharge'); ?>">Recharge</a>
            <a class="c_btn_1" href="<?php echo base_url('member/dashboard/trend'); ?>">Trend</a>
            <!--<button class="c_btn_1 float-right">Trend</button>-->
            <a class="btn refresh_btn btn-default float-right" href="<?php echo base_url('member/dashboard'); ?>"><i class="ki ki-refresh"></i></a>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <center><h4>Parity</h4></center>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-md-6 col-6">
        <div class="c_box_1">
            <h4>Period</h4>
            <h1 class="draw-value"><?php echo $active_data->draw_name; ?></h1>
        </div>
    </div>
    <div class="col-md-6 col-6">
        <div class="c_box_1" lass="justify-content-center">
            <h4>Count Down</h4>
            <h1 id="timer"><?php echo $timer; ?></h1>
            <input type="hidden" id="tot_second" value="<?php echo $tot_seconds; ?>">
            <input type="hidden" id="available_balance" value="<?php echo $data_profile->balance; ?>">
        </div>
    </div>
</div>

<div class="row color_btn_group">
    <?php
    foreach ($_games as $game) {
        if ($game->type == 1) {
            ?>
            <div class="color_btn_item col-4">
                <button class="draw_class btn btn-default" style="color:white; background-color:<?php echo $game->color_code; ?>;" data-color="<?php echo $game->color_code; ?>" data-name="<?php echo ucfirst($game->name); ?>" data-id="<?php echo $game->id; ?>">
                    Join <?php echo ucfirst($game->name); ?>
                </button>
            </div>
            <?php
        }
    }
    ?>
</div>    

<div class="row number_btn_cnt">
    <div class="col-12 number_btn_group">
        <?php
        $i = 1;
        foreach ($_games as $game) {
            if ($game->type == 2) {
                ?>
                <div class="number_btn_item">
                    <button type="button" class="draw_class c_btn amount_btn" data-color="<?php echo $game->color_code; ?>"  data-name="<?php echo ucfirst($game->name); ?>"data-id="<?php echo $game->id; ?>"><?php echo ucfirst($game->name); ?></button>
                </div>
                <?php
                if ($i == 5) {
                    //echo '<div class="col-md-2"></div>';
                }
                $i++;
            }
        }
        ?>
    </div>
</div>


<div class="row">
    <div class="col-md-12">

        <table class="table table-striped" id="draw_table">
            <thead>
            <th>Period</th>
            <th>Price</th>
            <th>Number</th>
            <th>Result</th>
            </thead>
            <tbody id="draw_data">
                <?php
                foreach ($_data as $data) {
                    echo '<tr>';
                    echo '<td>' . $data->draw_name . '</td>';
                    echo '<td>' . number_format(rand(14500, 15500), 0) . '</td>';
                    if ($data->win_number != '' || $data->win_number != NULL) {
                        echo '<td>' . $number[$data->win_number] . '</td>';
                    } else {
                        echo '<td></td>';
                    }
                    if ($data->win_color != '' || $data->win_color != NULL) {
                        if ($data->win_color == '3,2') {
                            echo '<td>'
                            . '<div class="test rounded-circle" style="background-color: #f44336;"></div>'
                            . '<div class="test rounded-circle" style="background-color: #9c27b0;"></div>'
                            . '</td>';
                        } else if ($data->win_color == '1,2') {
                            echo '<td>'
                            . '<div class="test rounded-circle" style="background-color: #4caf50;"></div>'
                            . '<div class="test rounded-circle" style="background-color: #9c27b0;"></div>'
                            . '</td>';
                        } else {
                            echo '<td><div class="test rounded-circle" style="background-color: ' . $color[$data->win_color] . ' ;"></div></td>';
                        }
                    } else {
                        echo '<td></td>';
                    }
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div> 
</div>

<div class="row">
    <div class="col-md-12">
        <h4>Transactions</h4>
        <table class="table table-striped" id="draw_table">
            <thead>
        <!--<th>Betted Amount</th>-->
        <th>Parity</th>
        <th>Amount</th>
        <th>Status</th>
        </thead>
        <tbody id="draw_data">
            <?php
            foreach ($data_profile_tran as $data) {
                if ($data->status == 1) {
                    $symbol = '+';
                    $style = "style='font-color:green !important'";
                    $amnt = $data->win_amount;
                } else {
                    $symbol = '-';
                    $style = "style='font-color:red !important'";
                    $amnt = $data->betted_amount;
                }
                echo '<tr>';
                echo '<td ' . $style . '>' . $data->draw_name . '</td>';
                echo '<td ' . $style . '>'. $amnt . '</td>';
//                echo '<td ' . $style . '>' . date("d-m-Y h:i:s A") . '</td>';

                if ($data->status == 1) {
                    echo '<td ' . $style . '>Win</td>';
                }
                if ($data->status == 0) {
                    echo '<td ' . $style . '>Waiting</td>';
                }
                if ($data->status == 2) {
                    echo '<td ' . $style . '>Loss</td>';
                }
                echo '</tr>';
            }
            ?>
        </tbody>
        </table>
    </div> 
</div>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>

    $(document).ready(function () {
        $('#draw_table').DataTable({
            "ordering": false,
            "bLengthChange": false,
            bFilter: false,
            bInfo: false,
        });
        $('#draw_table_tra').DataTable({
            "ordering": false,
            "bLengthChange": false,
            bFilter: false,
            bInfo: false,
        });

        var tot_secondss = $("#tot_second").val();

        if (tot_secondss < 30)
        {
            $(".draw_class").attr('disabled', 'disabled');
        } else {
            $(".draw_class").removeAttr('disabled', 'disabled');
        }

        $(document).on('click', ".range_selector", function () {
            var range = $("#range_val").val();
            var step = $("#step").val();
            var data_type = $(this).attr('data-type');
            var available_balance = $("#available_balance").val();
            var sum = range;
            if (data_type == 'minus')
            {
                if (sum > 0)
                {
                    sum -= parseInt(step);
                }
            }
            if (data_type == 'plus')
            {
                if (sum >= 0)
                {
                    sum = parseInt(sum) + parseInt(step);
                }
            }

            $("#range_val").val(sum);
            $("#range_value").html('Total contract money is ' + range);


            console.log(available_balance);
            if (Math.round(available_balance) < Math.round(range))
            {
                $(".confirma_bet").attr('disabled', 'disabled');
//                $(this).attr('disabled', 'disabled');
                $('#error_msg').html('You do not have enough money');
//                return false;

            } else {
                $(".confirma_bet").removeAttr('disabled');
//                $(this).removeAttr('disabled');
                $('#error_msg').html('');
                $("#betted_amount").val(range);

            }

        });

        $(document).on('click', '.draw_class', function () {
            var id = $(this).attr('data-id');
            var name = $(this).attr('data-name');
            var color = $(this).attr('data-color');
            $("#exampleModalLabel").html('Join ' + name);
            $("#game_name").val(name);
            $('#exampleModalLabel').css("color", "white");
            $('.modal-header').css("background-color", color);

            $.ajax({

                type: 'POST',

                url: base_url + 'account/get_data/',

                data: {'color_id': id},

                success: function (result) {
                    $('.color_data').html(result);
                    $('#exampleModal').modal('toggle');
                }

            });

        });


        setInterval(function () {

            var tot_seconds = $("#tot_second").val();

            if (tot_seconds < 30)
            {
                $(".draw_class").attr('disabled', 'disabled');
            } else {
                $(".draw_class").removeAttr('disabled', 'disabled');

            }

            $("#tot_second").val($("#tot_second").val() - 1)
            if (tot_seconds > 0)
            {
                var current_timer = Math.floor((tot_seconds) / 60) + ":" + ((tot_seconds) % 60 ? (tot_seconds) % 60 : '00');
                $('#timer').html(current_timer);
            } else {
                $('#timer').html(current_timer);
            }
            if ($("#tot_second").val() > 0 && $("#tot_second").val() < 2)
            {
                $("#tot_second").val('180');
                var current_timer = Math.floor((180) / 60) + ":" + ((180 - 1) % 60 ? (180 - 1) % 60 : '00');

            }

            if (tot_seconds > 177)
            {
                $.ajax({

                    type: 'POST',

                    url: base_url + 'account/active_draw_data/',

                    data: {'table': ''},
                    dataType: 'json',

                    success: function (result_data) {



                        $('.draw-value').html(result_data.draw);
                        if (result_data.tot_seconds < '30')
                        {
                            $(".draw_class").attr('disabled', 'disabled');
                        } else {
                            $(".draw_class").removeAttr('disabled', 'disabled');

                        }




                    }

                });
                $.ajax({

                    type: 'POST',

                    url: base_url + 'account/drawData/',

                    data: {'table': ''},

                    success: function (result_data) {

                        $('#draw_table').DataTable().destroy();

                        $('#draw_data').html(result_data);

                        $('#draw_table').DataTable({
                            "aaSorting": []
                        });

                    }

                });
            }

        }, 1000);

        //
//        setInterval(function () {
//
//            $.ajax({
//
//                type: 'POST',
//
//                url: base_url + 'account/active_draw_data/',
//
//                data: {'table': ''},
//                dataType: 'json',
//
//                success: function (result_data) {
//
//                    $('#timer').html(result_data.timer);
//
//                    $('.draw-value').html(result_data.draw);
//                    if (result_data.tot_seconds < '30')
//                    {
//                        $(".draw_class").attr('disabled', 'disabled');
//                    } else {
//                        $(".draw_class").removeAttr('disabled', 'disabled');
//
//                    }
//                    
//                   
//                    
//                    if (result_data.tot_seconds > '175')
//                    {
//                        $.ajax({
//
//                            type: 'POST',
//
//                            url: base_url + 'account/drawData/',
//
//                            data: {'table': ''},
//
//                            success: function (result_data) {
//
//                                $('#draw_table').DataTable().destroy();
//
//                                $('#draw_data').html(result_data);
//
//                                $('#draw_table').DataTable({
//                                    "aaSorting": []
//                                });
//
//                            }
//
//                        });
//                    }
//                }
//
//            });
//
//        }, 2000);

        $(document).on('click', '.bet_amount', function () {
            var available_balance = $("#available_balance").val();
            var current_balance = $(this).attr('data-amount');

            $("#range_val").val(current_balance);
            $("#step").val(current_balance);
            $("#range_value").html('Total contract money is ' + current_balance);

//            alert(available_balance+'--'+current_balance);
            if (Math.round(available_balance) < Math.round(current_balance))
            {
                $(".confirma_bet").attr('disabled', 'disabled');
                $('#error_msg').html('You do not have enough money');
//                return false;
            } else
            {
                $(".confirma_bet").removeAttr('disabled');
                $('#error_msg').html('');
                $(this).removeClass('btn-default');
                $(this).addClass('btn-primary');
                $("#betted_amount").val($(this).attr('data-amount'));
            }

        });

        $(document).on('click', '.confirma_bet', function () {
            var betted_amount = $("#betted_amount").val();
            var game_name = $("#game_name").val();

            if (betted_amount == '' || betted_amount == '0' || betted_amount == '0.00')
            {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Please select amount',
                })
                return false;
            }
            Swal.fire({
                title: 'Are you sure?',
                text: "You have bet for " + game_name + " and amount is Rs " + betted_amount,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Confirm'
            }).then((isConfirm) => {
//                    console.  log(isConfirm.value);
                if (isConfirm.value) {
                    $(this).hide();
                    $('.swal2-confirm').hide();

                    $.ajax({

                        type: 'POST',

                        url: base_url + 'account/submitBet/',

                        data: {'betted_amount': betted_amount, 'game_id': $("#game_id").val(), 'active_game_id': $("#active_game_id").val()},

                        success: function (result_data) {
                            Swal.fire(
                                    'Done!',
                                    'Submitteed successfully!',
                                    'success'
                                    )
                            location.reload();
                        }

                    });
                }
            })
        });






    });

</script>