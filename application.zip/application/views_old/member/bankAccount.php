<div class="card card-custom gutter-b example example-compact">
	<!--begin::Form-->
        <form id="user-form" class="form" method="post" action="<?= base_url('member/dashboard/saveAccount'); ?>">
<!--		<div class="card-footer bg-gray-100 border-top-0">
			<div class="row align-items-center">
				<div class="col text-left"></div>
				<div class="col text-right">
					<input type="hidden" name="user_id" value="<?= $data_profile->user_id; ?>" />
					<input type="hidden" name="previous" id="previous" value="<?= isset($edit) && isset($edit->email) ? $edit->email : set_value('email'); ?>" />
					<a href="<?= base_url('member/dashboard'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

					<button type="submit" data-url="console/user/upi" class="btn btn-primary font-weight-bolder submit_btn"> <i class="ki ki-check icon-sm"></i>Save </button>
				</div>
			</div>
		</div>-->
		<div class="card-body">
			<div class="row">
				<div class="col-sm-12 col-md-6 col-lg-4 form-group">
					<label>Account Number</label>
                                        <input type="number" class="form-control" name="ac_no" id="ac_no" placeholder="Enter Account No" value="<?php echo $data_profile->ac_no; ?>" required=""/>
					<span class="form-text text-danger" id="error_ac_no"></span>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-6 col-lg-4 form-group">
					<label>IFSC Code</label>
                                        <input type="text" class="form-control" name="ifsc" id="ifsc" placeholder="Enter IFSC Code" value="<?php echo $data_profile->ifsc; ?>" required=""/>
					<span class="form-text text-danger" id="error_ifsc"></span>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-6 col-lg-4 form-group">
					<label>Account Holder Name</label>
                                        <input type="text" class="form-control" name="ac_name" id="ac_name" placeholder="Account Holder Name" value="<?php echo $data_profile->ac_name; ?>" required=""/>
					<span class="form-text text-danger" id="error_ac_name"></span>
				</div>
			</div>
                        <div class="row align-items-center">
                                    <!--<div class="col text-left"></div>-->
                                    <div class="col text-left">
                                            <input type="hidden" name="user_id" value="<?= $data_profile->user_id; ?>" />
                                            <!--<input type="hidden" name="previous" id="previous" value="<?= isset($edit) && isset($edit->email) ? $edit->email : set_value('email'); ?>" />-->
                                            <a href="<?= base_url('member/dashboard'); ?>" class="btn btn-light-primary font-weight-bolder mr-2"> <i class="ki ki-long-arrow-back icon-sm"></i>Back </a>

					<button type="submit" data-url="console/user/upi" class="btn btn-primary font-weight-bolder submit_btn"> <i class="ki ki-check icon-sm"></i>Save </button>
				</div>
			</div>
		</div>
	</form>
</div>

