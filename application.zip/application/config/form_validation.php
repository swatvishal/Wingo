<?php
$config = array(
	'login_form' => array(
		array(
			'field' => 'email_id',
			'label' => 'Email address',
			'rules' => 'trim|required',
		), array(
			'field' => 'password',
			'label' => 'Password',
			'rules' => 'required'
		),
	),
	'forgot_password_form' => array(
		array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'trim|required|valid_email',
			'errors' => array(
                'is_unique' => 'This %s already exists.'
			)
		),
	),
	'reset_password_form' => array(
		array(
			'field' => 'reset_code',
			'label' => 'Reset Code',
			'rules' => 'required'
		), array(
			'field' => 'new_password',
			'label' => 'New Password',
			'rules' => 'required'
		), array(
			'field' => 'confirm_password',
			'label' => 'Confirm Password',
			'rules' => 'required|matches[new_password]'
		),
	),
        'otp_login_form' => array(
                    array(
                            'field' => 'mobile_no',
                            'label' => 'Mobile Number',
                            'rules' => 'trim|required',
                    )
        ),
    
	'change_password_form' => array(
		array(
			'field' => 'current_password',
			'label' => 'Current Password',
			'rules' => 'required'
		), array(
			'field' => 'new_password',
			'label' => 'New Password',
			'rules' => 'required'
		), array(
			'field' => 'confirm_password',
			'label' => 'Confirm Password',
			'rules' => 'required|matches[new_password]'
		),
	),
	'add_user' => array(
		array(
			'field' => 'first_name',
			'label' => 'First Name',
			'rules' => 'required'
		), array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'trim|required|valid_email',
			'errors' => array(
                'is_unique' => 'This %s already exists.'
			)
		)
	),
	'add_color' => array(
		array(
			'field' => 'first_name',
			'label' => 'Name',
			'rules' => 'required'
		),
//            array(
//			'field' => 'platform_charge',
//			'label' => 'Platform Charge',
//                        'rules' => 'required'
//			
//		)
	),
	'edit_user' => array(
		array(
			'field' => 'app_id',
			'label' => 'App ID',
			'rules' => 'required'
		), array(
			'field' => 'first_name',
			'label' => 'First Name',
			'rules' => 'required'
		), array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'trim|required|valid_email',
			'errors' => array(
                'is_unique' => 'This %s already exists.'
			)
		)
	),
	'add_category' => array(
		/*array(
			'field' => 'app_id',
			'label' => 'Choose App',
			'rules' => 'required'
		),*/ array(
			'field' => 'name',
			'label' => 'Category Name',
			'rules' => 'required'
		)
	),
	'edit_category' => array(
		array(
			'field' => 'category_id',
			'label' => 'Category ID',
			'rules' => 'required'
		), /*array(
			'field' => 'app_id',
			'label' => 'Choose App',
			'rules' => 'required'
		),*/ array(
			'field' => 'name',
			'label' => 'Category Name',
			'rules' => 'required'
		)
	),
	'add-question' => array(
		array(
			'field' => 'question',
			'label' => 'Question',
			'rules' => 'required'
		),
	),
	'edit-question' => array(
		array(
			'field' => 'question',
			'label' => 'Question',
			'rules' => 'required'
		),
	),
	'add-topic' => array(
		array(
			'field' => 'topic_name',
			'label' => 'Topic Name',
			'rules' => 'required'
		)
	),
	'edit-topic' => array(
		array(
			'field' => 'topic_id',
			'label' => 'Topic ID',
			'rules' => 'required'
		), array(
			'field' => 'topic_name',
			'label' => 'Topic Name',
			'rules' => 'required'
		)
	),
	'question-meta' => array(
		array(
			'field' => 'user_answer',
			'label' => 'Answer',
			'rules' => 'required'
		)
	),
    
        'user_register' => array(
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		), 
		array(
			'field' => 'mobile',
			'label' => 'Contact No',
			'rules' => 'required'
		), 
	),
);

$config['error_prefix'] = '';
$config['error_suffix'] = '';