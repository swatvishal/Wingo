<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| JWT Secure Key
|--------------------------------------------------------------------------
*/
$config['jwt_key'] = '$2y$10$X0tleSYxMjMkQCEjQHBybuEEI2bZwM8uZLjZ9D.0Nj9.LDjQjEV/6';


/*
|--------------------------------------------------------------------------
| JWT Algorithm Type
|--------------------------------------------------------------------------
*/
$config['jwt_algorithm'] = 'HS256';