<?php
class Enum {
	function __construct (){}
}

class User_role {
	const SUPER_ADMIN  = 1;
	const SYSTEM_ADMIN = 2;
	const CLIENT       = 3;
	const MEMBER       = 4;		

	public static function getValue($value = NULL)  {
        $class = new ReflectionClass('User_role');
        $constants = $class->getConstants();
        $constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL) {
			return $constants[$value];
		}
		return $constants;
    }
}

class User_status {
	const INACTIVE    = 0;
	const ACTIVE      = 1;
	const DEACTIVATED = 2;

	public static function getValue($value = NULL) {
        $class = new ReflectionClass('User_status');
        $constants = $class->getConstants();
        $constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL) {
			return $constants[$value];
		}
		return $constants;
    }
}

class Deleted_status {
	const NOT_DELETED = 0;
	const DELETED 	  = 1;

	public static function getValue($value = NULL) {
        $class = new ReflectionClass('Deleted_status');
        $constants = $class->getConstants();
        $constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL) {
			return $constants[$value];
		}
		return $constants;
    }
}

class Status {
	const INACTIVE = 0;
	const ACTIVE   = 1;

	public static function getValue($value = NULL) {
		$class = new ReflectionClass('Status');
		$constants = $class->getConstants();
		$constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL) {
			return $constants[$value];
		}
		return $constants;
	}
}

class Yes_no
{
	const No  = 1;
	const Yes = 2;

	public static function getValue($value = NULL)
	{
		$class = new ReflectionClass('Yes_no');
		$constants = $class->getConstants();
		$constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL)
		{
			return $constants[$value];
		}
		return $constants;
	}
}

class Verification_code_type
{
	const EMAIL    = 1;
	const MOBILE   = 2;
	const PASSWORD = 3;
}

class Verification_code_status
{
	const ACTIVE 	  = 1;
	const VERIFIED 	  = 2;
	const DEACTIVATED = 3;
}

class Verified
{
	const NOT_VERIFIED = 0;
	const VERIFIED     = 1;
}

class Module
{
	const Media        		= 		1;
	const Category     		= 		2;
	const USER         		= 		3;
	const TOPIC      		= 		4;
	const QUESTION      	= 		5;
	const MUSIC 			= 		6;
	const VIDEO     		= 		7;
	
	public static function getValue($value = NULL) {
		$class = new ReflectionClass('Module');
		$constants = $class->getConstants();
		$constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL) {
			return $constants[$value];
		}
		return $constants;
	}
}

class Action
{
	const Add      = 1;
	const Edit     = 2;
	const View     = 3;
	const Delete   = 4;
	const Sign_up  = 5;
	const Sign_in  = 6;
	const Sign_out = 7;
	
	public static function getValue($value = NULL) {
		$class = new ReflectionClass('Action');
		$constants = $class->getConstants();
		$constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL) {
			return $constants[$value];
		}
		return $constants;
	}
}

class Duration {
	const One_week    = 1;
	const One_month   = 2;
	const Three_month = 3;
	const Six_month   = 4;
	const One_Year    = 5;
	
	public static function getValue($value = NULL) {
		$class = new ReflectionClass('Duration');
		$constants = $class->getConstants();
		$constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL) {
			return $constants[$value];
		}
		return $constants;
	}
}

class Subscription_type
{
	const VIEW  = 1;
	const MODEL = 2;
	
	public static function getValue($value = NULL)
	{
		$class = new ReflectionClass('Subscription_type');
		$constants = $class->getConstants();
		$constants = toProperCase(array_flip($constants),'_');
		if($value !== NULL)
		{
			return $constants[$value];
		}
		return $constants;
	}
}

/* end of enum */